//
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation

/*
 AppSettings.swift - Responsible for managing user defaults throughout the application lifecycle
 */
class AppSettings {
    
    private let defaults = UserDefaults.standard
    ///singleton AppSettings instance
    static let shared = AppSettings()
    
    ///private initilizer for the singleton instance
    private init() {
    }
    
    enum Keys: String {
        case communicationMode
        case availableScannerBgNotification
        case activeScannerBgNotification
        case barcodeEventBgNotification
        case discoverBluetoothScanners
        case setFactoryDefaults
        case autoConnectOnRelaunch
        case enableVirtualTether
        case enableHostFeedback
        case virtualTetherVibration
        case virtualTetherAudioAlarm
        case virtualTetherFlashingScreen
        case virtualTetherPopupMessage
        case enableHostFeedbackToggles
        case virtualTetherNotifyEvent
        
    }
    
    var communicationMode: String {
        get { defaults.string(forKey: Keys.communicationMode.rawValue) ?? CommunicationMode.MFI_BT_LE.rawValue }
        set { defaults.set(newValue, forKey: Keys.communicationMode.rawValue) }
    }
    
    var availableScannerBgNotification: Bool {
        get { defaults.bool(forKey: Keys.availableScannerBgNotification.rawValue) }
        set { defaults.set(newValue, forKey: Keys.availableScannerBgNotification.rawValue) }
    }
    
    var activeScannerBgNotification: Bool {
        get { defaults.bool(forKey: Keys.activeScannerBgNotification.rawValue) }
        set { defaults.set(newValue, forKey: Keys.activeScannerBgNotification.rawValue) }
    }
    
    var barcodeEventBgNotification: Bool {
        get { defaults.bool(forKey: Keys.barcodeEventBgNotification.rawValue) }
        set { defaults.set(newValue, forKey: Keys.barcodeEventBgNotification.rawValue) }
    }
    
    var discoverBluetoothScanners: Bool {
        get { defaults.bool(forKey: Keys.discoverBluetoothScanners.rawValue) }
        set { defaults.set(newValue, forKey: Keys.discoverBluetoothScanners.rawValue) }
    }
    
    var setFactoryDefaults: Bool {
        get { defaults.bool(forKey: Keys.setFactoryDefaults.rawValue) }
        set { defaults.set(newValue, forKey: Keys.setFactoryDefaults.rawValue) }
    }
    
    var autoConnectOnRelaunch: Bool {
        get { defaults.bool(forKey: Keys.autoConnectOnRelaunch.rawValue) }
        set { defaults.set(newValue, forKey: Keys.autoConnectOnRelaunch.rawValue) }
    }
    
    func resetDefaults() {
        defaults.set(CommunicationMode.MFI_BT_LE.rawValue, forKey: Keys.communicationMode.rawValue)
        defaults.set(true, forKey: Keys.availableScannerBgNotification.rawValue)
        defaults.set(true, forKey: Keys.activeScannerBgNotification.rawValue)
        defaults.set(false, forKey: Keys.barcodeEventBgNotification.rawValue)
        defaults.set(true, forKey: Keys.discoverBluetoothScanners.rawValue)
        defaults.set(false, forKey: Keys.setFactoryDefaults.rawValue)
        defaults.set(false, forKey: Keys.autoConnectOnRelaunch.rawValue)
        
    }
    
    //virtual tether related settings
    var enableHostFeedbackToggles: Bool {
        get { defaults.bool(forKey: Keys.enableHostFeedbackToggles.rawValue) }
        set { defaults.set(newValue, forKey: Keys.enableHostFeedbackToggles.rawValue) }
    }
    
    var enableVirtualTether: Bool {
        get { defaults.bool(forKey: Keys.enableVirtualTether.rawValue) }
        set { defaults.set(newValue, forKey: Keys.enableVirtualTether.rawValue) }
    }
    
    var enableHostFeedback: Bool {
        get { defaults.bool(forKey: Keys.enableHostFeedback.rawValue) }
        set { defaults.set(newValue, forKey: Keys.enableHostFeedback.rawValue) }
    }
    
    var virtualTetherVibration: Bool {
        get { defaults.bool(forKey: Keys.virtualTetherVibration.rawValue) }
        set { defaults.set(newValue, forKey: Keys.virtualTetherVibration.rawValue) }
    }
    
    var virtualTetherAudioAlarm: Bool {
        get { defaults.bool(forKey: Keys.virtualTetherAudioAlarm.rawValue) }
        set { defaults.set(newValue, forKey: Keys.virtualTetherAudioAlarm.rawValue) }
    }
    
    var virtualTetherFlashingScreen: Bool {
        get { defaults.bool(forKey: Keys.virtualTetherFlashingScreen.rawValue) }
        set { defaults.set(newValue, forKey: Keys.virtualTetherFlashingScreen.rawValue) }
    }
    
    var virtualTetherPopupMessage: Bool {
        get { defaults.bool(forKey: Keys.virtualTetherPopupMessage.rawValue) }
        set { defaults.set(newValue, forKey: Keys.virtualTetherPopupMessage.rawValue) }
    }
    
    var virtualTetherNotifyEvent: Bool {
        get { defaults.bool(forKey: Keys.virtualTetherNotifyEvent.rawValue) }
        set { defaults.set(newValue, forKey: Keys.virtualTetherNotifyEvent.rawValue) }
    }

}

enum CommunicationMode: String, CaseIterable {
    case BT_LE = "BT LE"
    case MFI = "MFi"
    case MFI_BT_LE = "MFi + BT LE"
}
