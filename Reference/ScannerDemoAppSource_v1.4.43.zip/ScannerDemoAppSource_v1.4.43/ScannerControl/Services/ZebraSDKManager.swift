//
//  SDKHandler.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation
import SwiftUI

/*
 Responsible for  run scanner sdk api calls and receive notifications/events
 */
class ZebraSDKManager: NSObject, ISbtSdkApiDelegate {
    
    /// The shared property is static, can access it from anywhere in code. This ensures global access
    static let shared: ZebraSDKManager = {
        let sharedSDKInstance = ZebraSDKManager()
        return sharedSDKInstance
    }()
    
    weak var sdkApiInstance : ISbtSdkApi?
    @ObservedObject var appState = AppState.shared
    private var symbologyList: [Symbology] = []
    
    /// Private initializer, to avoid initializing singleton class again.
    private override init() {
        super.init()
        self.initializedSDK()
    }
    
    ///initialized sdk settings and subscribe for events
    func initializedSDK() {
        sdkApiInstance = SbtSdkFactory.createSbtSdkApiInstance()
        
        sdkApiInstance?.sbtSetDelegate(self)
        
        sdkApiInstance?.sbtSetOperationalMode(Int32(SBT_OPMODE_ALL))
        
        sdkApiInstance?.sbtSubsribe(forEvents: Int32(SBT_EVENT_SCANNER_APPEARANCE) |
                                    Int32(SBT_EVENT_SCANNER_DISAPPEARANCE) |
                                    Int32(SBT_EVENT_SESSION_ESTABLISHMENT) |
                                    Int32(SBT_EVENT_SESSION_TERMINATION) |
                                    Int32(SBT_EVENT_BARCODE) |
                                    Int32(SBT_EVENT_IMAGE) |
                                    Int32(SBT_EVENT_VIDEO))
        
        // actively detect appearance/disappearance of scanners
        sdkApiInstance?.sbtEnableAvailableScannersDetection(true)
        // start Bluetooth discovery of scanners
        sdkApiInstance?.sbtEnableBluetoothScannerDiscovery(true)
        // enable/disable auto connect on app relaunch
        sdkApiInstance?.sbtAutoConnectToLastConnectedScanner(onAppRelaunch: AppSettings.shared.autoConnectOnRelaunch)
    }
    
    /// Get sdk version
    /// - Returns: The sdk version
    func getSDKVersion() -> String {
        
        return sdkApiInstance?.sbtGetVersion() ?? ""
        
    }
    
    /// Get the generated paired barcode with the selected default setting status and resulting imageview
    /// - Parameters:
    ///   - setDefaultsStatus: enum value of default status setting (SETDEFAULT_YES / SETDEFAULT_NO)
    ///   - imageView: UIImageView to get the dimensions for barcode generation
    /// - Returns: The STC pairing barcode image as UIImage
    func getSTCPairingBarcode(setDefaultsStatus: SETDEFAULT_STATUS, imageView : UIImageView) -> UIImage {
        
        return sdkApiInstance?.sbtGetPairingBarcode(BARCODE_TYPE_STC, withComProtocol: STC_SSI_BLE, withSetDefaultStatus: setDefaultsStatus, withImageFrame: imageView.frame) ?? UIImage()
    }
    
    /// Disconnect the scanner
    ///  - Parameter scannerId : Id of the scanner
    func disconnectScanner(scannerId: Int32){
        sdkApiInstance?.sbtTerminateCommunicationSession(scannerId)
        self.appState.isScannerConnected = false
        self.appState.selectedTab = .BLE
    }
    
    /// Removing a scanner from available scanner list
    /// - Parameter scannerId : Id of the scanner
    func removeScannerFromAvailableList(scannerId: Int32) {
        self.appState.availableScannerList = self.appState.availableScannerList.filter{ $0.scannerId != scannerId}
    }
    
    /// Add a scanner to available scanner list
    /// - Parameter scanner : Scanner details
    func addScannerToAvailableList(scanner: ScannerInfo) {
        if (!self.appState.availableScannerList.contains(scanner)) {
            self.appState.availableScannerList.append(scanner)
        }
    }
    
    //MARK: Execute commands and helper functions ---------------------------------
    
    /// Method to get the attribute values by attribute ids and scanner id
    /// - Parameters:
    ///   - attributeIdList: List of attribute Ids
    ///   - scannerId: Id of the scanner
    /// - Returns: list of attribute details
    func getAttributeValues(attributeIdList: [Int32], scannerId: Int32) -> [AttributeDetail] {
        var retryCount = 0
        let attributeListString = attributeIdList.map{String($0)}.joined(separator: ",")
        var attributeList = [AttributeDetail]()
        let inXML:String = "<inArgs><scannerID>\(scannerId)</scannerID><cmdArgs><arg-xml><attrib_list>\(attributeListString)</attrib_list></arg-xml></cmdArgs></inArgs>"
        var outXml:NSMutableString! = NSMutableString()
        var result = self.sdkApiInstance?.sbtExecuteCommand(Int32(SBT_RSM_ATTR_GET),aInXML: inXML, aOutXML: &outXml,forScanner: scannerId)
        if (result != SBT_RESULT_SUCCESS) {
            repeat {
                Task {
                    //Add a 2 seconds delay before retry
                    try await Task.sleep(nanoseconds: 2_000_000_000)
                    result = self.sdkApiInstance?.sbtExecuteCommand(Int32(SBT_RSM_ATTR_GET),aInXML: inXML, aOutXML: &outXml,forScanner: scannerId)
                    if (result != SBT_RESULT_SUCCESS) {
                        retryCount += 1
                    } else {
                        retryCount = 0
                    }
                }
            } while retryCount != 0 && retryCount < 3
        }
        if (result == SBT_RESULT_SUCCESS) {
            retryCount = 0
            attributeList = self.parseOutXml(xmlContent: outXml as String)
        }
        return attributeList
    }
    
    /// Method to get all attribute values for the scanner id
    /// - Parameters:
    ///   - scannerId: Id of the scanner
    /// - Returns: list of attribute details
    func getAllAttributes(scannerId: Int32) -> [String] {
        var attributeList = [String]()
        let inXML:String = "<inArgs><scannerID>\(scannerId)</scannerID></inArgs>"
        var outXml:NSMutableString! = NSMutableString()
        
        let result = self.sdkApiInstance?.sbtExecuteCommand(Int32(SBT_RSM_ATTR_GETALL),aInXML: inXML, aOutXML: &outXml,forScanner: scannerId)
        if (result == SBT_RESULT_SUCCESS) {
            let tempArrayList = parseOutXml(xmlContent: outXml as String)
            for attribute in tempArrayList {
                attributeList.append(attribute.attributeIdGetAll)
            }
        }
        
        return attributeList
    }
    
    
    /// Method to set the attribute value for given attribute id and scanner id
    /// - Parameters:
    ///   - attributeId: Id of the attribute
    ///   - attributeValue: New input value for the attribute
    ///   - attributeDataType: Data type of the attribute
    ///   - scannerId: Id of the scanner
    func setAttributeValue(attributeId: Int32, attributeValue: String, attributeDataType: String, scannerId: Int32) {
        
        let inXML:String = "<inArgs><scannerID>\(scannerId)</scannerID><cmdArgs><arg-xml><attrib_list><attribute><id>\(attributeId)</id><datatype>\(attributeDataType)</datatype><value>\(attributeValue)</value></attribute></attrib_list></arg-xml></cmdArgs></inArgs>"
        sdkApiInstance?.sbtExecuteCommand(Int32(SBT_RSM_ATTR_SET),aInXML: inXML, aOutXML: nil,forScanner: scannerId)
    }
    
    /// Method to store the attribute value for given attribute id and scanner id
    /// - Parameters:
    ///   - attributeId: Id of the attribute
    ///   - attributeValue: New input value for the attribute
    ///   - attributeDataType: Data type of the attribute
    ///   - scannerId: Id of the scanner
    func storeAttributeValue(attributeId: Int32, attributeValue: String, attributeDataType: String, scannerId: Int32) {
        
        let inXML:String = "<inArgs><scannerID>\(scannerId)</scannerID><cmdArgs><arg-xml><attrib_list><attribute><id>\(attributeId)</id><datatype>\(attributeDataType)</datatype><value>\(attributeValue)</value></attribute></attrib_list></arg-xml></cmdArgs></inArgs>"
        sdkApiInstance?.sbtExecuteCommand(Int32(SBT_RSM_ATTR_STORE),aInXML: inXML, aOutXML: nil,forScanner: scannerId)
    }
    
    
    /// Method to perform actions on scanner
    /// - Parameters:
    ///   - actionValue: Value of the performing action
    ///   - scannerId: Id of the Scanner
    func setAction(actionValue: Int, scannerId: Int32) {
        let inXML:String = "<inArgs><scannerID>\(scannerId)</scannerID><cmdArgs><arg-int>\(actionValue)</arg-int></cmdArgs></inArgs>"
        sdkApiInstance?.sbtExecuteCommand(Int32(SBT_SET_ACTION),aInXML: inXML, aOutXML: nil,forScanner: scannerId)
    }
    
    /// Method to call SSI command to perform beeper action on scanners where set action commands doesn't work (Ex: CS4070)
    /// - Parameters:
    ///   - actionValue: Value of the performing action
    ///   - scannerId: Id of the Scanner
    func performBeepControl(actionValue: Int, scannerId: Int32) {
        sdkApiInstance?.sbtBeepControl(Int32(actionValue),forScanner: scannerId)
    }
    
    /// Method for parsing the outxml
    /// - Parameter xmlContent: String outXML content
    /// - Returns: AttributeDetail type array with attribute id and value
    func parseOutXml(xmlContent: String) -> [AttributeDetail]{
        let xmlData = Data(xmlContent.utf8)
        let parser = OutXmlParser()
        let xmlParser = XMLParser(data: xmlData)
        xmlParser.delegate = parser
        xmlParser.parse()
        return parser.attributeList
    }
    /// Method to call SSI command to perform led action on scanners where set action commands doesn't work (Ex: CS4070)
    /// - Parameters:
    ///   --  ledEnable:  boolean value for turn on or off the led
    ///   - ledCode: Value of the performing led action
    ///   - scannerId: Id of the Scanner
    func performLedControl(ledEnable: Bool,ledCode: Int, scannerId: Int32) {
        sdkApiInstance?.sbtLedControl(ledEnable, aLedCode:Int32(ledCode), forScanner: scannerId)
    }
    
    
    /// Method to call execute command to perform trigger pull and release
    /// - Parameters:
    ///   - command: trigger pull command or trigger release command (SBT_DEVICE_PULL_TRIGGER || SBT_DEVICE_RELEASE_TRIGGER)
    ///   - scannerId: Id of the Scanner
    func performTriggerPullandRelease(command: Int, scannerId: Int32) {
        let inXML:String = "<inArgs><scannerID>\(scannerId)</scannerID></inArgs>"
        sdkApiInstance?.sbtExecuteCommand(Int32(command),aInXML: inXML, aOutXML: nil,forScanner: scannerId)
    }
    
    /// Method to call execute command to perform aim on and off
    /// - Parameters:
    ///   - command: aim on command or aim off command (SBT_DEVICE_AIM_ON || SBT_DEVICE_AIM_OFF)
    ///   - scannerId: Id of the Scanner
    func performAimOnAndOff(command: Int, scannerId: Int32) {
        let inXML:String = "<inArgs><scannerID>\(scannerId)</scannerID></inArgs>"
        sdkApiInstance?.sbtExecuteCommand(Int32(command),aInXML: inXML, aOutXML: nil,forScanner: scannerId)
    }
    
    
    /// Method to call execute  command to perform device vibration
    /// - Parameter scannerId: Id of the scanner
    /// - Returns: SBT_RESULT_SUCCESS if command is successful otherwise SBT_RESULT_FAILURE
    func performVibrationFeedback(scannerId: Int32) -> SBT_RESULT {
        let inXML:String = "<inArgs><scannerID>\(scannerId)</scannerID></inArgs>"
        return sdkApiInstance?.sbtExecuteCommand(Int32(SBT_DEVICE_VIBRATION_FEEDBACK),aInXML: inXML, aOutXML: nil,forScanner: scannerId) ?? SBT_RESULT_FAILURE
    }
    
    /// Method to call  command to enable/disable discovery mode
    /// - Parameter discovery: boolean enable = true, disable = false
    func enableScannerDiscovery(discovery: Bool){
        sdkApiInstance?.sbtEnableBluetoothScannerDiscovery(discovery)
    }
    
    /// Method to call  command to enable/disable scanner detection
    /// - Parameter detection: boolean enable = true, disable = false
    func enableScannerDetection(detection: Bool){
        sdkApiInstance?.sbtEnableAvailableScannersDetection(detection)
    }
    
    /// Method to enable or disable "Automatic Session Reestablishment" for a specific scanner
    /// - Parameters:
    ///   - enable: boolean value to enable or disable
    ///   - scannerId: Id of the Scanner
    func autoReconnectionEstablishement(enable: Bool, scannerId: Int32) {
        sdkApiInstance?.sbtEnableAutomaticSessionReestablishment(enable, forScanner: scannerId)
    }
    
    /// Method to connect scanner using device id
    /// - Parameter scannerId: Id of the scanner
    func connectToScanner(scannerId: Int32) {
        // When attempting to connect to a different scanner than the one that is already connected
        if (appState.connectedScanner?.active ?? false && appState.connectedScanner?.scannerId  != scannerId)
        {
            disconnectScanner(scannerId: scannerId)
        }
        
        // Establish connection with the new scanner
        let result: SBT_RESULT = sdkApiInstance?.sbtEstablishCommunicationSession(scannerId) ?? SBT_RESULT_FAILURE
        if result == SBT_RESULT_FAILURE {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                AppState.shared.connectionInProgress = false
                AppState.shared.connectionFailed = true
            }
        }
    }
    
    /// Method to enable or disable barcode scanning of a scanner
    /// - Parameters:
    ///   - command: command for scan enable or disable
    ///   - scannerId: Id of the scanner
    func performScanEnableDisable(command: Int, scannerId: Int32) {
        let inXML:String = "<inArgs><scannerID>\(scannerId)</scannerID></inArgs>"
        sdkApiInstance?.sbtExecuteCommand(Int32(command),aInXML: inXML, aOutXML: nil,forScanner: scannerId)
    }
    
    /// Method to execute fimware update
    /// - Parameters:
    ///   - selectedFilePath: file path of the selected firmware file
    ///   - firmwareUpdateCommand: command for firmware update whether it is a plugin or dat file
    ///   - scannerId: Id of the scanner
    /// - Returns: SBT_RESULT_SUCCESS if command is successful otherwise SBT_RESULT_FAILURE
    func performFirmwareUpdate (selectedFilePath: String, firmwareUpdateCommand: Int, scannerId: Int32) -> SBT_RESULT {
        let inXML:String = "<inArgs><scannerID>\(scannerId)</scannerID><cmdArgs><arg-string>\(selectedFilePath)</arg-string></cmdArgs></inArgs>"
        return sdkApiInstance?.sbtExecuteCommand(Int32(firmwareUpdateCommand),aInXML: inXML, aOutXML: nil,forScanner: scannerId) ?? SBT_RESULT_FAILURE
    }
    
    /// Method to start new firmware after firmware update
    /// - Parameter scannerId: Id of the scanner
    /// - Returns: SBT_RESULT_SUCCESS if command is successful otherwise SBT_RESULT_FAILURE
    func startNewFirmware(scannerId: Int32) -> SBT_RESULT {
        let inXML:String = "<inArgs><scannerID>\(scannerId)</scannerID></inArgs>"
        return sdkApiInstance?.sbtExecuteCommand(Int32(SBT_START_NEW_FIRMWARE),aInXML: inXML, aOutXML: nil,forScanner: scannerId) ?? SBT_RESULT_FAILURE
    }
    
    
    /// Method to abort firmware update while firmware update is in progress
    /// - Parameter scannerId: Id of the scanner
    /// - Returns: SBT_RESULT_SUCCESS if command is successful otherwise SBT_RESULT_FAILURE
    func abortFirmwareUpdate(scannerId: Int32) -> SBT_RESULT {
        let inXML:String = "<inArgs><scannerID>\(scannerId)</scannerID></inArgs>"
        return sdkApiInstance?.sbtExecuteCommand(Int32(SBT_DEVICE_ABORT_UPDATE_FIRMWARE),aInXML: inXML, aOutXML: nil,forScanner: scannerId) ?? SBT_RESULT_FAILURE
    }
    
    /// Method to enable or disable virtual tether of a scanner
    /// - Parameters:
    ///   - command: command for virtual tether enable or disable
    ///   - scannerId: Id of the scanner
    ///   - Returns: SBT_RESULT_SUCCESS if command is successful otherwise SBT_RESULT_FAILURE
    func enableDisableVirualTether(command: Int, scannerId: Int32) -> SBT_RESULT  {
        let inXML:String = "<inArgs><scannerID>\(scannerId)</scannerID><cmdArgs><arg-xml><attrib_list><attribute><id>\(Constants.RmdAttribute.RMD_ATTR_VIRTUAL_TETHER_ALARM_STATUS)</id><datatype>B</datatype><value>\(command)</value></attribute></attrib_list></arg-xml></cmdArgs></inArgs>";
        return sdkApiInstance?.sbtExecuteCommand(Int32(SBT_RSM_ATTR_STORE),aInXML: inXML, aOutXML: nil,forScanner: scannerId) ?? SBT_RESULT_FAILURE
    }

    /// Method to start and stop virtual tether simulation action of a scanner
    /// - Parameters:
    ///   - command: command for virtual tether simulation start or stop
    ///   - scannerId:Id of the scanner
    func startStopVirtualTetherSimulation(command: Int, scannerId: Int32) {
        DispatchQueue.background(background:{
            self.setAction(actionValue: command, scannerId: scannerId)
        })
    }
    
    ///Method to create the symbology list
    func createSymbologyList() {
        /// checking symbolgylist size to create the symbology list only one time
        if (self.symbologyList.isEmpty) {
            symbologyList = [
                .init(name: "UPC-A", RMDAttributeId: Int(RMD_ATTR_SYM_UPC_A)),
                .init(name: "UPC-E" , RMDAttributeId: Int(RMD_ATTR_SYM_UPC_E)),
                .init(name: "UPC-E1" , RMDAttributeId: Int(RMD_ATTR_SYM_UPC_E_1)),
                .init(name: "EAN-8/JAN8" , RMDAttributeId: Int(RMD_ATTR_SYM_EAN_8_JAN_8)),
                .init(name: "EAN-13/JAN13" , RMDAttributeId: Int(RMD_ATTR_SYM_EAN_13_JAN_13)),
                .init(name: "Bookland EAN" , RMDAttributeId: Int(RMD_ATTR_SYM_BOOKLAND_EAN)),
                .init(name: "Code 128" , RMDAttributeId: Int(RMD_ATTR_SYM_CODE_128)),
                .init(name: "GS1-128" , RMDAttributeId: Int(RMD_ATTR_SYM_UCC_EAN_128)),
                .init(name: "Code 39" , RMDAttributeId: Int(RMD_ATTR_SYM_CODE_39)),
                .init(name: "Code 93" , RMDAttributeId: Int(RMD_ATTR_SYM_CODE_93)),
                .init(name: "Code 11" , RMDAttributeId: Int(RMD_ATTR_SYM_CODE_11)),
                .init(name: "Interleaved 2 of 5" , RMDAttributeId: Int(RMD_ATTR_SYM_INTERLEAVED_2_OF_5)),
                .init(name: "Discrete 2 of 5" , RMDAttributeId: Int(RMD_ATTR_SYM_DISCRETE_2_OF_5)),
                .init(name: "Chinese 2 of 5" , RMDAttributeId: Int(RMD_ATTR_SYM_CHINESE_2_OF_5)),
                .init(name: "Codabar" , RMDAttributeId: Int(RMD_ATTR_SYM_CODABAR)),
                .init(name: "MSI" , RMDAttributeId: Int(RMD_ATTR_SYM_MSI)),
                .init(name: "Data Matrix" , RMDAttributeId: Int(RMD_ATTR_SYM_DATAMATRIXQR)),
                .init(name: "PDF" , RMDAttributeId: Int(RMD_ATTR_SYM_PDF)),
                .init(name: "ISBT 128" , RMDAttributeId: Int(RMD_ATTR_SYM_ISBT_128)),
                .init(name: "UCCCouponExtendedCode" , RMDAttributeId: Int(RMD_ATTR_UCC_COUPEN_EXTENDED_CODE)),
                .init(name: "US Postnet" , RMDAttributeId: Int(RMD_ATTR_SYM_US_Postnet)),
                .init(name: "US Planet" , RMDAttributeId: Int(RMD_ATTR_SYM_US_Planet)),
                .init(name: "UKPost" , RMDAttributeId: Int(RMD_ATTR_SYM_UK_POST)),
                .init(name: "USPostal Check Digit" , RMDAttributeId: Int(RMD_ATTR_SYM_US_POSTAL_CHECK_DIGIT)),
                .init(name: "UKPostal Check Digit" , RMDAttributeId: Int(RMD_ATTR_SYM_UK_POSTAL_CHECK_DIGIT)),
                .init(name: "JapanPost" , RMDAttributeId: Int(RMD_ATTR_SYM_JAPAN_POST)),
                .init(name: "AusPost" , RMDAttributeId: Int(RMD_ATTR_SYM_AUS_POST)),
                .init(name: "GS1DataBar14" , RMDAttributeId: Int(RMD_ATTR_SYM_GS1_DATABAR_14)),
                .init(name: "GS1DataBarLimited" , RMDAttributeId: Int(RMD_ATTR_SYM_GS1_DATABAR_LIMITED)),
                .init(name: "GS1DataBarExpanded" , RMDAttributeId: Int(RMD_ATTR_SYM_GS1_DATABAR_EXPANDED)),
                .init(name: "MicroPDF" , RMDAttributeId: Int(RMD_ATTR_SYM_MICRO_PDF)),
                .init(name: "MaxiCode" , RMDAttributeId: Int(RMD_ATTR_SYM_MAXI_CODE)),
                .init(name: "ISSN EAN" , RMDAttributeId: Int(RMD_ATTR_ISSN_EAN)),
                .init(name: "Matrix 2 of 5" , RMDAttributeId: Int(RMD_ATTR_MATRIX_2_OF_5)),
                .init(name: "Korean 3 of 5" , RMDAttributeId: Int(RMD_ATTR_KOREAN_3_OF_5)),
                .init(name: "QR Code" , RMDAttributeId: Int(RMD_ATTR_QR_CODE)),
                .init(name: "Micro QR Code" , RMDAttributeId: Int(RMD_ATTR_MICRO_QR)),
                .init(name: "Aztec" , RMDAttributeId: Int(RMD_ATTR_AZTEC)),
                .init(name: "HanXin" , RMDAttributeId: Int(RMD_ATTR_HANXIN)),
                .init(name: "Composite CC-C" , RMDAttributeId: Int(RMD_ATTR_COMPOSITE_CC_C)),
                .init(name: "Composite CC-A/B" , RMDAttributeId: Int(RMD_ATTR_COMPOSITE_CC_A_B)),
                .init(name: "Composite TLC-39" , RMDAttributeId: Int(RMD_ATTR_COMPOSITE_TLC_39)),
                .init(name: "Netherlands KIX" , RMDAttributeId: Int(RMD_ATTR_SYM_Netherlands_KIX)),
                .init(name: "UPU FICS" , RMDAttributeId: Int(RMD_ATTR_SYM_UPU_FICS))
            ]
        }
    }
    
    ///Method to get the details(enable/disable) for each symbology
    func retrieveSymbologyDetails() {
        self.createSymbologyList()
        /// Make temporary copy of the original list to stop altering the original list
        var tempSymbologyList = symbologyList
        /// Empty list for new list with enable/disable status
        var supportedSymbologyList : [Symbology] = []
        /// Create an attibute Id list from the symbology list
        let attributeIdList = tempSymbologyList.map{ Int32($0.RMDAttributeId)}
        let attributeDetailList = ZebraSDKManager.shared.getAttributeValues(attributeIdList: attributeIdList, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
        
        /// Altering the items of the temporary list with enable/disable status and adding them to a new list to filter the supported scanners
        attributeDetailList.indices.forEach { index in
            tempSymbologyList[index].enabled = attributeDetailList[index].attributeValue == "TRUE" ? true : false
            supportedSymbologyList.append(tempSymbologyList[index])
        }
        
        DispatchQueue.main.async {
            AppState.shared.loading = false
            AppState.shared.symbologyList = supportedSymbologyList
        }

    }
    
    /// Method to enable or disable auto connection on app relaunch of a BLE scanner
    func autoConnectOnAppRelaunch(enable: Bool) {
        sdkApiInstance?.sbtAutoConnectToLastConnectedScanner(onAppRelaunch: enable)
    }
    

    
    //MARK: Scanner Events ------------------------------------------------------
    
    /// scanner appear event
    func sbtEventScannerAppeared(_ availableScanner: SbtScannerInfo!) {
        
        let scannerInfo = ScannerInfo(
            scannerId: availableScanner.getScannerID(),
            connectionType: availableScanner.getConnectionType(),
            autoCommunicationSessionReestablishment: availableScanner.getAutoCommunicationSessionReestablishment(),
            active: availableScanner.isActive(),
            available: availableScanner.isAvailable(),
            isStcConnected: availableScanner.isStcConnected(),
            scannerName: availableScanner.getScannerName(),
            scannerModel: availableScanner.getScannerModel())
        
        addScannerToAvailableList(scanner: scannerInfo)
    }
    
    /// scanner disappear event
    func sbtEventScannerDisappeared(_ scannerID: Int32) {
        removeScannerFromAvailableList(scannerId: scannerID)
    }
    
    /// communication session establishment event
    func sbtEventCommunicationSessionEstablished(_ activeScanner: SbtScannerInfo!) {
        
        let scannerInfo = ScannerInfo(scannerId: activeScanner.getScannerID(), connectionType: activeScanner.getConnectionType(), autoCommunicationSessionReestablishment: activeScanner.getAutoCommunicationSessionReestablishment(), active: activeScanner.isActive(), available: activeScanner.isAvailable(), isStcConnected: activeScanner.isStcConnected(), scannerName: activeScanner.getScannerName(), scannerModel: activeScanner.getScannerModel())
        
        ///Already a scanner is connected
        if (self.appState.isScannerConnected && self.appState.connectedScanner != nil) {
            
            ///remove connected scanner
            self.disconnectScanner(scannerId: self.appState.connectedScanner?.scannerId ?? 0)
            
            ///save new scanner info to appstate
            ///adding a delay to slowly reflect UI change
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                
                self.appState.connectedScanner = scannerInfo
                self.appState.isScannerConnected = true
                self.appState.selectedTab = .SETTINGS
                AppState.shared.connectionInProgress = false
                
            }
            
        } else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                
                self.appState.connectedScanner = scannerInfo
                self.appState.isScannerConnected = true
                self.appState.selectedTab = .SETTINGS
                AppState.shared.connectionInProgress = false
            }
            
        }
        
        
        let lastConnectedScannerName = self.appState.lastConnectedScanner?.scannerName.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        let currentScannerName = scannerInfo.scannerName.trimmingCharacters(in: .whitespacesAndNewlines)
        if (self.appState.isFirmwareUpdated && (lastConnectedScannerName == currentScannerName)) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                self.appState.isRebootCompleted = true
                self.appState.selectedTab = .ADVANCED

            }
        }else {
            AppState.shared.isFirmwareUpdated = false
        }
        
        ///create new barcode list for connected active scanner
        createScannerBarcodeDataList(activeScanner: scannerInfo)
        
        
    }
    
    ///Create new scanner barcode data list to store scanned data
    func createScannerBarcodeDataList(activeScanner: ScannerInfo) {
        
        if !self.appState.scannerBarcodeList.contains(where: { $0.scannerId == activeScanner.scannerId }) {
            let scannerData = BarcodeList(scannerId: activeScanner.scannerId, scannerName: activeScanner.scannerName, listOfBarcodes: [])
            DispatchQueue.main.async {
                self.appState.scannerBarcodeList.append(scannerData)
            }
        }
    }
    
    /// communication session terminated event
    func sbtEventCommunicationSessionTerminated(_ scannerID: Int32) {
        
        DispatchQueue.main.async() {
            if (self.appState.connectedScanner?.scannerId == scannerID) {
                self.appState.lastConnectedScanner = self.appState.connectedScanner
                self.appState.connectedScanner = nil
                self.appState.selectedTab = .BLE
                self.appState.isScannerConnected = false
                
                ///remove barcode data details of the disconnected scanner
                self.clearBarcodeDataList(scannerId: scannerID)
            }
        }
        
        // dispatched the published varibale change after a small delay to get the change on "onChange" modifier in the view
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
            AppState.shared.showAlert = true
        }
    }
    
    ///Remove the scanner data details for a scanner
    func clearBarcodeDataList(scannerId: Int32) {
        if let scannerDataIndex = self.appState.scannerBarcodeList.firstIndex(where: { $0.scannerId == scannerId}) {
            self.appState.scannerBarcodeList.remove(at: scannerDataIndex)
        }
    }
    
    /*
     barcode data is received as a String
     this event is deprecated and use sbtEventBarcodeData event instead
     */
    func sbtEventBarcode(_ barcodeData: String!, barcodeType: Int32, fromScanner scannerID: Int32) {
        
    }
    
    //barcode data is received as Data
    func sbtEventBarcodeData(_ barcodeData: Data!, barcodeType: Int32, fromScanner scannerID: Int32) {
        
        /// Add new barcode to barcode list of specified scanner
        if let scannerDataIndex = self.appState.scannerBarcodeList.firstIndex(where: { $0.scannerId == scannerID}) {
            let newBarcodeData = BarcodeData(barcodeType: barcodeType, barcodeData: barcodeData)
            self.appState.scannerBarcodeList[scannerDataIndex].listOfBarcodes.append(newBarcodeData)
        }
        
        //TBD: Handle event in background mode
        if (self.appState.selectedTab != .DATA_VIEW) {
            self.appState.selectedTab = .DATA_VIEW
        }
        
    }
    
    /// firmware update event
    func sbtEventFirmwareUpdate(_ fwUpdateEventObj: FirmwareUpdateEvent!) {
        
        if (!appState.firmwareUpdateDidStop) {
            DispatchQueue.main.async { [weak self] in
                
                let progressValue = (Float(fwUpdateEventObj.currentRecord) / Float(fwUpdateEventObj.maxRecords) * 100)
                self?.appState.progressOfFirmwareUpdate = progressValue
            }
        }
    }
    
    /*
     image data received event
     */
    func sbtEventImage(_ imageData: Data!, fromScanner scannerID: Int32) {
        
    }
    
    /*
     video data received event
     */
    func sbtEventVideo(_ videoFrame: Data!, fromScanner scannerID: Int32) {
        
    }
    
    func sbtEventTrigger(_ triggerState: SBT_TRIGGER_STATE, fromScanner scannerID: Int32) {
        
    }
    
}
