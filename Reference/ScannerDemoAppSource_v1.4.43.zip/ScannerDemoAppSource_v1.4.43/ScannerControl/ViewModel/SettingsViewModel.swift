//
//  SettingsViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation


extension SettingsView {
    
    ///ViewModel for publishing UI updates to SettingsView
    ///
    /// - Returns : ObservableObject with published properties
    ///
    @MainActor class ViewModel: ObservableObject {
        @Published var picklistModeSetting: Bool = false
        @Published var autoReconnectionEnabled: Bool = false
        @Published var parameterBarcodeDisabled: Bool = false
        var timerTask: Timer?

        let alertDetails = AlertDetails(alertType: .connected)
        
        init() {
            //Display connection successful message after connection
            DispatchQueue.main.async {
                AppState.shared.showAlert = true
            }
            timerTask = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(setDefaultSettings), userInfo: nil, repeats: false)

        }
        
        /// Method to get and set default settings for the  scanner  settings screen
        @objc func setDefaultSettings() {
            getPickListMode()
            /// disable the fast blink if it is on
            ZebraSDKManager.shared.setAction(actionValue: Int(RMD_ATTR_VALUE_ACTION_FAST_BLINK_OFF), scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            
            self.getAutoReconnectStatus()
            self.setParameterBarcodeScanningStatus(disabled: true)
        }
        
        
        /// Method for pulling scanner trigger
        func pullTrigger() {
            ZebraSDKManager.shared.performTriggerPullandRelease(command: SBT_DEVICE_PULL_TRIGGER, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
        }
        
        /// Method for releasing scanner trigger
        func releaseTrigger() {
            ZebraSDKManager.shared.performTriggerPullandRelease(command: SBT_DEVICE_RELEASE_TRIGGER, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
        }
        
        /// Method for turning on the aim for scanner
        func aimOn() {
            ZebraSDKManager.shared.performAimOnAndOff(command: SBT_DEVICE_AIM_ON, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
        }
        
        /// Method for turning off the aim for scanner
        func aimOff() {
            ZebraSDKManager.shared.performAimOnAndOff(command: SBT_DEVICE_AIM_OFF, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
        }
        
        ///Method to get the picklist mode of the scanner
        func getPickListMode() {
            let attributeList = ZebraSDKManager.shared.getAttributeValues(attributeIdList: [Int32(Constants.RmdAttribute.RMD_ATTR_PICKLIST_MODE)], scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            if (attributeList.count > 0) {
                let picklistModeValue = Int(attributeList[0].attributeValue)
                picklistModeSetting = picklistModeValue == 2 ? true : false
            }
        }
        
        ///Method to set the picklist mode of the scanner
        func setPickListMode() {
            let picklistModeValue = picklistModeSetting ? 2 : 0
            ZebraSDKManager.shared.setAttributeValue(attributeId: Int32(Constants.RmdAttribute.RMD_ATTR_PICKLIST_MODE), attributeValue: String(picklistModeValue), attributeDataType: "B", scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            ///Retrive the updated value
            getPickListMode()
        }
        
        ///Method to set the auto reconnection status of the scanner
        func setAutoReconnectStatus(enable: Bool) {
            let autoReconnectionValue = enable ? 2 : 0
            ZebraSDKManager.shared.storeAttributeValue(attributeId: Int32(RMD_ATTR_VALUE_AUTO_RECONNECT), attributeValue: String(autoReconnectionValue), attributeDataType: "B", scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            ///Retrive the updated value
            getAutoReconnectStatus()
        }
        
        ///Method to set the parameter barcode scanning status of the scanner
        func setParameterBarcodeScanningStatus(disabled: Bool) {
            let parameterBarcodeValue = disabled ? "FALSE" : "TRUE"
            ZebraSDKManager.shared.storeAttributeValue(attributeId: Int32(RMD_ATTR_VALUE_PARAMETER_BARCODE), attributeValue: parameterBarcodeValue, attributeDataType: "F", scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            ///Retrive the updated value
            getParameterBarcodeScanningStatus()
        }
        
        ///Method to get the auto reconnection status of the scanner
        func getAutoReconnectStatus() {
            let attributeList = ZebraSDKManager.shared.getAttributeValues(attributeIdList: [Int32(RMD_ATTR_VALUE_AUTO_RECONNECT)], scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            if (attributeList.count > 0) {
                let autoReconnectionValue = Int(attributeList[0].attributeValue)
                autoReconnectionEnabled = autoReconnectionValue == 2 ? true : false
            }
            
            /// update the auto reconnetion status in the SDK based on the scanner status
            ZebraSDKManager.shared.autoReconnectionEstablishement(enable: autoReconnectionEnabled, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            
        }
        
        ///Method to get the parameter barcode scanning status of the scanner
        func getParameterBarcodeScanningStatus() {
            let attributeList = ZebraSDKManager.shared.getAttributeValues(attributeIdList: [Int32(RMD_ATTR_VALUE_PARAMETER_BARCODE)], scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            if (attributeList.count > 0) {
                let parameterBarcodeValue = attributeList[0].attributeValue
                parameterBarcodeDisabled = parameterBarcodeValue == "TRUE" ? false : true
            }
        }
    }
}
