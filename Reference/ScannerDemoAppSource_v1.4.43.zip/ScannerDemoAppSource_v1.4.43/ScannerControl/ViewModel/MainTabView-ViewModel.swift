//
//  MainTabView-ViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation
import SwiftUI



extension MainTabView {
    
    @MainActor class ViewModel : ObservableObject{
        let alertDetails = AlertDetails(alertType: .disableMsg)
        
        init() {
            /// Adding custom color to the nav bar
            let navBarAppearance = UINavigationBarAppearance()
            navBarAppearance.configureWithOpaqueBackground()
            navBarAppearance.titleTextAttributes = [.foregroundColor: UIColor.white]
            navBarAppearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
            navBarAppearance.backgroundColor = Asset.blueColor.color
            navBarAppearance.backgroundImage = UIImage()
            navBarAppearance.shadowImage = UIImage()
            navBarAppearance.shadowColor = .clear
            UINavigationBar.appearance().standardAppearance = navBarAppearance
            UINavigationBar.appearance().scrollEdgeAppearance = navBarAppearance
            
            /// Back button settings for nav bar
            let backItemAppearance = UIBarButtonItemAppearance()
            backItemAppearance.normal.titleTextAttributes = [.foregroundColor : UIColor.white]
            navBarAppearance.backButtonAppearance = backItemAppearance
            let image = UIImage(systemName: "chevron.backward")?.withTintColor(.white, renderingMode: .alwaysOriginal)
            navBarAppearance.setBackIndicatorImage(image, transitionMaskImage: image)
            
            /// Adding custom colors to the tab bar
            let tabBarAppearance = UITabBarAppearance()
            tabBarAppearance.backgroundColor = Asset.tabBarColor.color
            UITabBar.appearance().standardAppearance = tabBarAppearance
            UITabBar.appearance().scrollEdgeAppearance = tabBarAppearance
            
        }
    }
}



