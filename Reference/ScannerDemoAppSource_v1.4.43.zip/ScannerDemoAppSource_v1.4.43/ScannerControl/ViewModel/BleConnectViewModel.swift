//
//  BleConnectViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.
//

import Foundation
import SwiftUI

extension BleConnectView {
    
    ///ViewModel for publishing UI updates to BleConnectView
    ///
    /// - Returns : ObservableObject with below published properties
    /// - Property currentSetting : Selected setting for the pairing barcode generation (Set Factory Defaults/ Keep current Setting)
    /// - Property stcBarcode : Generated barcode UIImage
    /// - Property orientation : Current orientation of the device
    ///
    @MainActor class ViewModel: ObservableObject {
        
        @Published var currentSetting: String?
        @Published var stcBarcodeImage: UIImage = UIImage()
        let screenWidth = UIScreen.main.bounds.width
        let screenHeight = UIScreen.main.bounds.height
        @Published var isLandscapeMode: Bool = UIDevice.current.orientation.isLandscape
        @Published var orientation: UIDeviceOrientation = UIDevice.current.orientation {
            didSet {
                if (orientation.isPortrait) {
                    self.isLandscapeMode = false
                    var imageWidth : CGFloat
                    var imageHeight : CGFloat
                    ///When the initial screen width,height measure was done while in portrait mode
                    if (screenWidth < screenHeight) {
                        imageWidth = screenWidth * 0.7
                        imageHeight = screenHeight * 0.2
                    } else {
                        imageWidth = screenHeight * 0.7
                        imageHeight = screenWidth * 0.2
                    }
                    getSTCPairingBarcode(imageWidth: imageWidth, imageHeight: imageHeight)
                } else if (orientation.isLandscape) {
                    self.isLandscapeMode = true
                    var imageWidth : CGFloat
                    var imageHeight : CGFloat
                    ///When the initial screen width,height measure was done while in landscape mode
                    if (screenWidth > screenHeight) {
                        imageWidth = screenWidth * 0.63
                        imageHeight = screenHeight * 0.2
                    } else {
                        imageWidth = screenHeight * 0.63
                        imageHeight = screenWidth * 0.2
                    }
                    getSTCPairingBarcode(imageWidth: imageWidth, imageHeight: imageHeight)
                }
            }
        }
        
        let alertDetails = AlertDetails(alertType: .disconnected)
        
        ///Change the ui text based on the selected setting for set factory defaults
        func getTextBasedOnFactoryDefaultSetting() {
            if AppSettings.shared.setFactoryDefaults {
                self.currentSetting = L10n.BtLe.setFactoryDefaultsText
            } else {
                self.currentSetting = L10n.BtLe.keepCurrentSettingsText
            }
        }
        
        ///Generate the STC pairing barcode with the selected settings and imageview dimensions
        ///
        /// - Parameter imageWidth: Width for the resulting paring barcode image
        /// - Parameter imageHeight: Height for the reulting pairing barcode image
        ///
        func getSTCPairingBarcode(imageWidth: Double, imageHeight: Double) {
            self.stcBarcodeImage = ZebraSDKManager.shared.getSTCPairingBarcode(setDefaultsStatus: AppSettings.shared.setFactoryDefaults ? SETDEFAULT_YES : SETDEFAULT_NO,imageView: UIImageView(frame: CGRect(x: 0, y: 0, width: imageWidth, height: imageHeight)))
            
        }
        
    }
}
