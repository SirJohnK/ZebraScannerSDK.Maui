//
//  DataViewViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation
import CoreImage
import SwiftUI

extension DataView {
    
    ///ViewModel for publishing UI updates to DataView
    ///
    /// - Returns : ObservableObject with published properties
    ///
    @MainActor class ViewModel: ObservableObject {
        
        @Published var barcodeDataList : [BarcodeData] = []
        @Published var selectedBarcodeData: BarcodeData?
        var sampleBarcodes = [SampleBarcodeType.UPC,SampleBarcodeType.CODE_128,SampleBarcodeType.DATAMATRIX]
        @Published var selectedSampleBarcode: SampleBarcodeType = .UPC
        @Published var barcodeImage: UIImage?
        
        ///Method to get barcode data from barcode list
        func getBarcodeData() {
            let scannerId = AppState.shared.connectedScanner?.scannerId
            if let scannerDataIndex = AppState.shared.scannerBarcodeList.firstIndex(where: { $0.scannerId == scannerId}) {
                self.barcodeDataList = AppState.shared.scannerBarcodeList[scannerDataIndex].getBarcodeList()
            }
            
        }
        
        ///Method to clear the barcode list
        func clearList() {
            let scannerId = AppState.shared.connectedScanner?.scannerId
            if let scannerDataIndex = AppState.shared.scannerBarcodeList.firstIndex(where: { $0.scannerId == scannerId}) {
                AppState.shared.scannerBarcodeList[scannerDataIndex].clearBarcodeList()
            }
        }
        
        ///Get sample barcode image based on given barcode type
        func getBarcodeImage(barcodeType: SampleBarcodeType) {
            switch(barcodeType)  {
            case .UPC:
                self.barcodeImage = Asset.upc.image
                break
            case .CODE_128:
                self.barcodeImage = Asset.code128.image
                break
            case .DATAMATRIX:
                self.barcodeImage = Asset.dataMatrix.image
                break
            }
        }
                
    }
}
