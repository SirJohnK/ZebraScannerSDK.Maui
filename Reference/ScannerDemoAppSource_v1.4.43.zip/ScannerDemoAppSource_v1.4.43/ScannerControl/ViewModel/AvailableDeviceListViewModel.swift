//
//  AvailableDeviceListViewModel.swift
//  ScannerControl
//
//   ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation


extension AvailableDeviceListView {
    
    ///ViewModel for publishing UI updates to AvailableDeviceListView
    ///
    /// - Returns : ObservableObject with published properties
    ///
    
    @MainActor class ViewModel: ObservableObject {
        
        @Published var lastConnectedOrCurrentConnectedScaner: ScannerInfo?
        @Published var otherScannersList: [ScannerInfo] = []
        
        //Method to get available scanners
        func getOtherScannerList() {
            
            if let scanner = lastConnectedOrCurrentConnectedScaner {
                
                otherScannersList = AppState.shared.availableScannerList.filter{$0.scannerId != scanner.scannerId}
                
            }else{
                otherScannersList = AppState.shared.availableScannerList
            }
        }
        
        //Method for updating published properties based on App state properties
        func LoadScannerList() {
            
            if (AppState.shared.isScannerConnected){
                lastConnectedOrCurrentConnectedScaner = AppState.shared.connectedScanner
            }else if (AppState.shared.lastConnectedScanner != nil){
                lastConnectedOrCurrentConnectedScaner = AppState.shared.lastConnectedScanner
            }
            
            getOtherScannerList()
            
        }
    }
}
