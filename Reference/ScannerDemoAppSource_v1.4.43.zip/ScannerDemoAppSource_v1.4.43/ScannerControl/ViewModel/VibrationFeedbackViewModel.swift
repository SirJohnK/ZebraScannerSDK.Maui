//
//  VibrationFeedbackViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation
import SwiftUI


extension VibrationFeedbackView {
    
    ///ViewModel for publishing UI updates to VibrationFeedbackView
    ///
    /// - Returns : ObservableObject with published properties
    /// - Property selectedDuration : Selected vibration duration setting
    /// - Property vibrationStatus : Status of the vibration
    /// - Property vibrationNotSupportedAlert : Vibration not supported alert will be shown based on this boolean value
    @MainActor class ViewModel: ObservableObject {
        
        let alertDetails = AlertDetails(alertType: .actionFailed, description: "vibration feedback")
        
        var vibrationDurationList: [VibrationDuration] = []
        @Published var selectedDuration : VibrationDuration? = nil
        @Published var vibrationStatus: Bool = false
        @Published var vibrationNotSupportedAlert: Bool = false
        
        init() {
            loadVibrationDurations()
            getVibrationStatus()
            getVibrationDuration()
        }
        
        ///Method to vibration duration list
        func loadVibrationDurations() {
            self.vibrationDurationList = [
                .init(actionValue: 15, actionName: "150"),
                .init(actionValue: 20, actionName: "200"),
                .init(actionValue: 25, actionName: "250"),
                .init(actionValue: 30, actionName: "300"),
                .init(actionValue: 40, actionName: "400"),
                .init(actionValue: 50, actionName: "500"),
                .init(actionValue: 60, actionName: "600"),
                .init(actionValue: 75, actionName: "750"),
                
                
            ]
        }
        
        ///Method to get current vibration status
        func getVibrationStatus() {
            let attributeList = ZebraSDKManager.shared.getAttributeValues(attributeIdList: [613], scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            if (attributeList.count > 0) {
                let vibrationStatusValue = attributeList[0].attributeValue
                vibrationStatus = NSString(string: vibrationStatusValue).boolValue
            }
        }
        
        ///Method to change the current vibration status
        func setVibrationStatus() {
            ZebraSDKManager.shared.setAttributeValue(attributeId: 613, attributeValue: String(vibrationStatus), attributeDataType: "F", scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
        }
        
        ///Method to perform vibration feedback
        func performVibrationFeedback() {
            setVibrationDuration()
            let result = ZebraSDKManager.shared.performVibrationFeedback(scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            if (result != SBT_RESULT_SUCCESS) {
                vibrationNotSupportedAlert = true
            }
            
        }
        
        ///Method to set the duration of the vibration
        func setVibrationDuration() {
            let vibrationDuration = selectedDuration?.actionValue
            ZebraSDKManager.shared.setAttributeValue(attributeId: Int32(Constants.RmdAttribute.RMD_ATTR_VIBRATION_DURATION), attributeValue: String(vibrationDuration ?? 15), attributeDataType: "B", scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
        }
        
        ///Method to get the current vibration duration
        func getVibrationDuration() {
            let attributeList = ZebraSDKManager.shared.getAttributeValues(attributeIdList: [Int32(Constants.RmdAttribute.RMD_ATTR_VIBRATION_DURATION)], scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            if (attributeList.count > 0) {
                let vibrationDurationValue = attributeList[0].attributeValue
                if let duration = vibrationDurationList.first(where: {String($0.actionValue) == vibrationDurationValue}) {
                   selectedDuration = duration
                }
            }
        }
        
    }
}
