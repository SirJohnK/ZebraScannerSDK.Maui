//
//  LEDControlViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation


extension LEDControlView {
    
    ///ViewModel for publishing UI updates to LEDControlView
    ///
    /// - Returns : ObservableObject with published properties
    ///
    @MainActor class ViewModel: ObservableObject {

        // these two variables are used when back navigation, to turn off if a led is on
        var selectedLedColor: LedColor?
        var selectedLedStatus: LedStatus = .off
        
        
        ///Perform LED  action
        func performLEDAction(ledColor: LedColor, ledStatus: LedStatus) {
            
            selectedLedColor = ledColor
            selectedLedStatus = ledStatus
            
            /// CS4070 firmware does not support SET ACTION commands to control LED. Use SSI commands instead.
            if (AppState.shared.connectedScanner?.scannerModel != nil && AppState.shared.connectedScanner.scannerModel.contains(Constants.ScannerDetails.SCANNER_MODEL_SSI_CS4070)){
                
                let ledEnableStatus: Bool = ledStatus == .on ? true : false
                var ledControlCode: Int = SBT_LEDCODE_GREEN
                
                switch ledColor {
                case .green:
                    ledControlCode = SBT_LEDCODE_GREEN
                case .yellow:
                    ledControlCode = SBT_LEDCODE_AMBER
                case .red:
                    ledControlCode = SBT_LEDCODE_RED
                }
                
                ZebraSDKManager.shared.performLedControl(ledEnable: ledEnableStatus, ledCode: ledControlCode, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
                
            } else { // for other scanners
                
                var ledControlCode: Int = Int(RMD_ATTR_VALUE_ACTION_LED_GREEN_ON)
                switch ledColor {
                case .green:
                    ledControlCode = ledStatus == .on ? Int(RMD_ATTR_VALUE_ACTION_LED_GREEN_ON) : Int(RMD_ATTR_VALUE_ACTION_LED_GREEN_OFF)
                    
                case .yellow:
                    ledControlCode = ledStatus == .on ? Int(RMD_ATTR_VALUE_ACTION_LED_YELLOW_ON) : Int(RMD_ATTR_VALUE_ACTION_LED_YELLOW_OFF)
                  
                case .red:
                    ledControlCode = ledStatus == .on ? Int(RMD_ATTR_VALUE_ACTION_LED_RED_ON): Int(RMD_ATTR_VALUE_ACTION_LED_RED_OFF)
                   
                }
                
                ZebraSDKManager.shared.setAction(actionValue: ledControlCode, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
                
            }
        }
        
        // turn off led if it is on when navigate back
        func turnOffLed (){
            
            if selectedLedStatus == .on {
                self.performLEDAction(ledColor: selectedLedColor!, ledStatus: .off)
            }
        }
    }
}

