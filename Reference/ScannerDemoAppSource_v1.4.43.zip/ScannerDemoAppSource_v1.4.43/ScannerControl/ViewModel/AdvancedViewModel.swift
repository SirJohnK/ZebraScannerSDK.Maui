//
//  AdvancedViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation
import SwiftUI

extension AdvancedView {
    
    ///ViewModel for publishing UI updates to AdvancedView
    ///
    /// - Returns : ObservableObject with published properties
    ///
    @MainActor class ViewModel: ObservableObject {
        
        @ObservedObject var appState = AppState.shared
        @Published var enableFindScannerButton: Bool = true
        var timerTask: Timer?
        var endTime: Date?
        
        /// Method to start the find scanner action
        func startFindScannerAction() {
            self.enableFindScannerButton = false
            self.turnOnOffLEDPattern(enable: true)
            self.beepScanner()
            self.vibrateScanner()

            endTime = Date().addingTimeInterval(3)
            timerTask = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(repeatTask), userInfo: nil, repeats: true)
            
        }
        
        /// Method to repeat the beeper and vibration
        @objc func repeatTask() {
            if Date() >= endTime ?? Date() {
                timerTask?.invalidate()
                self.turnOnOffLEDPattern(enable: false)
                self.enableFindScannerButton = true
                return
            }
            self.vibrateScanner()
            self.beepScanner()
        }
        
        
        /// Method to turn on and turn off LED pattern
        func turnOnOffLEDPattern(enable: Bool) {
            
            
            /// CS4070 firmware does not support SET ACTION commands to control LED. Use SSI commands instead.
            if (AppState.shared.connectedScanner?.scannerModel != nil && AppState.shared.connectedScanner.scannerModel.contains(Constants.ScannerDetails.SCANNER_MODEL_SSI_CS4070)){
                let ledControlCode: Int = SBT_LEDCODE_RED
                ZebraSDKManager.shared.performLedControl(ledEnable: enable, ledCode: ledControlCode, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
                
            } else { // for other scanners
                
                ZebraSDKManager.shared.setAction(actionValue: enable ? Int(RMD_ATTR_VALUE_ACTION_FAST_BLINK): Int(RMD_ATTR_VALUE_ACTION_FAST_BLINK_OFF), scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
                
            }
        }
        
        /// Method to vibrate the scanner
        func vibrateScanner() {
            _ = ZebraSDKManager.shared.performVibrationFeedback(scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
        }
        
        /// Method to beep the scanner
        func beepScanner() {
            /// CS4070 firmware does not support SET ACTION commands to control beeper. Use SSI commands instead.
            if (AppState.shared.connectedScanner?.scannerModel != nil && AppState.shared.connectedScanner.scannerModel.contains(Constants.ScannerDetails.SCANNER_MODEL_SSI_CS4070)){
                ZebraSDKManager.shared.performBeepControl(actionValue: Int(RMD_ATTR_VALUE_ACTION_HIGH_HIGH_LOW_LOW_BEEP), scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            } else {
                ZebraSDKManager.shared.setAction(actionValue: Int(RMD_ATTR_VALUE_ACTION_HIGH_HIGH_LOW_LOW_BEEP), scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            }
        }
    }
}
