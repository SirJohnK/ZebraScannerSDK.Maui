//
//  AssetInfoViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation

extension AssetInfoView {
    
    ///ViewModel for publishing UI updates to AssetInfoView
    ///
    /// - Returns : ObservableObject with published properties
    ///
    @MainActor class ViewModel: ObservableObject {
        
        @Published var scannerInfo: ScannerInfo?
                
        ///Method to get scanner information
        func getScannerInformation() {
            
            let scannerInformation = AppState.shared.connectedScanner
            
            ///Model, MFD and serial no does not chage. So getting those values only in the first time
            if (scannerInformation?.scannerModel == nil ||  scannerInformation?.serialNo == nil || scannerInformation?.dateOfManufacture == nil) {
                let attributeDetailList = ZebraSDKManager.shared.getAttributeValues(attributeIdList: [RMD_ATTR_FRMWR_VERSION,RMD_ATTR_MFD, RMD_ATTR_SERIAL_NUMBER, RMD_ATTR_MODEL_NUMBER,Int32(Constants.RmdAttribute.RMD_ATTR_CONFIG_NAME)], scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
                
                for attribute in attributeDetailList{
                    let attributeVal = attribute.attributeValue
                    
                    switch (Int32(attribute.attributeId)) {
                    case RMD_ATTR_FRMWR_VERSION:
                        AppState.shared.connectedScanner?.firmware = attributeVal
                        break
                    case RMD_ATTR_MFD:
                        AppState.shared.connectedScanner?.dateOfManufacture = attributeVal
                        break
                    case RMD_ATTR_SERIAL_NUMBER:
                        AppState.shared.connectedScanner?.serialNo = attributeVal
                        break
                    case RMD_ATTR_MODEL_NUMBER:
                        AppState.shared.connectedScanner?.scannerModel = attributeVal
                        break
                    case Int32(Constants.RmdAttribute.RMD_ATTR_CONFIG_NAME):
                        AppState.shared.connectedScanner?.configurationFileName = attributeVal
                        break
                    default:
                        AppState.shared.connectedScanner?.firmware = attributeVal
                    }
                }
                
            } else {
                let attributeDetailList = ZebraSDKManager.shared.getAttributeValues(attributeIdList: [RMD_ATTR_FRMWR_VERSION], scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
                
                for attribute in attributeDetailList{
                    let attributeVal = attribute.attributeValue
                    
                    switch (Int32(attribute.attributeId)) {
                    case RMD_ATTR_FRMWR_VERSION:
                        AppState.shared.connectedScanner?.firmware = attributeVal
                        break
                    case Int32(Constants.RmdAttribute.RMD_ATTR_CONFIG_NAME):
                        AppState.shared.connectedScanner?.configurationFileName = attributeVal
                        break
                    default:
                        AppState.shared.connectedScanner?.firmware = attributeVal
                    }
                }
            }
            
            scannerInfo = AppState.shared.connectedScanner
            
        }
        
    }

}
