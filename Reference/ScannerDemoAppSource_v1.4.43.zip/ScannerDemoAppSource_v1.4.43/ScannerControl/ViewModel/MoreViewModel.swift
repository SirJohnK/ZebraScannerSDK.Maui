//
//  SettingsViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation
import SwiftUI


extension MoreView {
    
    ///ViewModel for publishing UI updates to MoreView
    ///
    /// - Returns : ObservableObject with published properties
    ///
    @MainActor class ViewModel: ObservableObject {
        @ObservedObject var appState = AppState.shared

        let alertDetails = AlertDetails(alertType: .disconnectWithOptions)
        
        func disconnectScanner() {
            ZebraSDKManager.shared.disconnectScanner(scannerId: appState.connectedScanner?.scannerId ?? 0)
        }
        
    }
}
