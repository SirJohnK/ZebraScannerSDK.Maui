//
//  VirtualTetherViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation
import AVKit

extension VirtualTetherView {
    
    ///ViewModel for publishing UI updates to VirtualTetherView
    ///
    /// - Returns : ObservableObject with published properties
    ///
    @MainActor class ViewModel: ObservableObject {
        
        
        /// This property is for enabling/disabling  all virtual tether host feedback toggles
        @Published var enableHostFeedbackToggles: Bool = AppSettings.shared.enableHostFeedbackToggles {
            didSet {
                DispatchQueue.main.async {
                    AppSettings.shared.enableHostFeedbackToggles = self.enableHostFeedbackToggles
                }
                self.enableHostFeedback = self.enableHostFeedbackToggles
                self.virtualTetherVibration = self.enableHostFeedbackToggles
                self.virtualTetherAudioAlarm = self.enableHostFeedbackToggles
                self.virtualTetherFlashingScreen = self.enableHostFeedbackToggles
                self.virtualTetherPopupMessage = self.enableHostFeedbackToggles
            }
        }
        
        /// Toggle value for 'Enable Virtual Tether'
        @Published var enableVirtualTether: Bool = AppSettings.shared.enableVirtualTether {
            didSet {
                //Enable/Disable host feedback sliders when virtual tether is enabled/disabled
                self.enableHostFeedbackToggles = self.enableVirtualTether
                
            }
        }
        
        /// Toggle value for 'Simulate Alarm'
        @Published var simulateAlarm: Bool = false {
            didSet {
                self.validateSimulateAlarm()
            }
        }
        
        @Published var enableStopAlarmOnHostButton: Bool = false
        @Published var enableSnoozeAlarmOnScannerButton: Bool = false
        @Published var enableSimulateAlarmToggle: Bool = true
        private var isOnPause: Bool = false
        private var virtualTetherSimulationOccurred: Bool = false
        private var snoozeTimer: Timer?
        private var simulationTimer: Timer?
        private var hostFeedbackSimulationTimer: Timer?
        private var virtualTetherHostAlarmStopped: Bool = false
        private var audioPlayer: AVAudioPlayer?
        private var audioAlarmTimer: Timer?
        @Published var displayPopup: Bool = false
        
        /// Toggle value for 'Enable Host Feedback'
        @Published var enableHostFeedback: Bool = AppSettings.shared.enableHostFeedback {
            didSet {
                AppSettings.shared.enableHostFeedback = self.enableHostFeedback
                self.validateSimulateAlarm()
            }
        }
        
        /// Toggle value for 'Vibrate'
        @Published var virtualTetherVibration: Bool = AppSettings.shared.virtualTetherVibration {
            didSet {
                AppSettings.shared.virtualTetherVibration = self.virtualTetherVibration
                validateHostFeedbacks()
                
            }
        }
        
        /// Toggle value for 'Audio Alarm'
        @Published var virtualTetherAudioAlarm: Bool = AppSettings.shared.virtualTetherAudioAlarm {
            didSet {
                AppSettings.shared.virtualTetherAudioAlarm = self.virtualTetherAudioAlarm
                validateHostFeedbacks()
                
            }
        }
        
        /// Toggle value for 'Flashing Screen'
        @Published var virtualTetherFlashingScreen: Bool = AppSettings.shared.virtualTetherFlashingScreen {
            didSet {
                AppSettings.shared.virtualTetherFlashingScreen = self.virtualTetherFlashingScreen
                validateHostFeedbacks()
                
            }
        }
        
        /// Toggle value for 'Pop-up message'
        @Published var virtualTetherPopupMessage: Bool = AppSettings.shared.virtualTetherPopupMessage {
            didSet {
                AppSettings.shared.virtualTetherPopupMessage = self.virtualTetherPopupMessage
                validateHostFeedbacks()
                
            }
        }
        
        init() {
            getVirtualTetherScannerStatus()
        }
        
        /// Check current virtual tether status and enable host feedbacks when virtual tether screen appears (This will be triggered when the app displays the virtual tether screen when scanner forcefully disconnects or went out of range)
        func checkVirtualTetherEventStatus() {
            AppState.shared.virtualTetherEventOccurred = AppSettings.shared.virtualTetherNotifyEvent
            if (AppState.shared.virtualTetherEventOccurred || AppState.shared.virtualTetherHostActivated) {
                AppState.shared.virtualTetherHostActivated = false
                self.enableStopAlarmOnHostButton = true
                self.virtualTetherHostAlarmStopped = false
                
                self.startVirtualTetherAudioAlarmFunction()
                self.startVirtualTetherPopupMessageFunction()
                //TODO: start other host feedback options
                // Enable flash screen
                // Vibrate alarm
                                
            }
        }
        
        /// Method for validating host feedback toggles with host feedback options
        func validateHostFeedbacks () {
            if (!self.virtualTetherVibration && !self.virtualTetherAudioAlarm && !self.virtualTetherFlashingScreen && !self.virtualTetherPopupMessage) {
                self.enableHostFeedback = false
                
            } else if (self.virtualTetherVibration || self.virtualTetherAudioAlarm || self.virtualTetherFlashingScreen || self.virtualTetherPopupMessage){
                self.enableHostFeedback = true
            }
            self.validateSimulateAlarm()
        }
        
        /// Method for validating simulate alarm to enable/disable snooze and stop alarm buttons
        func validateSimulateAlarm () {
            if (self.simulateAlarm && self.enableHostFeedback) {
                self.enableStopAlarmOnHostButton = true
            } else if (!self.enableHostFeedback || !self.simulateAlarm) {
                self.enableStopAlarmOnHostButton = false
            }
        }
        
        /// Method for turning on and turning off  all host feedback toggles
        func enableAllHostFeedbackOptionToggles(turnOn: Bool){
            self.virtualTetherVibration = turnOn
            self.virtualTetherAudioAlarm = turnOn
            self.virtualTetherFlashingScreen = turnOn
            self.virtualTetherPopupMessage = turnOn
        }
        
        
        /// Method to snooze the alarm on scanner
        func snoozeAlarmOnScanner(){
            
            /// invalidate other timers
            self.simulationTimer?.invalidate()
    
            self.isOnPause = true
            
            /// stop simulation
            stopVirtualTetherSimulation()
            self.enableSnoozeAlarmOnScannerButton = false
            self.enableSimulateAlarmToggle = false
            
            /// restart virtual tether simulation after 3 seconds
            self.snoozeTimer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: false) { _ in
                Task {
                    await self.restartSimulation()
                    
                }
            }
        }
        
        /// Method to restart simulation after snooze timeout
        func restartSimulation() {

            self.enableSnoozeAlarmOnScannerButton = true
            self.initiateVirtualTetherSimulation()
        }
        
        /// Method to get the virtual tether scanner status
        func getVirtualTetherScannerStatus() {
            let attributeList = ZebraSDKManager.shared.getAttributeValues(attributeIdList: [Int32(Constants.RmdAttribute.RMD_ATTR_VIRTUAL_TETHER_ALARM_STATUS)], scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            if (attributeList.count > 0) {
                let virtualTetherStatus = attributeList[0].attributeValue
                self.enableVirtualTether = Int32(virtualTetherStatus) == 0 ? false : true
            }
        }
        
        ///Method to call the API to enable or disable  virtual tether in scanner
        func enableDisableVirtualTetherAlarm(turnOn: Bool) {
            
            let command = Int(turnOn ? Constants.RmdAttribute.RMD_ATTR_VALUE_VIRTUAL_TETHER_ALARM_ENABLE : Constants.RmdAttribute.RMD_ATTR_VALUE_VIRTUAL_TETHER_ALARM_DISABLE)
            let result: SBT_RESULT =  ZebraSDKManager.shared.enableDisableVirualTether(command: command, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            if (result == SBT_RESULT_SUCCESS) {
                AppSettings.shared.enableVirtualTether = turnOn ? true : false
            }
        }
        
        /// This method will initiate necessary callbacks and functions related to virtual tether simulation when simulation toggle is enabled
        func onSimulationEnabled() {
            if (self.simulateAlarm) {
                
                initiateVirtualTetherSimulation()
                
                simulateVirtualTetherHostFeedback()
                
                virtualTetherSimulationOccurred = true
                
                
                /// stop virtual tether host feedback simulation after 5 seconds
                self.hostFeedbackSimulationTimer = Timer.scheduledTimer(withTimeInterval: 5.0, repeats: false) { _ in
                    Task {
                        await self.stopVirtualTetherHostFeedbackSimulation()
                    }
                }
            }
            
        }
        
        /// This method is responsible for initiating the simulation process of Virtual Tether audio, LED ,haptics , illumination alarms
        func initiateVirtualTetherSimulation() {
            //invalidate other timers
            self.snoozeTimer?.invalidate()
            
            self.isOnPause = false
            startVirtualTetherSimulation()
            
            /// stop virtual tether simulation after 5 seconds
            self.simulationTimer = Timer.scheduledTimer(withTimeInterval: 5.0, repeats: false) { _ in
                Task {
                    await self.stopVirtualTetherSimulation()
                }
            }
            
        }
        
        /// This method is responsible for simulating the Virtual Tether audio, LED, haptics and illumination alarms.
        func startVirtualTetherSimulation() {
            self.enableSnoozeAlarmOnScannerButton = true
            self.simulateAlarm = true
            self.enableSimulateAlarmToggle = false
            
            ZebraSDKManager.shared.startStopVirtualTetherSimulation(command: Int(RMD_ATTR_VALUE_ACTION_VIRTUAL_TETHER_SIMULATION_ENABLE), scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
        }
        
        /// This method is responsible for disabling the simulation of the Virtual Tether audio, LED, haptics and illumination alarms.
        func stopVirtualTetherSimulation() {
            ZebraSDKManager.shared.startStopVirtualTetherSimulation(command: Int(RMD_ATTR_VALUE_ACTION_VIRTUAL_TETHER_SIMULATION_DISABLE), scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            self.enableSnoozeAlarmOnScannerButton = false
            
            if(!isOnPause) {
                self.simulateAlarm = false
                self.enableSimulateAlarmToggle = true
            }
        }
        
        /// Method to simulate virtual tether host feedback options
        func simulateVirtualTetherHostFeedback() {
            
            //simulate host audio alarm
            if(self.virtualTetherAudioAlarm) {
                self.startAudioAlarm()
            }
            //simulate popup message
            if(self.virtualTetherPopupMessage) {
                self.displayPopup = true
            }
            //TODO: Simulate other alarms
        }
        
        /// Method to start virtual tether audio alarm
        func startAudioAlarm() {
            guard let sound = Bundle.main.path(forResource: Constants.VirtualTetherResource.AUDIO_FILE, ofType: Constants.VirtualTetherResource.AUDIO_FILE_TYPE) else {
                    return
                }
            do {
                self.audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound))
                self.audioPlayer?.play()
                self.audioAlarmTimer?.invalidate()
                self.audioAlarmTimer = Timer.scheduledTimer(withTimeInterval: 3, repeats: true, block: { (timer) in
                    Task {
                        await self.audioPlayer?.play()
                    }
                })
            } catch {
                print("Eror while playing audio.")
            }
        }
        
        /// Method to stop the Virtual Tether host alarms
        func stopVirtualTetherHostFeedbackAlarms() {
            AppState.shared.virtualTetherEventOccurred = AppSettings.shared.virtualTetherNotifyEvent
            if (AppState.shared.virtualTetherEventOccurred || AppState.shared.virtualTetherHostActivated || self.virtualTetherSimulationOccurred) {
                
                self.enableStopAlarmOnHostButton = false
                self.virtualTetherHostAlarmStopped = true
                AppState.shared.virtualTetherHostActivated = false
                //stop audio alarm
                stopVirtualTetherAudioAlarmOnHost()
                //hide popup message
                self.displayPopup = false
                //TODO: stop other alarms
            }

        }
        
        /// Method to stop simulation of the Virtual Tether host alarms.
        func stopVirtualTetherHostFeedbackSimulation() {
            
            if (AppState.shared.virtualTetherEventOccurred || self.virtualTetherSimulationOccurred) {
                // invalidate simulation timer
                self.hostFeedbackSimulationTimer?.invalidate()
                
                self.enableStopAlarmOnHostButton = false
                self.virtualTetherHostAlarmStopped = true
                AppState.shared.virtualTetherHostActivated = false
                //stop audio alarm
                stopVirtualTetherAudioAlarmOnHost()
                //hide popup message
                self.displayPopup = false
                //TODO: stop other alarms
                
                self.virtualTetherSimulationOccurred = false
            }
        }
        
        /// Method to stop the virtual tether audio alarm on host
        func stopVirtualTetherAudioAlarmOnHost() {
            //stop audio player alarm
            self.audioPlayer?.stop()
            self.audioAlarmTimer?.invalidate()
        }
        

        //MARK: Below methods will be called when virtual tether gets activated without simulation(on foreceful disconnection/when out of range)
        /// Method to start  virtual tether audio alarm when virtual tether screen is coming back to the foreground when communication termination event occurs
        func startVirtualTetherAudioAlarmFunction() {
            if (AppSettings.shared.virtualTetherAudioAlarm) {
                self.startAudioAlarm()
            }

        }
        
        /// Method to start  virtual tether popup message when virtual tether screen is coming back to the foreground when communication termination event occurs
        func startVirtualTetherPopupMessageFunction() {
            if (AppSettings.shared.virtualTetherPopupMessage) {
                self.displayPopup = true
            }

        }
        
        
    }
    
    
}
