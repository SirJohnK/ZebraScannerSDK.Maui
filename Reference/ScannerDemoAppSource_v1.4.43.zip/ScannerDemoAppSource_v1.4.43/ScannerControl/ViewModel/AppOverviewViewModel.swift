//
//  AppOverviewViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation

extension AppOverviewView {
    
    ///ViewModel for publishing UI updates to BleConnectView
    ///
    /// - Returns : ObservableObject with below published properties
    /// - Property appVersion : Current application version
    /// - Property sdkVersion : Current sdk version
    ///
    @MainActor class ViewModel: ObservableObject {
        @Published var appVersion: String?
        @Published var sdkVersion: String?
        
        
        /// Get app version of the scanner control application
        func getScannerControlAppVersion() {
            if let version = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String
            {
                self.appVersion = "\(version)"
            }
            
        }
        
        /// Get scanner SDK version from the SDKManager
        func getScannerSDKVersion() {
            self.sdkVersion = ZebraSDKManager.shared.getSDKVersion()
        }
        
    }
    
}
