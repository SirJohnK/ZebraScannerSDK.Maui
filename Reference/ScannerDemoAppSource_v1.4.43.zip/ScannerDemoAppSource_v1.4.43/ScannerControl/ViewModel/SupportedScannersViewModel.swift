//
//  SupportedScannersViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation


extension SupportedScannersView {
    
    ///ViewModel for publishing UI updates to SupportedScannersView
    ///
    /// - Returns : ObservableObject with published properties
    ///
    @MainActor class ViewModel: ObservableObject {
        var supportedScannerList = ["DS3678","LI3678","RFD8500","CS4070 (Rev E firmware and newer)","DS8178","DS2278","CS6080","RS5100"]
    }
}
