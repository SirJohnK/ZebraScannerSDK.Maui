//
//  BatteryStatisticsView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct BatteryStatisticsView: View {
    var body: some View {
        Form {
            
        }
        .navigationBarTitle(L10n.Advanced.BatteryStatistics.navTitle)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct BatteryStatisticsView_Previews: PreviewProvider {
    static var previews: some View {
        BatteryStatisticsView()
    }
}
