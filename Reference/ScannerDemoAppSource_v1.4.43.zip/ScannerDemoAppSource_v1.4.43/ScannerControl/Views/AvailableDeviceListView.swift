//
//  AvailableDeviceListView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct AvailableDeviceListView: View {
    
    @EnvironmentObject var appState: AppState
    @Environment(\.colorScheme) var colorScheme
    @StateObject private var viewModel = ViewModel()
    
    @State private var showSection1 = false
    @State private var isCurrentlyConnected = false
    @State private var section1HeaderText = ""
    
    var body: some View {
        Form {
            if (showSection1){
                Section(header: Text(section1HeaderText) ) {
                    HStack{
                        Text(viewModel.lastConnectedOrCurrentConnectedScaner?.scannerName ?? "")
                        Spacer()
                        ///commented for initial release as not completed the connection part when tapping
//                        if (isCurrentlyConnected){
//                            Asset.checkMark.swiftUIImage.foregroundColor(.blue)
//                        }else{
//                            Image(asset: Asset.rightNav)
//                        }
                    }
                }
            }
            Section(header: Text("Other Scanners")){
                ForEach(viewModel.otherScannersList,id: \.self) { scanner in
                    HStack{
                        Text(scanner.scannerName)
                        Spacer()
                        ///commented for initial release as not completed the connection part when tapping
//                        Image(asset: Asset.rightNav)

                    }.onTapGesture {
                        if (!appState.connectionInProgress) {
                            ///TBD
                        }
                    }
                }
            }
        }
        .navigationBarTitle(L10n.AvailableDeviceList.navTitle)
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of: appState.availableScannerList) { _ in
            viewModel.getOtherScannerList()
        }
        .onAppear(){
            if(appState.isScannerConnected){
                section1HeaderText  = "Currently Connected Scanner"
                showSection1 = true
                isCurrentlyConnected = true
            }else if (appState.lastConnectedScanner != nil){
                section1HeaderText  = "Last Connected Scanner"
                showSection1 = true
                isCurrentlyConnected = false
            }
            viewModel.LoadScannerList()
        }
    }
}

struct AvailableDeviceListView_Previews: PreviewProvider {
    static var previews: some View {
        AvailableDeviceListView()
    }
}
