//
//  PairingHelpCS6080DS8178.swift
//  ScannerControl
//
//   ©2023 Zebra Technologies Corp. and/or its affiliates. All rights reserved.
//

import SwiftUI

struct PairingHelpCS6080DS8178View: View {
    
    @ObservedObject var viewModel : PairingHelpView.ViewModel
    
    var body: some View {
        Form(){
            Section(){
                NavigationLink{
                    PairingHelpBTLEView(scannerName: "DS8178/CS6080")
                }label: {
                    Text(L10n.PairingHelp.btle)
                }
                NavigationLink{
                    MFiView(viewModel: viewModel)
                }label: {
                    Text(L10n.PairingHelp.mFi)
                }
            }
        }.navigationBarTitle(L10n.PairingHelp.PairDS8178CS6080.navTitle)
            .navigationBarTitleDisplayMode(.inline)
    }
}

struct PairingHelpCS6080DS8178_Previews: PreviewProvider {
    static var previews: some View {
        PairingHelpCS6080DS8178View(viewModel: PairingHelpView.ViewModel())
    }
}

struct MFiView: View {
    @ObservedObject var viewModel : PairingHelpView.ViewModel
    var body: some View {
        
        
        Form () {
            
            Section{
                
                Text(L10n.MFi.Cs6080.instruction1)
                
                Text(L10n.MFi.Cs6080.instruction2)
                
                HStack() {
                    
                    HStack{
                        Image(uiImage: viewModel.resetSetDefaultBarcodeImage ?? UIImage())
                            .resizable()
                            .aspectRatio(contentMode:.fit)
                            .scaledToFit()
                            .frame(width: viewModel.imageWidth , height: viewModel.imageHeight, alignment: .center)
                    }
                    .padding(10)
                    .background(.white)
                    
                }.frame(maxWidth:.infinity)
                
                Text(L10n.MFi.Cs6080.instruction3)
                
                HStack() {
                    
                    HStack{
                        Image(uiImage: viewModel.mfiConfigBarcodeImageCS6080 ?? UIImage())
                            .resizable()
                            .aspectRatio(contentMode:.fit)
                            .scaledToFit()
                            .frame(width: viewModel.imageWidth , height: viewModel.imageHeight, alignment: .center)
                    }
                    .padding(10)
                    .background(.white)
                    
                }.frame(maxWidth:.infinity)
                
                Text(L10n.MFi.Cs6080.instruction4)
                
                Text(L10n.MFi.Cs6080.instruction5)
                
                Text(L10n.MFi.Cs6080.instruction6)
                
                Text(L10n.MFi.Cs6080.instruction7)
                
            }.listRowSeparator(.hidden)
        }
        .navigationBarTitle(L10n.PairingHelp.PairDS8178CS6080.navTitle)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            viewModel.getResetFactoryDefaultBarcode()
            viewModel.getMFiConfigBarcodeForCS6080_DS8178()
        }
        
    }
}

