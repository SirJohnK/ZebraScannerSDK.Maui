//
//  SupportedScannersView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct SupportedScannersView: View {
    
    @StateObject private var viewModel = ViewModel()

    var body: some View {
        Form {
            Section(header: Text(L10n.SupportedScanners.headingText)) {
                ForEach(self.viewModel.supportedScannerList,id: \.self) { (scanner: String) in
                    Text(scanner)
                }
            }
        }.navigationTitle(L10n.SupportedScanners.navTitle)
    }
}

struct SupportedScannersView_Previews: PreviewProvider {
    static var previews: some View {
        SupportedScannersView()
    }
}
