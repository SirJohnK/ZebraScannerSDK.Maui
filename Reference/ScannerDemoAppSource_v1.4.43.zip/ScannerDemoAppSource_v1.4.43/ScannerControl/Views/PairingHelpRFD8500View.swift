//
//  PairingHelpRFD8500View.swift
//  ScannerControl
//
//   ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct PairingHelpRFD8500View: View {
    var body: some View {
        Form () {
            Section {
                
                Text(L10n.Rfd8500.instruction1)
                Text(L10n.Rfd8500.instruction11)

                Text(L10n.Rfd8500.instruction2)
                Text(L10n.Rfd8500.instruction3)
                Text(L10n.Rfd8500.instruction4)
                Text(L10n.Rfd8500.instruction5)
                
            }.listRowSeparator(.hidden)
        }.navigationBarTitle(L10n.Rfd8500.navTitle)
            .navigationBarTitleDisplayMode(.inline)
    }
}

struct PairingHelpRFD8500View_Previews: PreviewProvider {
    static var previews: some View {
        PairingHelpRFD8500View()
    }
}
