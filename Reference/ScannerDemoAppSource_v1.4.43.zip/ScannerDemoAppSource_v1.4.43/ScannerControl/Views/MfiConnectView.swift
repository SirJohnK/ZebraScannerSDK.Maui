//
//  MfiConnectView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct MfiConnectView: View {
    
    @StateObject private var viewModel = ViewModel()
    @EnvironmentObject var appState: AppState
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        
        NavigationView {
            Form {
                Section {
                    if (viewModel.MFiScannerList.isEmpty) {
                        Text(L10n.MFi.noDevicesMessage).frame(maxWidth: .infinity, alignment: .center)
                    } else {
                        ForEach(viewModel.MFiScannerList,id: \.self) { scanner in
                            HStack{
                                Text(scanner.scannerName).foregroundColor(viewModel.selection?.scannerId != scanner.scannerId && appState.connectionInProgress ? Asset.lightTextColor.swiftUIColor : (colorScheme == .dark ? .white : .black))
                                Spacer()
                                if (appState.connectionInProgress && viewModel.selection?.scannerId == scanner.scannerId) {
                                    ProgressView()
                                } else {
                                    Image(asset: Asset.rightNav).foregroundColor(viewModel.selection?.scannerId != scanner.scannerId && appState.connectionInProgress ? Asset.lightTextColor.swiftUIColor : (colorScheme == .dark ? .white : .black))
                                }
                            }.onTapGesture {
                                if (!appState.connectionInProgress) {
                                    viewModel.selection = scanner
                                    viewModel.connectMFiScanner(scanner: scanner)
                                }
                            }
                        }
                    }
                }
            }
            .safeAreaInset(edge: .top){
                Color.clear.frame(height: 20)
            }
            .navigationTitle(L10n.MFi.navTitle)
            .alert(viewModel.alertDetails.getTitle(), isPresented: $appState.connectionFailed, presenting: viewModel.alertDetails) { alertDetails in
                Button("OK"){
                    alertDetails.dismissAlert()
                }
                
            }message: { alertDetails in
                Text("\(alertDetails.getDescription())")
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
        .onAppear {
            viewModel.getMFiScannerList()
        }
        .onChange(of: appState.availableScannerList) { _ in
            viewModel.getMFiScannerList()
        }
    }
}

struct MfiConnectView_Previews: PreviewProvider {
    static var previews: some View {
        MfiConnectView()
    }
}
