//
//  SettingsView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct SettingsView: View {
    @EnvironmentObject var appState: AppState
    @StateObject private var viewModel = ViewModel()
    @State  var showAlertMessage = false
    
    var body: some View {
        
        NavigationView {
            Form {
                Section() {
                    NavigationLink {
                        BeeperView()
                    } label: {
                        Text(L10n.Settings.beeperLabel)
                    }
                    NavigationLink {
                        LEDControlView()
                    } label: {
                        Text(L10n.Settings.ledControlLabel)
                    }
                    NavigationLink {
                        SymbologySettingsView()
                    } label: {
                        Text(L10n.Settings.symbologiesLabel)
                    }
                    HStack {
                        Text(L10n.Settings.triggerLabel)
                        Spacer()
                        HStack(spacing: 25) {
                            Button(L10n.Settings.Trigger.pullButtonText) {
                                viewModel.pullTrigger()
                            }
                            Text("|").font(.system(size: 30, weight: .ultraLight)).foregroundColor(Color.gray)
                            Button(L10n.Settings.Trigger.releaseButtonText) {
                                viewModel.releaseTrigger()
                            }
                        }
                        
                    }.buttonStyle(BorderlessButtonStyle())
                    Toggle(L10n.Settings.picklistModeLabel, isOn: $viewModel.picklistModeSetting)
                        .onChange(of: viewModel.picklistModeSetting) { value in
                            viewModel.setPickListMode()
                    }
                    HStack {
                        Text(L10n.Settings.aimGuideLabel)
                        Spacer()
                        HStack(spacing: 25) {
                            Button(L10n.Settings.AimGuide.onButtonText) {
                                viewModel.aimOn()
                            }
                            Text("|").font(.system(size: 30, weight: .ultraLight)).foregroundColor(Color.gray)
                            Button(L10n.Settings.AimGuide.offButtonText) {
                                viewModel.aimOff()
                            }
                        }
                    }.buttonStyle(BorderlessButtonStyle())
                    NavigationLink {
                        VibrationFeedbackView()
                    } label: {
                        Text(L10n.Settings.vibrationFeedbackLabel)
                    }
                }
                Section {
                    Toggle(L10n.Settings.autoReconnectText, isOn: $viewModel.autoReconnectionEnabled)
                        .onChange(of: viewModel.autoReconnectionEnabled) { value in
                            viewModel.setAutoReconnectStatus(enable: value)
                        }
                    Toggle(L10n.Settings.paramterBarcodeText, isOn: $viewModel.parameterBarcodeDisabled)
                        .onChange(of: viewModel.parameterBarcodeDisabled) { value in
                            viewModel.setParameterBarcodeScanningStatus(disabled: value)
                        }
                } footer: {
                    Text(L10n.Settings.paramterBarcodeInfoText)
                }
            }
            .safeAreaInset(edge: .top){
                Color.clear.frame(height: 20)
            }
            .navigationTitle(L10n.Settings.navTitle)
            .onChange(of: appState.showAlert) { newValue in
                if (newValue){
                    showAlertMessage = true
                }
            }
            .alert(viewModel.alertDetails.getTitle(), isPresented: $showAlertMessage, presenting: viewModel.alertDetails) { alertDetails in
                Button("OK"){
                    alertDetails.dismissAlert()
                }
            }message: { alertDetails in
                Text("\(alertDetails.getDescription())")
            }

        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}
