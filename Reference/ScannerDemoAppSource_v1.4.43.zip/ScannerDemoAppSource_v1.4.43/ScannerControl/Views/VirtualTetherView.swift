//
//  VirtualTetherView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct VirtualTetherView: View {
    
    @StateObject private var viewModel = ViewModel()
    @Environment(\.colorScheme) var colorScheme
    @State var showAlert = false
    
    var body: some View {
        Form {
            Section(header: Text(L10n.VirtualTether.scannerSettingsText)) {
                Toggle(L10n.VirtualTether.enableVirtualTetherText, isOn: $viewModel.enableVirtualTether).onChange(of: viewModel.enableVirtualTether) { value in
                    viewModel.enableDisableVirtualTetherAlarm(turnOn: value)
                }
                Toggle(L10n.VirtualTether.simulateAlarmText, isOn: $viewModel.simulateAlarm).disabled(!viewModel.enableSimulateAlarmToggle).onChange(of: viewModel.simulateAlarm) { value in
                    viewModel.onSimulationEnabled()
                }
                HStack() {
                    Spacer()
                    Button(action: {
                        viewModel.snoozeAlarmOnScanner()
                    }) {
                        HStack {
                            Text(L10n.VirtualTether.snoozeAlarmButtonText).bold()
                        }.frame(width: 300, height: 50)
                    }
                    .frame(width: 300, height: 50)
                    .buttonStyle(CustomButtonStyle())
                    .background(Asset.blueColor.swiftUIColor)
                    .cornerRadius(5)
                    .disabled(!viewModel.enableSnoozeAlarmOnScannerButton)
                    Spacer()
                    
                }.frame(height: 70,alignment: .center)
            }
            
            Section(header: Text(L10n.VirtualTether.hostSettingsText)) {
                Toggle(L10n.VirtualTether.enableHostFeedbackText, isOn: $viewModel.enableHostFeedback).disabled(!viewModel.enableHostFeedbackToggles).onChange(of: viewModel.enableHostFeedback) { value in
                    viewModel.enableAllHostFeedbackOptionToggles(turnOn: value)
                }
                Toggle(L10n.VirtualTether.vibrateText, isOn: $viewModel.virtualTetherVibration).disabled(!viewModel.enableHostFeedbackToggles)
                Toggle(L10n.VirtualTether.audioAlarmText, isOn: $viewModel.virtualTetherAudioAlarm).disabled(!viewModel.enableHostFeedbackToggles)
                Toggle(L10n.VirtualTether.flashingScreenText, isOn: $viewModel.virtualTetherFlashingScreen).disabled(!viewModel.enableHostFeedbackToggles)
                Toggle(L10n.VirtualTether.popupMessageText, isOn: $viewModel.virtualTetherPopupMessage).disabled(!viewModel.enableHostFeedbackToggles)
                HStack() {
                    Spacer()
                    Button(action: {
                        viewModel.stopVirtualTetherHostFeedbackAlarms()
                    }) {
                        HStack {
                            Text(L10n.VirtualTether.stopAlarmButtonText).bold()
                        }.frame(width: 300, height: 50)
                    }
                    .frame(width: 300, height: 50)
                    .buttonStyle(CustomButtonStyle())
                    .background(Asset.blueColor.swiftUIColor)
                    .cornerRadius(5)
                    .disabled(!viewModel.enableStopAlarmOnHostButton)
                    Spacer()
                    
                }.frame(height: 70,alignment: .center)
            }
        }
        .alert("", isPresented: $viewModel.displayPopup) {
            Button(L10n.VirtualTether.popupMessageOKText) {
                viewModel.stopVirtualTetherHostFeedbackAlarms()
            }
        } message: {
            Text(L10n.VirtualTether.popupAlertText)
        }
        .navigationBarTitle(L10n.Advanced.VirtualTether.navTitle)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            viewModel.checkVirtualTetherEventStatus()
        }
    }
}

struct VirtualTetherView_Previews: PreviewProvider {
    static var previews: some View {
        VirtualTetherView()
    }
}
