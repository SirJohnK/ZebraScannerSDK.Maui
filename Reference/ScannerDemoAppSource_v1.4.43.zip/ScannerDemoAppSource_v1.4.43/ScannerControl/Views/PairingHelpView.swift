//
//  ConnectionHelpView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct PairingHelpView: View {
    
    @StateObject private var viewModel = ViewModel()
    
    var body: some View {
        Form {
            Section(header: Text(L10n.PairingHelp.pairingInstructionsLabel)) {
                NavigationLink {
                    ParingHelpCS4070View(viewModel: viewModel)
                } label: {
                    Text(L10n.PairingHelp.pairCS4070)
                }
                NavigationLink {
                    PairingHelpRFD8500View()
                } label: {
                    Text(L10n.PairingHelp.pairRFD8500)
                }
                NavigationLink {
                    PairingHelpBTLEView(scannerName: "LI/DS3678")
                } label: {
                    Text(L10n.PairingHelp.pairLIDS3678)
                }
                NavigationLink {
                    PairingHelpCS6080DS8178View(viewModel: viewModel)
                } label: {
                    Text(L10n.PairingHelp.pairDS8178CS6080)
                }
                NavigationLink {
                    PairingHelpBTLEView(scannerName: "DS2278")
                } label: {
                    Text(L10n.PairingHelp.pairDS2278)
                }
                NavigationLink {
                    PairingHelpBTLEView(scannerName: "RS5100")
                } label: {
                    Text(L10n.PairingHelp.pairRS5100)
                }
            }
            Section(header: Text(L10n.PairingHelp.setDefaultsLabel)) {
                NavigationLink {
                    SetDefaultsView(viewModel: viewModel)
                } label: {
                    Text(L10n.PairingHelp.setDefaultsLabel)
                }
            }
        }
        .navigationBarTitle(L10n.PairingHelp.navTitle)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct PairingHelpView_Previews: PreviewProvider {
    static var previews: some View {
        PairingHelpView()
    }
}
