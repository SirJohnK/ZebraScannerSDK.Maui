//
//  AssetInfoView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct AssetInfoView: View {
    @StateObject private var viewModel = ViewModel()

    var body: some View {
        Form {
            Section {
                DetailItemView(label: L10n.Advanced.AssetInformation.modelLabel, value: viewModel.scannerInfo?.scannerModel ?? "")
                DetailItemView(label: L10n.Advanced.AssetInformation.serialNoLabel, value: viewModel.scannerInfo?.serialNo ?? "")
                DetailItemView(label: L10n.Advanced.AssetInformation.firmwareLabel, value: viewModel.scannerInfo?.firmware ?? "")
                DetailItemView(label: L10n.Advanced.AssetInformation.dateOfManufactureLabel, value: viewModel.scannerInfo?.dateOfManufacture ?? "")
                DetailItemView(label: L10n.Advanced.AssetInformation.nameLabel, value: viewModel.scannerInfo?.scannerName ?? "")
                DetailItemView(label: L10n.Advanced.AssetInformation.configurationFilenameLabel, value: viewModel.scannerInfo?.configurationFileName ?? "")
                DetailItemView(label: L10n.Advanced.AssetInformation.connectionTypeLabel, value: viewModel.scannerInfo?.getConnectionType() ?? "")
            }
        }
        .navigationBarTitle(L10n.Advanced.AssetInformation.navTitle)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            viewModel.getScannerInformation()
        }
    }
}

struct AssetInfoView_Previews: PreviewProvider {
    static var previews: some View {
        AssetInfoView()
    }
}

struct DetailItemView: View {
    var label: String
    var value: String
    var body: some View {
        HStack {
            Text(label)
            Spacer()
            Text(value.trimmingCharacters(in: .whitespacesAndNewlines)).foregroundColor(Asset.lightTextColor.swiftUIColor)
        }
    }
}
