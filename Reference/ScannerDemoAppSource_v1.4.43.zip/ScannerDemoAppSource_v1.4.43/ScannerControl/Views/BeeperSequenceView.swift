//
//  BeeperSequenceView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct BeeperSequenceView: View {
    
    @ObservedObject var viewModel : BeeperView.ViewModel
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        Form {
            Section {
                ForEach(self.viewModel.beeperSequenceList) { (beeperSequence: BeeperSequence) in
                    HStack {
                        Button(action: {
                            viewModel.selectedSequence = beeperSequence
                        }) {
                            HStack{
                                Text(beeperSequence.actionName)
                                    .foregroundColor(
                                        colorScheme == .dark ? .white : .black
                                    )
                                Spacer()
                                if viewModel.selectedSequence == beeperSequence {
                                    Asset.checkMark.swiftUIImage
                                }
                            }
                        }.buttonStyle(BorderlessButtonStyle())
                    }
                    
                }
            }
        }
        .navigationBarTitle(L10n.BeeperSettings.Sequence.navTitle)
        .navigationBarItems(
            trailing:
                Button(action: {
                    viewModel.performBeeperSequenceAction()
                }) {Text(L10n.BeeperSettings.beepText).tint(Color.white)}
        )
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct BeeperSequenceView_Previews: PreviewProvider {
    static var previews: some View {
        BeeperSequenceView(viewModel: BeeperView.ViewModel())
    }
}
