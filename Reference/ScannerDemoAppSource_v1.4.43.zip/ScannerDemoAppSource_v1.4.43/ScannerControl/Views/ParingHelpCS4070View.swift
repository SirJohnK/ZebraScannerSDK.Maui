//
//  ParingHelpCS4070View.swift
//  ScannerControl
//
//   ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct ParingHelpCS4070View: View {
    @ObservedObject var viewModel : PairingHelpView.ViewModel
    
    var body: some View {
        Form () {
            
            Section{
                
                Text(L10n.MFi.Cs4070.instruction1)
                
                Text(L10n.MFi.Cs4070.instruction2)
                
                HStack() {
                    
                    HStack{
                        Image(uiImage: viewModel.resetSetDefaultBarcodeImageCS4070 ?? UIImage())
                            .resizable()
                            .aspectRatio(contentMode:.fit)
                            .scaledToFit()
                            .frame(width: viewModel.imageWidth , height: viewModel.imageHeight, alignment: .center)
                    }
                    .padding(10)
                    .background(.white)
                    
                }.frame(maxWidth:.infinity)
                
                Text(L10n.MFi.Cs4070.instruction3)
                
                HStack() {
                    
                    HStack{
                        Image(uiImage: viewModel.mfiConfigBarcodeImageCS4070 ?? UIImage())
                            .resizable()
                            .aspectRatio(contentMode:.fit)
                            .scaledToFit()
                            .frame(width: viewModel.imageWidth , height: viewModel.imageHeight, alignment: .center)
                    }
                    .padding(10)
                    .background(.white)
                    
                }.frame(maxWidth:.infinity)
                
                Text(L10n.MFi.Cs4070.instruction4)
                
                Text(L10n.MFi.Cs4070.instruction5)
                
                Text(L10n.MFi.Cs4070.instruction6)
                
                Text(L10n.MFi.Cs4070.instruction7)
                
            }.listRowSeparator(.hidden)
        }
        .navigationBarTitle(L10n.PairingHelp.PairCS4070.navTitle)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            viewModel.getResetFactoryDefaultBarcodeForCS4070()
            viewModel.getMFiConfigBarcodeForCS4070()
        }
    }
}

struct ParingHelpCS4070View_Previews: PreviewProvider {
    static var previews: some View {
        ParingHelpCS4070View(viewModel: PairingHelpView.ViewModel())
    }
}
