//
//  BeeperVolumeView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct BeeperVolumeView: View {
    
    @ObservedObject var viewModel : BeeperView.ViewModel
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        Form {
            Section {
                ForEach(self.viewModel.beeperVolumeList) { (beeperVolume: BeeperVolume) in
                    HStack {
                        Button(action: {
                            viewModel.selectedVolume = beeperVolume
                            viewModel.updateBeeperVolume()
                        }) {
                            HStack{
                                Text(beeperVolume.actionName)
                                    .foregroundColor(
                                        colorScheme == .dark ? .white : .black
                                    )
                                Spacer()
                                if viewModel.selectedVolume == beeperVolume {
                                    Asset.checkMark.swiftUIImage
                                }
                            }
                        }.buttonStyle(BorderlessButtonStyle())
                    }
                    
                }
            }
        }
        .navigationBarTitle(L10n.BeeperSettings.Volume.navTitle)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct BeeperVolumeView_Previews: PreviewProvider {
    static var previews: some View {
        BeeperVolumeView(viewModel: BeeperView.ViewModel())
    }
}
