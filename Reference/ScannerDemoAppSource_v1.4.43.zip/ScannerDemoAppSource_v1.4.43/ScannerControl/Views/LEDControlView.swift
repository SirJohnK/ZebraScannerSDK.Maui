//
//  LEDControlView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct LEDControlView: View {
    
    @StateObject private var viewModel = ViewModel()

    var body: some View {
        Form {
            Section(){
                
                HStack {
                    Text(L10n.Settings.LEDControl.greenLED)
                    Spacer()
                    HStack(spacing: 25) {
                        Button(L10n.Settings.LEDControl.ledOn) {
                            viewModel.performLEDAction(ledColor: .green, ledStatus: .on)
                        }
                        Text("|").font(.system(size: 30, weight: .ultraLight)).foregroundColor(Color.gray)
                        Button(L10n.Settings.LEDControl.ledOff) {
                            viewModel.performLEDAction(ledColor: .green, ledStatus: .off)
                        }
                    }
                    
                }.buttonStyle(BorderlessButtonStyle())
                HStack {
                    Text(L10n.Settings.LEDControl.yellowLED)
                    Spacer()
                    HStack(spacing: 25) {
                        Button(L10n.Settings.LEDControl.ledOn) {
                            viewModel.performLEDAction(ledColor: .yellow, ledStatus: .on)
                        }
                        Text("|").font(.system(size: 30, weight: .ultraLight)).foregroundColor(Color.gray)
                        Button(L10n.Settings.LEDControl.ledOff) {
                            viewModel.performLEDAction(ledColor: .yellow, ledStatus: .off)
                        }
                    }
                    
                }.buttonStyle(BorderlessButtonStyle())
                HStack {
                    Text(L10n.Settings.LEDControl.redLED)
                    Spacer()
                    HStack(spacing: 25) {
                        Button(L10n.Settings.LEDControl.ledOn) {
                            viewModel.performLEDAction(ledColor: .red, ledStatus: .on)
                        }
                        Text("|").font(.system(size: 30, weight: .ultraLight)).foregroundColor(Color.gray)
                        Button(L10n.Settings.LEDControl.ledOff) {
                            viewModel.performLEDAction(ledColor: .red, ledStatus: .off)
                        }
                    }
                    
                }.buttonStyle(BorderlessButtonStyle())
            }
        }
        .navigationBarTitle(L10n.Settings.LEDControl.navTitle)
        .navigationBarTitleDisplayMode(.inline)
        .onDisappear{
            viewModel.turnOffLed()
        }
    }
}

extension LEDControlView {
    enum LedColor: Hashable {
        case green
        case yellow
        case red
    }
    enum LedStatus: Hashable {
        case on
        case off
    }
}

struct LEDControlView_Previews: PreviewProvider {
    static var previews: some View {
        LEDControlView()
    }
}
