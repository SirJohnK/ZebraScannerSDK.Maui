//
//  DataView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct DataView: View {
    
    @StateObject private var viewModel = ViewModel()
    @EnvironmentObject var appState: AppState
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        
        NavigationView {
            ZStack{
                Color(colorScheme == .dark ? .black : .secondarySystemBackground).edgesIgnoringSafeArea(.all)
                VStack {
                    
                    VStack {
                        HStack{
                            Text("\(L10n.DataView.barcodesScannedLabel) \(viewModel.barcodeDataList.count)").foregroundColor(Asset.lightTextColor.swiftUIColor).font(.system(size: 14)).textCase(.uppercase)
                            Spacer()
                            Button(L10n.DataView.clearButtonText) {
                                viewModel.clearList()
                            }
                            .font(.system(size:14)).textCase(.uppercase)
                            .disabled(viewModel.barcodeDataList.count == 0 ? true : false)
                        }.padding(15)
                    }.padding([.leading, .trailing], 15)
                    List {
                        Section {
                            ForEach(viewModel.barcodeDataList) { barcode in
                                NavigationLink(destination: BarcodeDetailView(viewModel: viewModel), tag: barcode,selection:$viewModel.selectedBarcodeData) {
                                    VStack(alignment: .leading) {
                                        Text(barcode.barcodeText)
                                            .lineLimit(1)
                                        Text(barcode.getBarcodeTypeAsString()).foregroundColor(Asset.lightTextColor.swiftUIColor).font(.system(size: 13))
                                        Text("Characters: \(barcode.characterCount)").foregroundColor(Asset.lightTextColor.swiftUIColor).font(.system(size: 13))
                                    }
                                }
                            }
                        }
                        .listSectionSeparator(.hidden)
                    }
                    .cornerRadius(15)
                    .listStyle(.insetGrouped)
                    .offset(x: 0, y: -10).edgesIgnoringSafeArea(.bottom)
                    
                    
                        VStack {
                            HStack {
                                NavigationLink(destination: SampleBarcodeView(viewModel: viewModel)) {
                                    HStack {
                                        Text(L10n.DataView.sampleBarcodesNavText).foregroundColor(colorScheme == .dark ? .white : .black)
                                        Spacer()
                                        Image(asset: Asset.rightNav)
                                                .font(Font.system(size: 14, weight: .semibold)).foregroundColor(.gray).opacity(0.6)
                                    }
                                }
                            }.frame(maxWidth:.infinity,alignment:.leading)
                                .padding(15)
                                .background(Color(colorScheme == .dark ? .secondarySystemBackground : .white))
                                .cornerRadius(10)
                        }
                        .frame(maxWidth:.infinity,alignment:.topLeading)
                        .padding([.leading,.trailing,.bottom],15)
                }
                .navigationTitle(L10n.DataView.navTitle)
            }
            .safeAreaInset(edge: .top){
                Color.clear.frame(height: 10)
            }
            
        }.onAppear {
            viewModel.getBarcodeData()
        }.onChange(of:  appState.scannerBarcodeList) { _ in
            viewModel.getBarcodeData()
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}
