//
//  SymbologySettingsView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct SymbologySettingsView: View {
    
    @StateObject private var viewModel = ViewModel()
    @EnvironmentObject var appState: AppState
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        ZStack {
            Form {
                Section {
                    if (viewModel.showPersistSetting) {
                        Toggle(L10n.Symbology.persistLabel, isOn: $viewModel.setPersistSetting)
                    }
                }
                Section {
                    ForEach(appState.symbologyList.indices, id: \.self) { index in
                        SymbologyToggle(viewModel: self.viewModel, index:index)
                    }
                }
            }
            LoadingView()
        }
        .navigationBarTitle(L10n.Settings.Symbologies.navTitle)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct SymbologySettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SymbologySettingsView()
    }
}

struct SymbologyToggle: View {
    
    @StateObject var viewModel: SymbologySettingsView.ViewModel
    @EnvironmentObject var appState: AppState
    var index : Int
    
    var body: some View {
        Toggle(appState.symbologyList[index].name, isOn: $appState.symbologyList[index].enabled)
            .onChange(of: appState.symbologyList[index].enabled) { value in
                viewModel.setSymbologyConfiguration(symbology: appState.symbologyList[index])
            }
    }
}
