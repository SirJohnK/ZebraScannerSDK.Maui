//
//  SetDefaultsView.swift
//  ScannerControl
//
//   ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI


struct SetDefaultsView: View {
    @ObservedObject var viewModel : PairingHelpView.ViewModel

    var body: some View {
        Form () {
            Section {
                
                Text(L10n.SetDefault.instruction)
                HStack() {
                    
                    HStack{
                        Image(uiImage: viewModel.setDefaultBarcodeImage ?? UIImage())
                            .resizable()
                            .aspectRatio(contentMode:.fit)
                            .scaledToFit()
                            .frame(width: viewModel.imageWidth , height: viewModel.imageHeight, alignment: .center)
                    }
                    .padding(10)
                    .background(.white)
                    
                }.frame(maxWidth:.infinity)
                
            }.listRowSeparator(.hidden)
        }
        .navigationBarTitle(L10n.PairingHelp.SetDefaults.navTitle)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            viewModel.getSetDefaultBarcode()
        }
    }
}

struct SetDefaultsView_Previews: PreviewProvider {
    static var previews: some View {
        SetDefaultsView(viewModel: PairingHelpView.ViewModel())
    }
}
