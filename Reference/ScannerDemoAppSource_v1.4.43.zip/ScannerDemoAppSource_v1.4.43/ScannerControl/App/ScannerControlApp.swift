//
//  ScannerControlApp.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

@main
struct ScannerControlApp: App {
    
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            let appState = AppState.shared
            MainTabView().environmentObject(appState)
        }
    }
}


