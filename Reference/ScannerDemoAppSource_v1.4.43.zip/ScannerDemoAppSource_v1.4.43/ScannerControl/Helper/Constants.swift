//
// Constants.swift
// ScannerControl
//
// ©2023 Zebra Technologies Corp. and/or its affiliates. All rights reserved.
//

import Foundation

// to handle app constants
struct Constants {
    
    
    struct ScannerDetails {
        static let SCANNER_MODEL_SSI_CS4070 = "CS4070";
    }
    
    ///supported all symbology types
    struct SymbologyTypes {
        static let ST_NOT_APP = 0x00
        static let ST_CODE_39 = 0x01
        static let ST_CODABAR = 0x02
        static let ST_CODE_128 = 0x03
        static let ST_D2OF5 = 0x04
        static let ST_IATA = 0x05
        static let ST_I2OF5 = 0x06
        static let ST_CODE93 = 0x07
        static let ST_UPCA = 0x08
        static let ST_UPCE0 = 0x09
        static let ST_EAN8 = 0x0a
        static let ST_EAN13 = 0x0b
        static let ST_CODE11 = 0x0c
        static let ST_CODE49 = 0x0d
        static let ST_MSI = 0x0e
        static let ST_EAN128 = 0x0f
        static let ST_UPCE1 = 0x10
        static let ST_PDF417 = 0x11
        static let ST_CODE16K = 0x12
        static let ST_C39FULL = 0x13
        static let ST_UPCD = 0x14
        static let ST_TRIOPTIC = 0x15
        static let ST_BOOKLAND = 0x16
        static let ST_COUPON = 0x17
        static let ST_NW7 = 0x18
        static let ST_ISBT128 = 0x19
        static let ST_MICRO_PDF = 0x1a
        static let ST_DATAMATRIX = 0x1b
        static let ST_QR_CODE = 0x1c
        static let ST_MICRO_PDF_CCA = 0x1d
        static let ST_POSTNET_US = 0x1e
        static let ST_PLANET_CODE = 0x1f
        static let ST_CODE_32 = 0x20
        static let ST_ISBT128_CON = 0x21
        static let ST_JAPAN_POSTAL = 0x22
        static let ST_AUS_POSTAL = 0x23
        static let ST_DUTCH_POSTAL = 0x24
        static let ST_MAXICODE = 0x25
        static let ST_CANADIN_POSTAL = 0x26
        static let ST_UK_POSTAL = 0x27
        static let ST_MACRO_PDF = 0x28
        static let ST_RSS14 = 0x30
        static let ST_RSS_LIMITED = 0x31
        static let ST_RSS_EXPANDED = 0x32
        static let ST_SCANLET = 0x37
        static let ST_UPCA_2 = 0x48
        static let ST_UPCE0_2 = 0x49
        static let ST_EAN8_2 = 0x4a
        static let ST_EAN13_2 = 0x4b
        static let ST_UPCE1_2 = 0x50
        static let ST_CCA_EAN128 = 0x51
        static let ST_CCA_EAN13 = 0x52
        static let ST_CCA_EAN8 = 0x53
        static let ST_CCA_RSS_EXPANDED = 0x54
        static let ST_CCA_RSS_LIMITED = 0x55
        static let ST_CCA_RSS14 = 0x56
        static let ST_CCA_UPCA = 0x57
        static let ST_CCA_UPCE = 0x58
        static let ST_CCC_EAN128 = 0x59
        static let ST_TLC39 = 0x5A
        static let ST_CCB_EAN128 = 0x61
        static let ST_CCB_EAN13 = 0x62
        static let ST_CCB_EAN8 = 0x63
        static let ST_CCB_RSS_EXPANDED = 0x64
        static let ST_CCB_RSS_LIMITED = 0x65
        static let ST_CCB_RSS14 = 0x66
        static let ST_CCB_UPCA = 0x67
        static let ST_CCB_UPCE = 0x68
        static let ST_SIGNATURE_CAPTURE = 0x69
        static let ST_MATRIX2OF5 = 0x71
        static let ST_CHINESE2OF5 = 0x72
        static let ST_UPCA_5 = 0x88
        static let ST_UPCE0_5 = 0x89
        static let ST_EAN8_5 = 0x8a
        static let ST_EAN13_5 = 0x8b
        static let ST_UPCE1_5 = 0x90
        static let ST_MACRO_MICRO_PDF = 0x9A
        static let ST_MICRO_QR_CODE = 0x2c
        static let ST_AZTEC = 0x2d
        static let ST_HAN_XIN = 0xB7
        static let ST_KOREAN_3_OF_5 = 0x73
        static let ST_ISSN = 0x36
        static let ST_MATRIX_2_OF_5 = 0x39
        static let ST_AZTEC_RUNE_CODE = 0x2E
        static let ST_NEW_COUPEN_CODE = 0xB4
        static let ST_DOT_CODE = 0xC4
    }
    
    // App related constants
    struct AppDetails {
        static let ZT_FW_FILE_DIRECTORY_NAME           = "Download"
        static let ZT_FW_FILE_EXTENSION                = "DAT"
        static let ZT_PLUGIN_FILE_EXTENSION            = "SCNPLG"
        static let ZT_RELEASE_NOTES_FILE_EXTENTION     = "txt"
        static let ZT_METADATA_FILE                    = "Metadata.xml"
        static let ZT_MODEL_LIST_TAG                   = "models"
        static let ZT_MODEL_TAG                        = "model"
        static let ZT_REVISION_TAG                     = "revision"
        static let ZT_RELEASED_DATE_TAG                = "release-date"
        static let ZT_FAMILY_TAG                       = "family"
        static let ZT_NAME_TAG                         = "name"
        static let ZT_FIRMWARE_NAME_TAG                = "combined-firmware"
        static let ZT_FIRMWARE_COMPONENT               = "component"
        static let ZT_RELEASE_DATE_LBL_PREFIX          = "To Release "
        static let ZT_IMAGE_TAG                        = "picture"

    }
    
    struct RmdAttribute {
        //TODO: Move this attributes to SDK
        static let RMD_ATTR_VIRTUAL_TETHER_ALARM_STATUS = 2053
        static let RMD_ATTR_PICKLIST_MODE = 402
        static let RMD_ATTR_VIBRATION_FEEDBACK_STATUS = 613
        static let RMD_ATTR_VIBRATION_DURATION = 626
        static let RMD_ATTR_CONFIG_NAME = 616
        
        //TODO: Move this attribute values to SDK
        static let RMD_ATTR_VALUE_VIRTUAL_TETHER_ALARM_ENABLE = 1
        static let RMD_ATTR_VALUE_VIRTUAL_TETHER_ALARM_DISABLE = 0
        

    }
    
    struct VirtualTetherResource {
        static let AUDIO_FILE = "vt_alarm_tone"
        static let AUDIO_FILE_TYPE = "wav"
    }
}
