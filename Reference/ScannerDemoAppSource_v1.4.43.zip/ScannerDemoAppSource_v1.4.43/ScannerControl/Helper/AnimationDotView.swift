//
//  AnimationDotView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation
import SwiftUI

/// Animation dot view for reboot dialog
struct DotView: View {
    @State var delay: Double = 0
    @State var scale: CGFloat = 0.5
    var body: some View {
        Circle()
            .frame(width: 10, height: 10)
            .scaleEffect(scale)
            .animation(Animation.easeInOut(duration: 0.6).repeatForever().delay(delay),value: UUID())
            .onAppear {
                withAnimation {
                    self.scale = 1
                }
            }
            .tint(Color.black.opacity(0.8))
    }
}
