//
//  BarcodeGeneratorCode128.h
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/*
 Responsible for generating code 128 barcodes
 */

@interface BarcodeGeneratorCode128 : NSObject

unsigned generateBarcode128B1(const char *input, unsigned short *output, unsigned *width);

@end

NS_ASSUME_NONNULL_END
