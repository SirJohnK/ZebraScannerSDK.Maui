//
//  VibrationDuration.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation

///Data model for vibration duration action details
struct VibrationDuration : Identifiable, Hashable{

    var id: Int { actionValue }
    var actionValue: Int
    var actionName: String
        
    init(actionValue: Int,actionName: String) {
        self.actionValue = actionValue
        self.actionName = actionName
    }

}
