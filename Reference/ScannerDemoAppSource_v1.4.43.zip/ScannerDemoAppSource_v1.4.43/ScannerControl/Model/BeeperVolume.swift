//
//  BeeperVolume.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation

///Data model for beeper sequence action details
struct BeeperVolume : Identifiable,Hashable {
    
    var id: Int32 { actionValue }
    var actionValue: Int32
    var actionName: String
        
    init(actionValue: Int32,actionName: String) {
        self.actionValue = actionValue
        self.actionName = actionName
    }
}
