//
//  AttributeDetail.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation

///Data model for storing attribute details
struct AttributeDetail {
    var attributeId: String
    var attributeValue: String
    var attributeIdGetAll: String
    
    init(details: [String: Any]) {
        attributeId = details["id"] as? String ?? ""
        attributeValue = details["value"] as? String ?? ""
        attributeIdGetAll = details["attrib_list"] as? String ?? ""
    }
}
