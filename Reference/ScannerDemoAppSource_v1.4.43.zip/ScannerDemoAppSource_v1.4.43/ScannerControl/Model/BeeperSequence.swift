//
//  BeeperAction.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation

///Data model for beeper sequence action details
struct BeeperSequence : Identifiable, Hashable{

    var id: Int { actionValue }
    var actionValue: Int
    var actionName: String
        
    init(actionValue: Int,actionName: String) {
        self.actionValue = actionValue
        self.actionName = actionName
    }

}
