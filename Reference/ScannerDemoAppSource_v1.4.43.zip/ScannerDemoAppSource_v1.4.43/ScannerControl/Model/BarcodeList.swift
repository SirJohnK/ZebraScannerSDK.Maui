//
//  BarcodeList.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation

///Data model for storing barcode data in a list corresponding to each scanner id
struct BarcodeList : Hashable{
    
    var scannerId: Int32
    var scannerName: String
    var listOfBarcodes: [BarcodeData]
        
    init(scannerId: Int32, scannerName: String, listOfBarcodes: [BarcodeData]) {
        self.scannerId = scannerId
        self.scannerName = scannerName
        self.listOfBarcodes = listOfBarcodes
    }
    
    ///Method to get the reversed barcode list to make the last scanned barcode to appear at the top of the list in the UI
    func getBarcodeList()-> [BarcodeData] {
        return self.listOfBarcodes.reversed()
    }
    
    ///Method to clear the list of barcodes
    mutating func clearBarcodeList(){
        self.listOfBarcodes.removeAll()
    }

    ///Method to add a newly scanned barcode to list
    mutating func addBarcodeData(data: BarcodeData){
        self.listOfBarcodes.append(data)
    }
}
