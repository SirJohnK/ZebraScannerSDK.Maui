//
//  Symbology.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation

///Data model for symbology settings
struct Symbology : Identifiable, Hashable{

    var id: Int { RMDAttributeId }
    var name: String
    var RMDAttributeId: Int
    var enabled: Bool
    var supported: Bool
        
    init(name: String, RMDAttributeId: Int) {
        self.name = name
        self.RMDAttributeId = RMDAttributeId
        self.enabled = false
        self.supported = false
    }

}
