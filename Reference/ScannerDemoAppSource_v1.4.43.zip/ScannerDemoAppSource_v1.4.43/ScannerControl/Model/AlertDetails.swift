//
//  AlertDetails.swift
//  ScannerControl
//
//   ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation

///Data model for alert details
struct AlertDetails: Identifiable {
    
    let id = UUID()
    var description: String = ""
    var alertType:AlertType
    

    init(alertType: AlertType, description: String = "") {
        self.alertType = alertType
        self.description = description
    }
    
    ///Method to get the description of the alert
    func getDescription() -> String {
        switch self.alertType {
        case .connected:
            return "\(AppState.shared.connectedScanner?.scannerName ?? "") has connected."
        case .disconnectWithOptions:
            return "This will disconnect the application from the scanner, however the device will still be paired to the system."
        case .disconnected:
            return "\(AppState.shared.lastConnectedScanner?.scannerName ?? "") has disconnected."
        case .disableMsg:
            return AppSettings.shared.communicationMode == CommunicationMode.BT_LE.rawValue ? L10n.CommunicationMode.disabledMFiModeAlertMsg: L10n.CommunicationMode.disabledBLEModeAlertMsg
        case .connectionError:
            return "Connection Failed."
        case .actionFailed:
            return "Cannot perform \(self.description) action"
        default:
            return self.description
        }
    }
    
    ///Method to get the title of the alert
    func getTitle() -> String {
        switch self.alertType {
        case .connected:
            fallthrough
        case .disconnected:
            fallthrough
        case .actionFailed:
            return "Zebra Scanner Control"
        case .disableMsg,.none:
            return "Message"
        case .disconnectWithOptions:
            return "Disconnect?"
        case .connectionError:
            return "Error"
        }
    }
    
    ///Action method to dismiss the alert
    func dismissAlert() {
        switch self.alertType {
        case .connected:
            AppState.shared.showAlert = false
        case .disconnectWithOptions:
            break
        case .disconnected, .none:
            AppState.shared.showAlert = false
        case .disableMsg:
            break
        case .connectionError:
            break
        case .actionFailed:
            break
        }
    }
    
    ///Disconnect the connected scanner
    func disconnectScanner() {
        dismissAlert()
        ZebraSDKManager.shared.disconnectScanner(scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
    }
}

extension AlertDetails {
    /// Enum for alert types
    enum AlertType: Hashable, CaseIterable {
        case connected
        case disconnectWithOptions
        case disconnected
        case disableMsg
        case connectionError
        case actionFailed
        case none
    }
}


