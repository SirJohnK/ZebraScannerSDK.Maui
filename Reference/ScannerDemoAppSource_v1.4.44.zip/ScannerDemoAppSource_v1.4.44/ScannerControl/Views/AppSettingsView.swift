//
//  AppSettingsView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct AppSettingsView: View {
    
    @StateObject private var viewModel = ViewModel()
    @Environment(\.colorScheme) var colorScheme
    @State var showAlert = false
    let alertDetails = AlertDetails(alertType: .none, description: L10n.ComingSoon.text)
    
    
    var body: some View {
        Form {
            Section {
                Button(){
                    viewModel.resetDefaults()
                } label: {
                    Text(L10n.AppSettings.resetDefaultsLabel)
                } .disabled(!viewModel.enableResetDefaults)
            }
            Section(header: Text(L10n.AppSettings.communicationModeHeader)) {
                NavigationLink {
                    CommunicationModeView(viewModel: viewModel)
                } label: {
                    HStack {
                        Text(L10n.AppSettings.communicationModeLabel).fixedSize()
                        Spacer()
                        Text(viewModel.selectedCommunicationMode)
                            .lineLimit(1)
                    }
                }
            }
            Section(header: Text(L10n.AppSettings.setFactoryDefaultHeader)) {
                Toggle(L10n.AppSettings.setFactoryDefaultToggleText, isOn: $viewModel.setFactoryDefaults)
            }
            
            Section(header: Text(L10n.AppSettings.backgroundNotificationsLabel)) {
                Toggle(L10n.AppSettings.availableScannerLabel, isOn: $viewModel.availableScannerBgNotification)
                Toggle(L10n.AppSettings.activeScannerLabel, isOn: $viewModel.activeScannerBgNotification)
                Toggle(L10n.AppSettings.barcodeEventLabel, isOn: $viewModel.barcodeEventBgNotification)
            }
            
            Section(header: Text(L10n.AppSettings.scannerDiscoveryLabel)) {
                Toggle(L10n.AppSettings.scannerDiscoveryToggleLabel, isOn: $viewModel.discoverBluetoothscanners)
            }
            
            Section(header: Text(L10n.AppSettings.autoConnectLabel),footer: Text(L10n.AppSettings.autoConnectFooterLabel), content:{
                Toggle(L10n.AppSettings.autoConnectToggleLabel, isOn: $viewModel.autoReconnectOnRelaunch)
            }
            )
        }
        .navigationBarTitle(L10n.AppSettings.navTitle)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            viewModel.checkDefaults()
        }
        .alert(alertDetails.getTitle(), isPresented: $showAlert, presenting: alertDetails) { alertDetails in
            Button("OK"){
                alertDetails.dismissAlert()
            }
            
        }message: { alertDetails in
            Text("\(alertDetails.getDescription())")
        }
    }
}

struct AppSettingsView_Previews: PreviewProvider {
    static var previews: some View {
        AppSettingsView()
    }
}
