//
//  SampleBarcodeView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct SampleBarcodeView: View {
    @ObservedObject var viewModel : DataView.ViewModel
    @Environment(\.colorScheme) var colorScheme
    @EnvironmentObject var appState: AppState
    @Environment(\.presentationMode) var presentationMode
    
    
    var body: some View {
        Form {
            Section(header: Text(L10n.DataView.SampleBarcodeView.sectionHeader)) {
                ForEach(self.viewModel.sampleBarcodes,id: \.self) { (barcode: SampleBarcodeType) in
                    HStack {
                        Button(action: {
                            viewModel.selectedSampleBarcode = barcode
                            viewModel.getBarcodeImage(barcodeType: barcode)
                        }) {
                            HStack{
                                Text(barcode.rawValue)
                                    .foregroundColor(
                                        colorScheme == .dark ? .white : .black
                                    )
                                Spacer()
                                if viewModel.selectedSampleBarcode == barcode {
                                    Asset.checkMark.swiftUIImage
                                }
                            }
                        }.buttonStyle(BorderlessButtonStyle())
                    }
                    
                }
            }
            Section {
                HStack(alignment: .center){
                    Spacer()
                    if (UIDevice.current.orientation == .portrait) {
                        Image(uiImage: viewModel.barcodeImage ?? Asset.upc.image)
                            .resizable()
                            .scaledToFit()
                            .frame( width: UIScreen.main.bounds.width * 0.7, height: UIScreen.main.bounds.height * 0.2,alignment:.center)
                    } else {
                        Image(uiImage: viewModel.barcodeImage ?? Asset.upc.image)
                            .resizable()
                            .scaledToFit()
                            .frame( width: UIScreen.main.bounds.width * 0.63, height: UIScreen.main.bounds.height * 0.2,alignment:.center)
                    }
                    Spacer()
                }
            }
        }
        .navigationBarTitle(L10n.DataView.SampleBarcodeView.navTitle)
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of:  appState.scannerBarcodeList) { _ in
            presentationMode.wrappedValue.dismiss()
        }
    }
}

struct SampleBarcodeView_Previews: PreviewProvider {
    static var previews: some View {
        SampleBarcodeView(viewModel: DataView.ViewModel())
    }
}

enum SampleBarcodeType: String, CaseIterable {
    case UPC = "UPC"
    case CODE_128 = "Code 128"
    case DATAMATRIX = "Datamatrix"
}
