//
//  BleConnectView.swift
//  ScannerControl
//
//   ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI
import UIKit

struct BleConnectView: View {
    
    @StateObject private var viewModel = ViewModel()
    @EnvironmentObject var appState: AppState
    @Environment(\.colorScheme) var colorScheme
    @State  var showAlertMessage = false
    var body: some View {
        
        NavigationView {
            ZStack {
                Color(colorScheme == .dark ? .black : .secondarySystemBackground).edgesIgnoringSafeArea(.all)
                VStack(alignment: .leading) {
                    Text(L10n.BtLe.stcDescriptionText).foregroundColor(Asset.lightTextColor.swiftUIColor).padding(20)
                    Spacer()
                    VStack {
                        VStack(alignment: .center) {
                            Image(uiImage: viewModel.stcBarcodeImage)
                                .resizable()
                                .aspectRatio(contentMode:.fit)
                                .scaledToFit()
                        }
                        .padding(20)
                        .background(.white)
                        .cornerRadius(15)
                    }.padding([.leading, .trailing], 20)
                    Spacer()
                    
                    VStack(alignment: .leading) {
                        Text("\(L10n.BtLe.stcBarcodeText)\n").foregroundColor(Asset.lightTextColor.swiftUIColor).font(.system(size: 13))
                        Text(viewModel.currentSetting ?? "").foregroundColor(Asset.lightTextColor.swiftUIColor).font(.system(size: 13))
                        Text(L10n.BtLe.settingGuideText).foregroundColor(Asset.lightTextColor.swiftUIColor).font(.system(size: 13)).italic()
                    }.padding(20)
                    
                }.frame(maxWidth: .infinity, maxHeight: .infinity)
                    .navigationBarTitle(L10n.BtLe.navTitle)
                
            }.frame(maxWidth: .infinity).background(Color.gray)
        }
        
        .navigationViewStyle(StackNavigationViewStyle())
        .onAppear{
            viewModel.getTextBasedOnFactoryDefaultSetting()
            if (UIDevice.current.orientation == .portrait) {
                viewModel.getSTCPairingBarcode(imageWidth: UIScreen.main.bounds.width * 0.7, imageHeight: UIScreen.main.bounds.height * 0.2)
            } else {
                
                viewModel.getSTCPairingBarcode(imageWidth: UIScreen.main.bounds.width * 0.63, imageHeight: UIScreen.main.bounds.height * 0.2)
            }
        }
        .detectOrientation($viewModel.orientation)
        .alert(viewModel.alertDetails.getTitle(), isPresented: $showAlertMessage, presenting: viewModel.alertDetails) { alertDetails in
            Button("OK"){
                alertDetails.dismissAlert()
            }
        }message: { alertDetails in
            Text("\(alertDetails.getDescription())")
        }
        .onChange(of: appState.showAlert) { newValue in
            if (newValue){
                showAlertMessage = true
            }
        }
    }
}

struct BleConnectView_Previews: PreviewProvider {
    static var previews: some View {
        BleConnectView()
    }
}
