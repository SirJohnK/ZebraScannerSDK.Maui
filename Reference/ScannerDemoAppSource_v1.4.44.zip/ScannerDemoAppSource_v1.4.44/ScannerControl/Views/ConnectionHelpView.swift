//
//  ConnectionHelpView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct ConnectionHelpView: View {
    var body: some View {
        Form {
            Section() {
                NavigationLink {
                    SupportedScannersView()
                } label: {
                    Text(L10n.ConnectionHelp.supportedScanners)
                }
                NavigationLink {
                    PairingHelpView()
                } label: {
                    Text(L10n.ConnectionHelp.pairingHelp)
                }
            }
        }
        .navigationBarTitle(L10n.ConnectionHelp.navTitle)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct ConnectionHelpView_Previews: PreviewProvider {
    static var previews: some View {
        ConnectionHelpView()
    }
}

