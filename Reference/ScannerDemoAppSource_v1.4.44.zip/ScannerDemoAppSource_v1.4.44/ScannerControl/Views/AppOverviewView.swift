//
//  AppOverviewView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct AppOverviewView: View {
    
    @StateObject private var viewModel = ViewModel()
    
    var body: some View {
        Form {
            Section {
                HStack {
                    Text(L10n.AppOverview.scannerControlVersion)
                    Spacer()
                    Text(viewModel.appVersion ?? "-")
                        .foregroundColor(Asset.lightTextColor.swiftUIColor)
                }
                HStack {
                    Text(L10n.AppOverview.scannerSDKVersion)
                    Spacer()
                    Text(viewModel.sdkVersion ?? "-")
                        .foregroundColor(Asset.lightTextColor.swiftUIColor)
                }
            }
            Section() {
                Text("\(L10n.AppOverview.copyrightYear) \(L10n.AppOverview.copyrightMessage)")
                    .multilineTextAlignment(.center)
            }
        }
        .navigationBarTitle(L10n.AppOverview.title)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            self.viewModel.getScannerControlAppVersion()
            self.viewModel.getScannerSDKVersion()
        }
    }
}

struct AppOverviewView_Previews: PreviewProvider {
    static var previews: some View {
        AppOverviewView()
    }
}
