//
//  LoadingView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

///Common loading progress view to be loaded while doing background tasks
struct LoadingView: View {
    
    @EnvironmentObject var appState: AppState
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        if (appState.loading) {
            ZStack {
                if (colorScheme == .dark) {
                    Color.black.opacity(0.8)
                } else {
                    Color.white.opacity(0.9)
                }
                ProgressView {
                    Text(appState.loadingText)
                        .foregroundColor(.gray)
                        .fontWeight(.regular)
                }
            }
        }
    }
}

struct LoadingView_Previews: PreviewProvider {
    static var previews: some View {
        LoadingView()
    }
}
