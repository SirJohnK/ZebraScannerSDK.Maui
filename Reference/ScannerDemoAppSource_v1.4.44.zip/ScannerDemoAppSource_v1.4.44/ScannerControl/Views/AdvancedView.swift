//
//  AdvancedView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct AdvancedView: View {
    @StateObject private var viewModel = ViewModel()
    @State var isUpdateFirmwareScreenActive: Bool = false
    @State private var condition = false
    @Environment(\.colorScheme) var colorScheme
    let alertDetails = AlertDetails(alertType: .none, description: L10n.VirtualTether.virtualTetherNotSupportedAlertText)
    @State var showAlert: Bool = false
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        
        NavigationView {
            Form {
                Section {
                    HStack() {
                        Spacer()
                        Button(action: {
                            viewModel.startFindScannerAction()
                        }) {
                            HStack {
                                Text("Find Scanner").bold()
                            }.frame(width: 300, height: 50)
                        }
                        .frame(width: 300, height: 50)
                        .buttonStyle(CustomButtonStyle())
                        .background(Asset.blueColor.swiftUIColor)
                        .cornerRadius(5)
                        .disabled(!viewModel.enableFindScannerButton)
                        Spacer()
                        
                    }
                    .frame(height: 60,alignment: .center)
                }
                Section() {
                    NavigationLink {
                        AssetInfoView()
                    } label: {
                        Text(L10n.Advanced.assetInformation)
                    }

                    NavigationLink {
                        BatteryStatisticsView(viewModel: viewModel)
                    } label: {
                        Text(L10n.Advanced.batteryStatistics)
                    }
                    if (appState.isVirtualTetherSupported) {
                        NavigationLink (isActive: $appState.isVirtualTetherScreenActive){
                            VirtualTetherView()
                        } label: {
                            Text(L10n.Advanced.virtualTether)
                        }
                    } else {
                        HStack {
                            Button(action: {
                                self.showAlert = true
                            }) {
                                Text(L10n.Advanced.virtualTether)
                                    .foregroundColor(colorScheme == .dark ? .white : .black)
                            }
                            Spacer()
                            Image(asset: Asset.rightNav).frame(width: 12).font(Font.system(size: 12, weight: .semibold))
                                .foregroundColor(.gray.opacity(0.5))
                        }
                    }
                    NavigationLink(isActive: $isUpdateFirmwareScreenActive) {
                        UpdateFirmwareView()
                    } label: {
                        Text(L10n.Advanced.updateFirmware)
                    }
                }
            }
            .alert("Zebra Scanner Control", isPresented: $showAlert, presenting: alertDetails) { alertDetails in
                Button("OK"){
                    alertDetails.dismissAlert()
                }
                
            }message: { alertDetails in
                Text("\(alertDetails.getDescription())")
            }
            .safeAreaInset(edge: .top){
                Color.clear.frame(height: 20)
            }
            .navigationTitle(L10n.Advanced.navTitle)
        } 
        .onChange(of: appState.isScannerConnected) { _ in
            //start virtual tether when scanner disconnection happens
            if (!appState.isScannerConnected && AppState.shared.virtualTetherHostActivated) {
                DispatchQueue.main.async {
                    appState.isVirtualTetherScreenActive = true
                }
            }
        }
        .onAppear {
            if (!AppState.shared.virtualTetherHostActivated) {
                viewModel.getVirtualTetherSupportedStatus()
            }
            if (AppState.shared.isRebootCompleted) {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.isUpdateFirmwareScreenActive = true
                }
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
        
    }
}

struct AdvancedView_Previews: PreviewProvider {
    static var previews: some View {
        AdvancedView()
    }
}

