//
//  AvailableDeviceListView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct AvailableDeviceListView: View {
    
    @EnvironmentObject var appState: AppState
    @Environment(\.colorScheme) var colorScheme
    @StateObject private var viewModel = ViewModel()
    
    @State private var showConnectedScannerSection = false
    @State private var isCurrentlyConnected = false
    @State private var connectedScannerSectionText = ""
    @State  var showAlertMessage = false
    
    var body: some View {
        Form {
            if (showConnectedScannerSection){
                Section(header: Text(connectedScannerSectionText) ) {
                    HStack{
                        Text(viewModel.lastConnectedOrCurrentConnectedScaner?.scannerName ?? "")
                        Spacer()
                        if (isCurrentlyConnected){
                            Asset.checkMark.swiftUIImage.foregroundColor(.blue)
                        }else{
                            if (appState.connectionInProgress && AppState.shared.lastConnectedScanner?.scannerId ?? 0 == viewModel.selectedScannerFromList?.scannerId ?? -1){
                                ProgressView()
                            } else {
                                Image(asset: Asset.rightNav)
                            }
                        }
                    }.onTapGesture {
                        if (!appState.connectionInProgress && !isCurrentlyConnected) {
                            viewModel.selectedScannerFromList = viewModel.lastConnectedOrCurrentConnectedScaner
                            viewModel.connectScanner()
                        }
                    }
                }
            }
            Section(header: Text("Other Scanners")){
                ForEach(viewModel.otherScannersList,id: \.self) { scanner in
                    HStack{
                        Text(scanner.scannerName).foregroundColor(viewModel.selectedScannerFromList?.scannerId != scanner.scannerId && appState.connectionInProgress ? Asset.lightTextColor.swiftUIColor : (colorScheme == .dark ? .white : .black))
                        Spacer()
                        if (appState.connectionInProgress && viewModel.selectedScannerFromList?.scannerId == scanner.scannerId) {
                            ProgressView()
                        } else {
                            Image(asset: Asset.rightNav).foregroundColor(viewModel.selectedScannerFromList?.scannerId != scanner.scannerId && appState.connectionInProgress ? Asset.lightTextColor.swiftUIColor : (colorScheme == .dark ? .white : .black))
                        }

                    }.onTapGesture {
                        viewModel.selectedScannerFromList = scanner
                        if (!appState.connectionInProgress) {
                            if(isCurrentlyConnected) {
                                showAlertMessage = true
                            } else {
                                viewModel.connectScanner()
                            }
                        }
                    }
                }
            }
        }
        .navigationBarTitle(L10n.AvailableDeviceList.navTitle)
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of: appState.availableScannerList) { _ in
            viewModel.getOtherScannerList()
        }
        .onAppear(){
            if(appState.isScannerConnected){
                connectedScannerSectionText  = "Currently Connected Scanner"
                showConnectedScannerSection = true
                isCurrentlyConnected = true
            }else if (appState.lastConnectedScanner != nil){
                connectedScannerSectionText  = "Last Connected Scanner"
                showConnectedScannerSection = true
                isCurrentlyConnected = false
                appState.connectionInProgress = false
            }
            viewModel.LoadScannerList()
        }
        .alert(viewModel.connectionFailureAlert.getTitle(), isPresented: $appState.connectionFailed, presenting: viewModel.connectionFailureAlert) { alertDetails in
            Button("OK"){
                alertDetails.dismissAlert()
            }
            
        }message: { alertDetails in
            Text("\(alertDetails.getDescription())")
        }
        .alert(viewModel.alertDetails.getTitle(), isPresented: $showAlertMessage, presenting: viewModel.alertDetails) { alertDetails in
            Button("Cancel"){
                showAlertMessage = false
                alertDetails.dismissAlert()
            }
            Button("Continue"){
                showAlertMessage = false
                viewModel.connectScanner()
            }
        }message: { alertDetails in
            Text("\(alertDetails.getDescription())")
        }
        
    }
}

struct AvailableDeviceListView_Previews: PreviewProvider {
    static var previews: some View {
        AvailableDeviceListView()
    }
}
