//
//  VibrationFeedbackView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct VibrationFeedbackView: View {
    
    @StateObject private var viewModel = ViewModel()
    @Environment(\.colorScheme) var colorScheme


    var body: some View {
        Form {
            Section{
                Toggle(L10n.VibrationFeedback.vibrationToggleText, isOn: $viewModel.vibrationStatus)
                    .onChange(of: viewModel.vibrationStatus) { value in
                        viewModel.setVibrationStatus()
                }
            }
            Section {
                
                ForEach(self.viewModel.vibrationDurationList) { (duration: VibrationDuration) in
                    HStack {
                        Button(action: {
                            viewModel.selectedDuration = duration
                        }) {
                            HStack{
                                Text("\(duration.actionName) ms")
                                    .foregroundColor(
                                        colorScheme == .dark ? .white : .black
                                    )
                                Spacer()
                                if viewModel.selectedDuration == duration {
                                    Asset.checkMark.swiftUIImage
                                }
                            }
                            .alert(viewModel.alertDetails.getTitle(), isPresented: $viewModel.vibrationNotSupportedAlert, presenting: viewModel.alertDetails) { alertDetails in
                                Button("OK"){
                                    alertDetails.dismissAlert()
                                }
                            }message: { alertDetails in
                                Text("\(alertDetails.getDescription())")
                            }
                        }.buttonStyle(BorderlessButtonStyle())
                    }.disabled(!viewModel.vibrationStatus)
                    
                }
            }
            Section {
                HStack() {
                    Spacer()
                    Button(action: {
                        viewModel.performVibrationFeedback()
                    }) {
                        HStack {
                            Text(L10n.VibrationFeedback.vibrateText).bold()
                        }.frame(width: 300, height: 50)
                    }
                    .frame(width: 300, height: 50)
                    .buttonStyle(CustomButtonStyle())
                    .background(Asset.blueColor.swiftUIColor)
                    .cornerRadius(5)
                    .disabled(!viewModel.vibrationStatus)
                    Spacer()
                    
                }
                .frame(height: 60,alignment: .center)
            }
        }
        .navigationBarTitle(L10n.Settings.VibrationFeedback.navTitle)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct VibrationFeedbackView_Previews: PreviewProvider {
    static var previews: some View {
        VibrationFeedbackView()
    }
}
