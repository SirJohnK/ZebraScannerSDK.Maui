//
//  BarcodeDetailView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct BarcodeDetailView: View {
    @Environment(\.presentationMode) var presentationMode
    @EnvironmentObject var appState: AppState
    @ObservedObject var viewModel : DataView.ViewModel
    
    var body: some View {
        Form {
            Section() {
                HStack {
                    Text(L10n.DataView.DetailView.scannerIDLabel)
                    Spacer()
                    Text(String(appState.connectedScanner?.scannerId ?? 0)).foregroundColor(Asset.lightTextColor.swiftUIColor)
                }
                HStack {
                    Text(L10n.DataView.DetailView.barcodeTypeLabel)
                    Spacer()
                    Text((viewModel.selectedBarcodeData?.getBarcodeTypeAsString() ?? "").trimmingCharacters(in: .whitespacesAndNewlines)).foregroundColor(Asset.lightTextColor.swiftUIColor)
                }
                VStack(alignment: .leading) {
                    Text(L10n.DataView.DetailView.barcodeDataLabel)
                    Text("\n\(viewModel.selectedBarcodeData?.barcodeText ?? "")").foregroundColor(Asset.lightTextColor.swiftUIColor)
                }
            }
        }
        .navigationBarTitle(L10n.DataView.DetailView.navTitle)
        .navigationBarTitleDisplayMode(.inline)
        .onChange(of:  appState.scannerBarcodeList) { _ in
            presentationMode.wrappedValue.dismiss()
        }
    }
}

struct BarcodeDetailView_Previews: PreviewProvider {
    static var previews: some View {
        BarcodeDetailView(viewModel: DataView.ViewModel())
    }
}
