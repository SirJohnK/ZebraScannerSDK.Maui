//
//  PairingHelpBTLEView.swift
//  ScannerControl
//
//   ©2023 Zebra Technologies Corp. and/or its affiliates. All rights reserved.
//

import SwiftUI

//Common Pairing Help view for BTLE connection 
struct PairingHelpBTLEView: View {
    var scannerName : String
    var body: some View {
        Form () {
            Section {
                
                Text("\(L10n.Btle.instruction1) \(scannerName).")
                Text(L10n.Btle.instruction2)
                Text(L10n.Btle.instruction3)
                Text(L10n.Btle.instruction4)
                
            }.listRowSeparator(.hidden)
        }.navigationBarTitle("Pair \(scannerName)")
            .navigationBarTitleDisplayMode(.inline)
    }
}

struct PairingHelpBTLEView_Previews: PreviewProvider {
    static var previews: some View {
        PairingHelpBTLEView(scannerName: "")
    }
}
