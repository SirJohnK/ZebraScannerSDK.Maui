//
//  BatteryStatisticsView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct BatteryStatisticsView: View {
    @ObservedObject var viewModel : AdvancedView.ViewModel

    var body: some View {
        Form {
            if viewModel.unsupportedBattery {
                Section() {
                    Text(L10n.BatteryDetail.unsupportedScannerText)
                }
            } else {
                Section(L10n.BatteryDetail.header1){
                    BatteryDetailItemView(label: L10n.BatteryDetail.manufactureDateText, value: viewModel.batteryStatictics?.manufactureDate ?? "")
                    if UIDevice.current.userInterfaceIdiom == .pad {
                        BatteryDetailItemView(label: L10n.BatteryDetail.serialNumberText, value: viewModel.batteryStatictics?.serialNumber ?? "")
                    } else {
                        VStack(alignment: .leading) {
                            Text(L10n.BatteryDetail.serialNumberText)
                            Text((viewModel.batteryStatictics?.serialNumber ?? "").trimmingCharacters(in: .whitespacesAndNewlines)).foregroundColor(Asset.lightTextColor.swiftUIColor).multilineTextAlignment(.trailing)
                        }
                    }
                    BatteryDetailItemView(label: L10n.BatteryDetail.modelNumberText, value: viewModel.batteryStatictics?.modelNumber ?? "")
                    BatteryDetailItemView(label: L10n.BatteryDetail.designCapacityText, value: "\(viewModel.batteryStatictics?.designCapacity ?? "") mAh")

                }
                Section(L10n.BatteryDetail.header2){
                    BatteryDetailItemView(label: L10n.BatteryDetail.stateOfHealthText, value: "\(viewModel.batteryStatictics?.stateOfHealth ?? "")%")
                    BatteryDetailItemView(label: L10n.BatteryDetail.chargeCyclesText, value: viewModel.batteryStatictics?.chargeCyclesConsumed ?? "")

                }
                Section(L10n.BatteryDetail.header3){
                    BatteryDetailItemView(label: L10n.BatteryDetail.fullChargeCapacityText, value: "\(viewModel.batteryStatictics?.fullChargeCapacity ?? "") mAh")
                    BatteryDetailItemView(label: L10n.BatteryDetail.stateOfChargeText, value: "\(viewModel.batteryStatictics?.stateOfCharge ?? "")%")
                    BatteryDetailItemView(label: L10n.BatteryDetail.remainingCapacityText, value: "\(viewModel.batteryStatictics?.remainingCapacity ?? "") mAh")
                }
                Section(L10n.BatteryDetail.header4){
                    BatteryDetailItemView(label: L10n.BatteryDetail.temperaturePresentText, value: viewModel.batteryStatictics?.currentTemperature ?? "")
                    BatteryDetailItemView(label: L10n.BatteryDetail.temperatureHighestText, value: viewModel.batteryStatictics?.highestTemperature ?? "")
                    BatteryDetailItemView(label: L10n.BatteryDetail.temperatureLowestText, value: viewModel.batteryStatictics?.lowestTemperature ?? "")
                }
                
            }
        }
        .navigationBarTitle(L10n.Advanced.BatteryStatistics.navTitle)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            viewModel.getBatteryStatictics()
        }
    }
}

struct BatteryDetailItemView: View {
    var label: String
    var value: String
    var body: some View {
        HStack {
            Text(label)
            Spacer()
            Text(value.trimmingCharacters(in: .whitespacesAndNewlines)).foregroundColor(Asset.lightTextColor.swiftUIColor).multilineTextAlignment(.trailing)
        }
    }
}

struct BatteryStatisticsView_Previews: PreviewProvider {
    static var previews: some View {
        BatteryStatisticsView(viewModel: AdvancedView.ViewModel())
    }
}
