//
//  MainView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct MainTabView: View {
    
    @StateObject private var viewModel = ViewModel()
    @EnvironmentObject var appState: AppState
    @State var showDisabledMsg: Bool = false
    @State var alreadySelectedTab: Tab = AppState.shared.selectedTab
    
    var body: some View {
        TabView(selection: $appState.selectedTab) {
            if !appState.isScannerConnected && !AppState.shared.virtualTetherHostActivated {
                BleConnectView()
                    .tabItem{
                        Label(L10n.BtLe.tabTitle,image: Asset.MainTabBar.ble.name)
                    }
                    .tag(Tab.BLE)
                MfiConnectView()
                    .tabItem{
                        Label(L10n.MFi.tabTitle,image: Asset.MainTabBar.mfi.name)
                    }
                    .tag(Tab.MFI)
                
                MoreView()
                    .tabItem{
                        Label(L10n.More.tabTitle,image: Asset.moreIcon.name)
                    }
                    .tag(Tab.MORE)
            } else {
                SettingsView()
                    .tabItem{
                        Label(L10n.Settings.tabTitle,image: Asset.MainTabBar.settings.name)
                    }
                    .tag(Tab.SETTINGS)
                DataView()
                    .tabItem{
                        Label(L10n.DataView.tabTitle,image: Asset.dataViewIcon.name)
                    }
                    .tag(Tab.DATA_VIEW)
                    .tabViewStyle(.page)
                AdvancedView()
                    .tabItem{
                        Label(L10n.Advanced.tabTitle,image: Asset.advancedIcon.name)
                    }
                    .tag(Tab.ADVANCED)
                MoreView()
                    .tabItem{
                        Label(L10n.More.tabTitle,image: Asset.moreIcon.name)
                    }
                    .tag(Tab.MORE)
            }
        }
        .alert(viewModel.alertDetails.getTitle(), isPresented: $showDisabledMsg, presenting: viewModel.alertDetails) { alertDetails in
            Button("OK"){
                alertDetails.dismissAlert()
            }
            
        }message: { alertDetails in
            Text("\(alertDetails.getDescription())")
        }
        .onChange(of: appState.selectedTab) { _ in
            if (appState.selectedTab == .BLE && AppSettings.shared.communicationMode == CommunicationMode.MFI.rawValue) {
                showDisabledMsg = true
                appState.selectedTab = alreadySelectedTab
            } else if (appState.selectedTab == .MFI && AppSettings.shared.communicationMode == CommunicationMode.BT_LE.rawValue) {
                showDisabledMsg = true
                appState.selectedTab = alreadySelectedTab
            } else if (appState.isFirmwareUpdating && (appState.selectedTab == .SETTINGS || appState.selectedTab == .DATA_VIEW || appState.selectedTab == .MORE )) {
                appState.selectedTab = alreadySelectedTab
            }else {
                alreadySelectedTab = appState.selectedTab
            }
        }

        
    }
}


extension MainTabView {
    enum Tab: Hashable {
        case BLE
        case MFI
        case MORE
        case SETTINGS
        case ADVANCED
        case DATA_VIEW
    }
}

struct MainView_Previews: PreviewProvider {
    
    static var previews: some View {
        MainTabView()
    }
}
