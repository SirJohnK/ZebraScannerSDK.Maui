//
//  AppSettingsView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct MoreView: View {
    
    @EnvironmentObject var appState: AppState
    @StateObject private var viewModel = ViewModel()
    @State  var showAlertMessage = false

    var body: some View {
        NavigationView {
            Form {
                Section() {
                    if self.appState.isScannerConnected {
                        Button() {
//                            viewModel.disconnectScanner()
                            showAlertMessage = true
                        } label: {
                            Label {
                                Text(L10n.More.disconnectScannerButtonText)
                            } icon: {
                                Image(asset: Asset.disconnectIcon).resizable().scaledToFit().frame(width: 23,height: 23)
                            }                        }
                    }
                    NavigationLink {
                        AvailableDeviceListView()
                    } label: {
                        Label(L10n.More.availableDeviceList, image: Asset.arrowRight.name)
                    }
                    NavigationLink {
                        ConnectionHelpView()
                    } label: {
                        Label(L10n.More.connectionHelp, image: Asset.connectionHelpIcon.name)
                    }
                    NavigationLink {
                        AppSettingsView()
                    } label: {
                        Label(L10n.More.appSettings, image: Asset.appSettingsIcon.name)
                    }
                    NavigationLink {
                        AppOverviewView()
                    } label: {
                        Label(L10n.More.appOverview, image: Asset.appOverviewIcon.name)
                    }
                }
            }
            .safeAreaInset(edge: .top){
                Color.clear.frame(height: 20)
            }
            .navigationTitle(L10n.More.navTitle)
            .navigationBarTitleDisplayMode(.automatic)
            .alert(viewModel.alertDetails.getTitle(), isPresented: $showAlertMessage, presenting: viewModel.alertDetails) { alertDetails in
                Button("Cancel"){
                    alertDetails.dismissAlert()
                }
                Button("Continue"){
                    alertDetails.disconnectScanner()
                }
            }message: { alertDetails in
                Text("\(alertDetails.getDescription())")
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct MoreView_Previews: PreviewProvider {
    static var previews: some View {
        MoreView()
    }
}
