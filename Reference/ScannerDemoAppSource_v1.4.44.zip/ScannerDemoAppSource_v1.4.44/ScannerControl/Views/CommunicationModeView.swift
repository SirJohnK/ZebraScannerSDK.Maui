//
//  CommunicationModeView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct CommunicationModeView: View {
    
    @ObservedObject var viewModel : AppSettingsView.ViewModel
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        Form {
            Section {
                ForEach(CommunicationMode.allCases,id:\.self) { (communicationMode: CommunicationMode) in
                    HStack {
                        Button(action: {
                            viewModel.selectedCommunicationMode = communicationMode.rawValue
                        }) {
                            HStack{
                                Text(communicationMode.rawValue)
                                    .foregroundColor(
                                        colorScheme == .dark ? .white : .black
                                    )
                                Spacer()
                                if viewModel.selectedCommunicationMode == communicationMode.rawValue {
                                    Asset.checkMark.swiftUIImage
                                }
                            }
                        }.buttonStyle(BorderlessButtonStyle())
                    }
                    
                }
            }
        }
        .navigationBarTitle(L10n.AppSettings.communicationModeLabel)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct CommunicationModeView_Previews: PreviewProvider {
    static var previews: some View {
        CommunicationModeView(viewModel: AppSettingsView.ViewModel())
    }
}
