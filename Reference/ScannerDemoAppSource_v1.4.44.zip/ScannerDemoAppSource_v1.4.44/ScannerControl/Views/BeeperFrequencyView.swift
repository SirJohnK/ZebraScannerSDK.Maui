//
//  BeeperFrequencyView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct BeeperFrequencyView: View {
    
    @ObservedObject var viewModel : BeeperView.ViewModel
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        Form {
            Section {
                ForEach(self.viewModel.beeperFrequencyList) { (beeperFrequency: BeeperFrequency) in
                    HStack {
                        Button(action: {
                            viewModel.selectedFrequency = beeperFrequency
                            viewModel.updateBeeperFrequency()
                        }) {
                            HStack{
                                Text(beeperFrequency.actionName)
                                    .foregroundColor(
                                        colorScheme == .dark ? .white : .black
                                    )
                                Spacer()
                                if viewModel.selectedFrequency == beeperFrequency {
                                    Asset.checkMark.swiftUIImage
                                }
                            }
                        }.buttonStyle(BorderlessButtonStyle())
                    }
                    
                }
            }
        }
        .navigationBarTitle(L10n.BeeperSettings.Frequency.navTitle)
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct BeeperFrequencyView_Previews: PreviewProvider {
    static var previews: some View {
        BeeperFrequencyView(viewModel: BeeperView.ViewModel())
    }
}
