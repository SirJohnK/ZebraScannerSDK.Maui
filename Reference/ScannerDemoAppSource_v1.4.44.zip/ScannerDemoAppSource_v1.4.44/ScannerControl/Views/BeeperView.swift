//
//  BeeperView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI

struct BeeperView: View {
    
    @StateObject private var viewModel = ViewModel()
    
    var body: some View {
        Form {
            Section() {
                NavigationLink {
                    BeeperVolumeView(viewModel: viewModel)
                } label: {
                    HStack {
                        Text(L10n.BeeperSettings.volumeLabel).fixedSize()
                        Spacer()
                        Text(viewModel.selectedVolume?.actionName ?? "")
                            .lineLimit(1)
                    }
                }
                NavigationLink {
                    BeeperFrequencyView(viewModel: viewModel)
                } label: {
                    HStack {
                        Text(L10n.BeeperSettings.frequencyLabel).fixedSize()
                        Spacer()
                        Text(viewModel.selectedFrequency?.actionName ?? "")
                            .lineLimit(1)
                    }
                    
                }
                NavigationLink {
                    BeeperSequenceView(viewModel: viewModel)
                } label: {
                    Text(L10n.BeeperSettings.sequenceLabel).fixedSize()
                    Spacer()
                }
            }
        }
        .navigationBarTitle(L10n.Settings.Beeper.navTitle)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            viewModel.getBeeperSettings()
        }
    }
}

struct BeeperView_Previews: PreviewProvider {
    static var previews: some View {
        BeeperView()
    }
}
