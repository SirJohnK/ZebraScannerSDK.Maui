//
//  UpdateFirmwareView.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import SwiftUI
import UniformTypeIdentifiers

struct UpdateFirmwareView: View {
    @StateObject private var viewModel = ViewModel()
    @Environment(\.colorScheme) var colorScheme
    @Environment(\.dismiss) var dismiss
    @EnvironmentObject var appState: AppState
    
    var body: some View {
        VStack{
            Form {
                
                if (!(viewModel.showPluginMatchUI)){
                    Section {
                        HStack() {
                            Spacer()
                            Button(action: {
                                viewModel.selectFirmwareButtonAction()
                            }) {
                                HStack {
                                    Text(L10n.UpdateFirmwareView.selectFirmwareButtonText).bold()
                                }.frame(width: 300, height: 50)
                            }
                            .frame(width: 300, height: 50)
                            .buttonStyle(CustomButtonStyle())
                            .background(Asset.blueColor.swiftUIColor)
                            .cornerRadius(5)
                            Spacer()
                            
                        }.frame(height: 100,alignment: .center)
                    }
                } else {
                    
                    Section {
                        
                        Text(viewModel.selectedFirmwareFile?.fileName ?? "")
                            .bold()
                            .font(.system(size:16))
                        if (viewModel.selectedFirmwareFile?.fileType == FirmwareFileType.SCNPLG) {
                            HStack(alignment:.center){
                                Image(uiImage:viewModel.selectedFirmwareFile?.pluginScannerImage ?? UIImage())
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 200, height: 200)
                            }.frame(maxWidth: .infinity)
                        }
                    }.listRowSeparator(.hidden)
                    
                    Section {
                        if (viewModel.selectedFirmwareFile?.fileType == FirmwareFileType.SCNPLG) {
                            NavigationLink {
                                ReleaseNoteView(viewModel: viewModel)
                            } label: {
                                Text("Release Notes")
                            }
                        }
                    }
                    
                    if (AppState.shared.isRebootCompleted) {
                        Section {
                            HStack {
                                Text("\nCurrent: Release \(viewModel.selectedFirmwareFile?.getToText(currentFWversion: viewModel.currentFirmwareVersion ?? "") ?? "")")
                                    .foregroundColor(colorScheme == .dark ? .white : .black)
                            }
                            HStack() {
                                Spacer()
                                Button(action: {}){
                                    HStack {
                                        Asset.tick.swiftUIImage.resizable().frame(width: 25, height: 25)
                                        Text(L10n.UpdateFirmwareView.firmwareUpdatedText).bold()
                                    }
                                }
                                .tint(.clear)
                                .frame(width: 300, height: 50)
                                .buttonStyle(.borderedProminent)
                                .background(Asset.greenColor.swiftUIColor)
                                .cornerRadius(5)
                                Spacer()
                                
                            }.frame(height: 100,alignment: .center)
                        }.listRowSeparator(.hidden)
                            .onAppear {
                                if (self.appState.isFirmwareUpdated) {
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
                                        AppState.shared.isFirmwareUpdated = false
                                    }
                                }
                            }
                    } else {
                        Section {
                            HStack {
                                Text("From")
                                Spacer()
                                Text(viewModel.currentFirmwareVersion?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "")
                                    .foregroundColor(Asset.lightTextColor.swiftUIColor)
                            }
                            HStack {
                                Text("To")
                                Spacer()
                                Text(viewModel.selectedFirmwareFile?.getToText(currentFWversion: viewModel.currentFirmwareVersion?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "") ?? "")
                                    .foregroundColor(Asset.lightTextColor.swiftUIColor)
                            }
                            HStack() {
                                Spacer()
                                Button(action: {
                                    viewModel.updateFirmwareButtonAction()
                                }) {
                                    HStack {
                                        Text(L10n.UpdateFirmwareView.updateFirmwareButtonText).bold()
                                    }.frame(width: 300, height: 50)
                                }
                                .frame(width: 300, height: 50)
                                .buttonStyle(CustomButtonStyle())
                                .background(Asset.blueColor.swiftUIColor)
                                .cornerRadius(5)
                                Spacer()
                                
                            }.frame(height: 100,alignment: .center)
                        }
                    }
                }
                
            }
            .disabled(viewModel.showFWUpdateProgressView || viewModel.showRebooting)
        }.sheet(isPresented: $viewModel.showFilePicker, content: {
            Form {
                Section(header:
                            HStack {
                    Spacer()
                    Text(L10n.UpdateFirmwareView.selectFirmwareButtonText)
                        .bold()
                        .font(.system(size:16))
                        .foregroundColor(colorScheme == .dark ? .white : .black)
                        .textCase(.none)
                    Spacer()
                }.padding([.bottom],15))
                {
                    ForEach(viewModel.firmwareFileList,id:\.self) { (item: FirmwareFile) in
                        HStack {
                            Button(action: {
                                viewModel.onFirmwareFileSelected(item: item)
                            }) {
                                HStack{
                                    Text(item.fileName ?? "").font(.system(size: 14)).tint(colorScheme == .dark ? .white : .black)
                                    Spacer()
                                    if viewModel.selectedFirmwareFile == item {
                                        Asset.checkMark.swiftUIImage
                                    }
                                }
                            }.buttonStyle(BorderlessButtonStyle())
                        }.frame(height: 40)
                    }
                }
            }
        })
        .onAppear(){
            if (AppState.shared.isFirmwareUpdated) {
                viewModel.selectedFirmwareFile = AppState.shared.updatedFirmwarePluginFile
                viewModel.showPluginData()
            }
            // if it is enable fast blink led, then disable it
            viewModel.performFastBlinkLed(enable: false)
            viewModel.isNavigatingToReleaseNotes = false
        }
        .onDisappear(){
            if (AppState.shared.isFirmwareUpdated == false && !viewModel.isNavigatingToReleaseNotes) {
                AppState.shared.isRebootCompleted = false
            }
            // If we disconect a scanner and reconnect another on the same app session, it will show previous connected scanner details in the firmware update ui. To avoid that need to dismiss the UI
            if (!AppState.shared.isVirtualTetherScreenActive) {
                dismiss()
            }
        }
        .sheet(isPresented: $viewModel.showHelp) {
            HelpView(colorScheme: colorScheme)
        }
        .alert(viewModel.alertDetails.getTitle(), isPresented: $viewModel.actionNotSupportedAlert, presenting: viewModel.alertDetails) { alertDetails in
            Button("OK"){
                alertDetails.dismissAlert()
            }
        }message: { alertDetails in
            Text("\(alertDetails.getDescription())")
        }
        .overlay(
            viewModel.showPluginMismatch ?  PluginMismatchAlertView(isPresented: $viewModel.showPluginMismatch,colorScheme: colorScheme) : nil
        )
        .overlay(
            viewModel.showFWUpdateProgressView ? FWUpdateProgressView(viewModel: viewModel, appState: appState, colorScheme: colorScheme) : nil
        )
        .overlay(
            viewModel.showRebooting ?  RebootingView( colorScheme: colorScheme) : nil
        )
        .alert(L10n.UpdateFirmwareView.AbortConfirmation.title, isPresented: $viewModel.showAlertForAbortFWUpdate) {
            Button("No") {
                viewModel.dismissAbortFirmwareAlert()
            }
            Button("Yes") {
                viewModel.abortFirmwareUpdate()
            }
        } message: {
            Text(L10n.UpdateFirmwareView.AbortConfirmation.description)
        }
        .navigationBarTitle(L10n.Advanced.UpdateFirmware.navTitle)
        .navigationBarItems(
            trailing:
                HStack {
                    Button(action: {
                        self.viewModel.showHelp.toggle()
                    }) {
                        Asset.connectionHelpIcon.swiftUIImage
                    }.tint(Color.white)
                }
                .disabled(viewModel.showFWUpdateProgressView)
        )
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(viewModel.showFWUpdateProgressView)
    }
    
}

struct UpdateFirmwareView_Previews: PreviewProvider {
    static var previews: some View {
        UpdateFirmwareView()
    }
}

// Firmware update help view
struct HelpView: View {
    var colorScheme: ColorScheme?
    let URL123Scan = try! AttributedString(markdown: "[www.Zebra.com/123Scan](https://www.zebra.com/ap/en/products/software/scanning-systems/scanner-drivers-and-utilities/123scan2-configuration-utility.html)")
    var body: some View {
        Form {
            Section(header:
                        HStack {
                Spacer()
                Text(L10n.UpdateFirmwareView.helpTitle)
                    .bold()
                    .font(.system(size:16))
                    .foregroundColor(colorScheme == .dark ? .white : .black)
                    .textCase(.none)
                Spacer()
            }.padding([.bottom],15)) {
                Text(L10n.UpdateFirmwareView.mainIntructionText)
                Text("\(L10n.UpdateFirmwareView.subInstruction1) \(URL123Scan)")
                Text(L10n.UpdateFirmwareView.subInstruction2)
                Text(L10n.UpdateFirmwareView.subInstruction3).lineLimit(nil)
            }
            .listRowSeparator(.hidden)
        }
    }
}

// Plugin mismatch popup
struct PluginMismatchAlertView: View {
    @Binding var isPresented: Bool
    var colorScheme: ColorScheme?
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.2).edgesIgnoringSafeArea(.all)
            VStack {
                VStack(alignment: .leading, spacing: 20) {
                    HStack {
                        Spacer()
                        Text(L10n.UpdateFirmwareView.pluginMismatchTitle).bold()
                        Spacer()
                    }
                    Text(L10n.UpdateFirmwareView.pluginMismatchInstruction1).font(.system(size: 13))
                    Text(L10n.UpdateFirmwareView.pluginMismatchInstruction2).font(.system(size: 13))
                }
                .padding(20)
                Divider()
                HStack {
                    Button(action: {
                        self.isPresented.toggle()
                    }) {
                        HStack{
                            Spacer()
                            Text("OK")
                            Spacer()
                        }
                    }
                }
                .padding([.bottom],10)
            }
            .background(colorScheme == .dark ? Asset.formColorDark.swiftUIColor : Asset.formColorLight.swiftUIColor)
            .cornerRadius(10)
            .frame(width: 300)
        }
        
    }
}

//Release note view
struct ReleaseNoteView: View {
    @ObservedObject var viewModel : UpdateFirmwareView.ViewModel
    var body : some View {
        Form {
            Section {
                Text(viewModel.selectedFirmwareFile?.releaseNotes ?? "")
                    .font(.system(size:12))
            }
        }
        .navigationBarTitle("Release Notes")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            viewModel.isNavigatingToReleaseNotes = true
        }
    }
}

/// Progress view for firmware update
struct FWUpdateProgressView: View {
    
    @ObservedObject var viewModel : UpdateFirmwareView.ViewModel
    @ObservedObject var appState: AppState
    var colorScheme: ColorScheme?
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.3)
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                VStack(alignment: .leading, spacing: 20) {
                    ProgressView(value: appState.progressOfFirmwareUpdate, total: 100.0) {
                        Text("Updating Firmware")
                    } currentValueLabel: {
                        Text(" \(appState.progressOfFirmwareUpdate, specifier: "%.2f") %")
                            .font(.system(size:15))
                            .foregroundColor(.blue)
                    }
                }
                .padding(20)
                
                HStack {
                    Spacer()
                    Button(action: {
                        viewModel.cancelButtonAction()
                        
                    }) {
                        Text("Cancel")
                            .padding([.trailing],20)
                        
                    }
                }
                .padding([.bottom],10)
            }
            .background(colorScheme == .dark ? Asset.formColorDark.swiftUIColor : Asset.formColorLight.swiftUIColor)
            .cornerRadius(10)
            .frame(width: 300)
        }
        
    }
}

// Rebooting popup
struct RebootingView: View {
    var colorScheme: ColorScheme?
    
    var body: some View{
        ZStack {
            Color.black.opacity(0.3).edgesIgnoringSafeArea(.all)
            VStack {
                VStack(alignment: .leading, spacing: 20) {
                    HStack {
                        Spacer()
                        Text("Rebooting Scanner").bold()
                        Spacer()
                    }
                    HStack {
                        Spacer()
                        DotView()
                        DotView(delay: 0.2)
                        DotView(delay: 0.4)
                        DotView(delay: 0.6)
                        DotView(delay: 0.8)
                        Spacer()
                    }
                }
                .padding(20)
            }
            .background(colorScheme == .dark ? Asset.formColorDark.swiftUIColor : Asset.formColorLight.swiftUIColor)
            .cornerRadius(10)
            .frame(width: 300)
        }
    }
}
