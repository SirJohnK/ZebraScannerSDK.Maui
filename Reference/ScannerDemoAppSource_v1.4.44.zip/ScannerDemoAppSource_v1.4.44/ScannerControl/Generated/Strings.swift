// swiftlint:disable all
// Generated using SwiftGen — https://github.com/SwiftGen/SwiftGen

import Foundation

// swiftlint:disable superfluous_disable_command file_length implicit_return prefer_self_in_static_references

// MARK: - Strings

// swiftlint:disable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:disable nesting type_body_length type_name vertical_whitespace_opening_braces
internal enum L10n {
  internal enum Advanced {
    /// Asset Information
    internal static let assetInformation = L10n.tr("Localizable", "Advanced.AssetInformation", fallback: "Asset Information")
    /// Battery Statistics
    internal static let batteryStatistics = L10n.tr("Localizable", "Advanced.BatteryStatistics", fallback: "Battery Statistics")
    /// Advanced
    internal static let navTitle = L10n.tr("Localizable", "Advanced.navTitle", fallback: "Advanced")
    /// Advanced
    internal static let tabTitle = L10n.tr("Localizable", "Advanced.TabTitle", fallback: "Advanced")
    /// Update Firmware
    internal static let updateFirmware = L10n.tr("Localizable", "Advanced.UpdateFirmware", fallback: "Update Firmware")
    /// Virtual Tether
    internal static let virtualTether = L10n.tr("Localizable", "Advanced.VirtualTether", fallback: "Virtual Tether")
    internal enum AssetInformation {
      /// Configuration Filename
      internal static let configurationFilenameLabel = L10n.tr("Localizable", "Advanced.AssetInformation.configurationFilenameLabel", fallback: "Configuration Filename")
      /// Connection Type
      internal static let connectionTypeLabel = L10n.tr("Localizable", "Advanced.AssetInformation.connectionTypeLabel", fallback: "Connection Type")
      /// Manufacture Date
      internal static let dateOfManufactureLabel = L10n.tr("Localizable", "Advanced.AssetInformation.dateOfManufactureLabel", fallback: "Manufacture Date")
      /// Firmware
      internal static let firmwareLabel = L10n.tr("Localizable", "Advanced.AssetInformation.firmwareLabel", fallback: "Firmware")
      /// Model Number
      internal static let modelLabel = L10n.tr("Localizable", "Advanced.AssetInformation.modelLabel", fallback: "Model Number")
      /// Scanner Name
      internal static let nameLabel = L10n.tr("Localizable", "Advanced.AssetInformation.nameLabel", fallback: "Scanner Name")
      /// Asset Information
      internal static let navTitle = L10n.tr("Localizable", "Advanced.AssetInformation.navTitle", fallback: "Asset Information")
      /// Serial Number
      internal static let serialNoLabel = L10n.tr("Localizable", "Advanced.AssetInformation.serialNoLabel", fallback: "Serial Number")
    }
    internal enum BatteryStatistics {
      /// Battery Statistics
      internal static let navTitle = L10n.tr("Localizable", "Advanced.BatteryStatistics.navTitle", fallback: "Battery Statistics")
    }
    internal enum FindScanner {
      /// Find Scanner
      internal static let text = L10n.tr("Localizable", "Advanced.FindScanner.text", fallback: "Find Scanner")
    }
    internal enum UpdateFirmware {
      /// Update Firmware
      internal static let navTitle = L10n.tr("Localizable", "Advanced.UpdateFirmware.navTitle", fallback: "Update Firmware")
    }
    internal enum VirtualTether {
      /// Virtual Tether
      internal static let navTitle = L10n.tr("Localizable", "Advanced.VirtualTether.navTitle", fallback: "Virtual Tether")
    }
  }
  internal enum AppOverview {
    /// Zebra Technologies Corp. and/or its affiliates. All rights reserved.
    internal static let copyrightMessage = L10n.tr("Localizable", "AppOverview.CopyrightMessage", fallback: "Zebra Technologies Corp. and/or its affiliates. All rights reserved.")
    /// ©2024
    internal static let copyrightYear = L10n.tr("Localizable", "AppOverview.CopyrightYear", fallback: "©2024")
    /// Zebra Scanner Control Version
    internal static let scannerControlVersion = L10n.tr("Localizable", "AppOverview.ScannerControlVersion", fallback: "Zebra Scanner Control Version")
    /// Zebra Scanner SDK Version
    internal static let scannerSDKVersion = L10n.tr("Localizable", "AppOverview.ScannerSDKVersion", fallback: "Zebra Scanner SDK Version")
    /// App Overview
    internal static let title = L10n.tr("Localizable", "AppOverview.title", fallback: "App Overview")
  }
  internal enum AppSettings {
    /// Active Scanner
    internal static let activeScannerLabel = L10n.tr("Localizable", "AppSettings.ActiveScannerLabel", fallback: "Active Scanner")
    /// If the setting is enabled, the last connected scanner will be re-connected on app relaunch. This behaviour is only valid for BLE communication mode
    internal static let autoConnectFooterLabel = L10n.tr("Localizable", "AppSettings.AutoConnectFooterLabel", fallback: "If the setting is enabled, the last connected scanner will be re-connected on app relaunch. This behaviour is only valid for BLE communication mode")
    /// Auto Connect
    internal static let autoConnectLabel = L10n.tr("Localizable", "AppSettings.AutoConnectLabel", fallback: "Auto Connect")
    /// Auto connect to last
    /// connected scanner
    internal static let autoConnectToggleLabel = L10n.tr("Localizable", "AppSettings.AutoConnectToggleLabel", fallback: "Auto connect to last\nconnected scanner")
    /// Available Scanner
    internal static let availableScannerLabel = L10n.tr("Localizable", "AppSettings.AvailableScannerLabel", fallback: "Available Scanner")
    /// Background Notifications
    internal static let backgroundNotificationsLabel = L10n.tr("Localizable", "AppSettings.BackgroundNotificationsLabel", fallback: "Background Notifications")
    /// Barcode Event
    internal static let barcodeEventLabel = L10n.tr("Localizable", "AppSettings.BarcodeEventLabel", fallback: "Barcode Event")
    /// Communication Mode
    internal static let communicationModeHeader = L10n.tr("Localizable", "AppSettings.CommunicationModeHeader", fallback: "Communication Mode")
    /// Communication Mode
    internal static let communicationModeLabel = L10n.tr("Localizable", "AppSettings.CommunicationModeLabel", fallback: "Communication Mode")
    /// App Settings
    internal static let navTitle = L10n.tr("Localizable", "AppSettings.navTitle", fallback: "App Settings")
    /// Reset Defaults
    internal static let resetDefaultsLabel = L10n.tr("Localizable", "AppSettings.ResetDefaultsLabel", fallback: "Reset Defaults")
    /// Scanner Discovery
    internal static let scannerDiscoveryLabel = L10n.tr("Localizable", "AppSettings.ScannerDiscoveryLabel", fallback: "Scanner Discovery")
    /// Discover Bluetooth Scanners
    internal static let scannerDiscoveryToggleLabel = L10n.tr("Localizable", "AppSettings.ScannerDiscoveryToggleLabel", fallback: "Discover Bluetooth Scanners")
    /// Scan To Connect
    internal static let setFactoryDefaultHeader = L10n.tr("Localizable", "AppSettings.SetFactoryDefaultHeader", fallback: "Scan To Connect")
    /// Set Factory Defaults
    internal static let setFactoryDefaultToggleText = L10n.tr("Localizable", "AppSettings.setFactoryDefaultToggleText", fallback: "Set Factory Defaults")
  }
  internal enum AvailableDeviceList {
    /// Available Device List
    internal static let navTitle = L10n.tr("Localizable", "AvailableDeviceList.navTitle", fallback: "Available Device List")
  }
  internal enum Btle {
    /// 1. If previously paired, use Bluetooth Settings to unpair the
    internal static let instruction1 = L10n.tr("Localizable", "BTLE.Instruction1", fallback: "1. If previously paired, use Bluetooth Settings to unpair the")
    /// 2. Enable Bluetooth on the device.
    internal static let instruction2 = L10n.tr("Localizable", "BTLE.Instruction2", fallback: "2. Enable Bluetooth on the device.")
    /// 3. Go to BT LE barcode screen and scan the STC barcode provided.
    internal static let instruction3 = L10n.tr("Localizable", "BTLE.Instruction3", fallback: "3. Go to BT LE barcode screen and scan the STC barcode provided.")
    /// 4. Tap the 'Pair' button when the 'Bluetooth Pairing Request' promt appears
    internal static let instruction4 = L10n.tr("Localizable", "BTLE.Instruction4", fallback: "4. Tap the 'Pair' button when the 'Bluetooth Pairing Request' promt appears")
  }
  internal enum BtLe {
    /// Keep Current Settings
    internal static let keepCurrentSettingsText = L10n.tr("Localizable", "BT_LE.KeepCurrentSettingsText", fallback: "Keep Current Settings")
    /// Pair New Scanner
    internal static let navTitle = L10n.tr("Localizable", "BT_LE.navTitle", fallback: "Pair New Scanner")
    /// Set Factory Defaults
    internal static let setFactoryDefaultsText = L10n.tr("Localizable", "BT_LE.SetFactoryDefaultsText", fallback: "Set Factory Defaults")
    /// (To change settings click: More / App Settings)
    internal static let settingGuideText = L10n.tr("Localizable", "BT_LE.SettingGuideText", fallback: "(To change settings click: More / App Settings)")
    /// STC Barcode
    internal static let stcBarcodeText = L10n.tr("Localizable", "BT_LE.STCBarcodeText", fallback: "STC Barcode")
    /// Scan barcode to pair your cordless scanner to this app
    internal static let stcDescriptionText = L10n.tr("Localizable", "BT_LE.STCDescriptionText", fallback: "Scan barcode to pair your cordless scanner to this app")
    /// BT LE
    internal static let tabTitle = L10n.tr("Localizable", "BT_LE.TabTitle", fallback: "BT LE")
  }
  internal enum BatteryDetail {
    /// Charge Cycles Consumed
    internal static let chargeCyclesText = L10n.tr("Localizable", "BatteryDetail.ChargeCyclesText", fallback: "Charge Cycles Consumed")
    /// Design Capacity
    internal static let designCapacityText = L10n.tr("Localizable", "BatteryDetail.DesignCapacityText", fallback: "Design Capacity")
    /// Full Charge Capacity
    internal static let fullChargeCapacityText = L10n.tr("Localizable", "BatteryDetail.FullChargeCapacityText", fallback: "Full Charge Capacity")
    /// Battery Asset Information
    internal static let header1 = L10n.tr("Localizable", "BatteryDetail.Header1", fallback: "Battery Asset Information")
    /// Battery Life Statistics
    internal static let header2 = L10n.tr("Localizable", "BatteryDetail.Header2", fallback: "Battery Life Statistics")
    /// Battery Status
    internal static let header3 = L10n.tr("Localizable", "BatteryDetail.Header3", fallback: "Battery Status")
    /// Battery Temperature
    internal static let header4 = L10n.tr("Localizable", "BatteryDetail.Header4", fallback: "Battery Temperature")
    /// Manufacture Date
    internal static let manufactureDateText = L10n.tr("Localizable", "BatteryDetail.ManufactureDateText", fallback: "Manufacture Date")
    /// Model Numebr
    internal static let modelNumberText = L10n.tr("Localizable", "BatteryDetail.ModelNumberText", fallback: "Model Numebr")
    /// Remaining Capacity
    internal static let remainingCapacityText = L10n.tr("Localizable", "BatteryDetail.RemainingCapacityText", fallback: "Remaining Capacity")
    /// Serial Number
    internal static let serialNumberText = L10n.tr("Localizable", "BatteryDetail.SerialNumberText", fallback: "Serial Number")
    /// State of Charge
    internal static let stateOfChargeText = L10n.tr("Localizable", "BatteryDetail.StateOfChargeText", fallback: "State of Charge")
    /// State of Health
    internal static let stateOfHealthText = L10n.tr("Localizable", "BatteryDetail.StateOfHealthText", fallback: "State of Health")
    /// Highest
    internal static let temperatureHighestText = L10n.tr("Localizable", "BatteryDetail.TemperatureHighestText", fallback: "Highest")
    /// Lowest
    internal static let temperatureLowestText = L10n.tr("Localizable", "BatteryDetail.TemperatureLowestText", fallback: "Lowest")
    /// Present
    internal static let temperaturePresentText = L10n.tr("Localizable", "BatteryDetail.TemperaturePresentText", fallback: "Present")
    /// This scanner does not have a PowerPrecision+ smart battery
    internal static let unsupportedScannerText = L10n.tr("Localizable", "BatteryDetail.UnsupportedScannerText", fallback: "This scanner does not have a PowerPrecision+ smart battery")
  }
  internal enum BeeperSettings {
    /// Beep
    internal static let beepText = L10n.tr("Localizable", "BeeperSettings.BeepText", fallback: "Beep")
    /// Beeper Frequency
    internal static let frequencyLabel = L10n.tr("Localizable", "BeeperSettings.FrequencyLabel", fallback: "Beeper Frequency")
    /// Beeper Sequence
    internal static let sequenceLabel = L10n.tr("Localizable", "BeeperSettings.SequenceLabel", fallback: "Beeper Sequence")
    /// Beeper Volume
    internal static let volumeLabel = L10n.tr("Localizable", "BeeperSettings.VolumeLabel", fallback: "Beeper Volume")
    internal enum Frequency {
      /// Beeper Frequency Settings
      internal static let navTitle = L10n.tr("Localizable", "BeeperSettings.Frequency.navTitle", fallback: "Beeper Frequency Settings")
    }
    internal enum Sequence {
      /// Beeper Sequence Settings
      internal static let navTitle = L10n.tr("Localizable", "BeeperSettings.Sequence.navTitle", fallback: "Beeper Sequence Settings")
    }
    internal enum Volume {
      /// Beeper Volume Settings
      internal static let navTitle = L10n.tr("Localizable", "BeeperSettings.Volume.navTitle", fallback: "Beeper Volume Settings")
    }
  }
  internal enum ComingSoon {
    /// To be released in the upcoming update.
    internal static let text = L10n.tr("Localizable", "ComingSoon.Text", fallback: "To be released in the upcoming update.")
  }
  internal enum CommunicationMode {
    /// Message
    internal static let disabledAlertTitle = L10n.tr("Localizable", "CommunicationMode.DisabledAlertTitle", fallback: "Message")
    /// Currently, you only selected MFi mode. To access BT LE devices, change the communication mode to BT LE or MFi + BT LE on the "App Settings" page.
    internal static let disabledBLEModeAlertMsg = L10n.tr("Localizable", "CommunicationMode.DisabledBLEModeAlertMsg", fallback: "Currently, you only selected MFi mode. To access BT LE devices, change the communication mode to BT LE or MFi + BT LE on the \"App Settings\" page.")
    /// Currently, you only selected BT LE mode. To access MFi devices, change the communication mode to MFi or MFi + BT LE on the "App Settings" page.
    internal static let disabledMFiModeAlertMsg = L10n.tr("Localizable", "CommunicationMode.DisabledMFiModeAlertMsg", fallback: "Currently, you only selected BT LE mode. To access MFi devices, change the communication mode to MFi or MFi + BT LE on the \"App Settings\" page.")
  }
  internal enum ConnectionHelp {
    /// Connection Help
    internal static let navTitle = L10n.tr("Localizable", "ConnectionHelp.navTitle", fallback: "Connection Help")
    /// Pairing Help
    internal static let pairingHelp = L10n.tr("Localizable", "ConnectionHelp.PairingHelp", fallback: "Pairing Help")
    /// Supported Scanners
    internal static let supportedScanners = L10n.tr("Localizable", "ConnectionHelp.SupportedScanners", fallback: "Supported Scanners")
  }
  internal enum DataView {
    /// Barcodes Scanned:
    internal static let barcodesScannedLabel = L10n.tr("Localizable", "DataView.BarcodesScannedLabel", fallback: "Barcodes Scanned:")
    /// Clear
    internal static let clearButtonText = L10n.tr("Localizable", "DataView.ClearButtonText", fallback: "Clear")
    /// Data View
    internal static let navTitle = L10n.tr("Localizable", "DataView.navTitle", fallback: "Data View")
    /// Sample Barcodes for Scanning
    internal static let sampleBarcodesNavText = L10n.tr("Localizable", "DataView.SampleBarcodesNavText", fallback: "Sample Barcodes for Scanning")
    /// Data View
    internal static let tabTitle = L10n.tr("Localizable", "DataView.TabTitle", fallback: "Data View")
    internal enum DetailView {
      /// Barcode Data
      internal static let barcodeDataLabel = L10n.tr("Localizable", "DataView.DetailView.BarcodeDataLabel", fallback: "Barcode Data")
      /// Barcode Type
      internal static let barcodeTypeLabel = L10n.tr("Localizable", "DataView.DetailView.BarcodeTypeLabel", fallback: "Barcode Type")
      /// Barcode Details
      internal static let navTitle = L10n.tr("Localizable", "DataView.DetailView.navTitle", fallback: "Barcode Details")
      /// Scanner ID
      internal static let scannerIDLabel = L10n.tr("Localizable", "DataView.DetailView.ScannerIDLabel", fallback: "Scanner ID")
    }
    internal enum SampleBarcodeView {
      /// Sample Barcodes
      internal static let navTitle = L10n.tr("Localizable", "DataView.SampleBarcodeView.navTitle", fallback: "Sample Barcodes")
      /// Scan a sample barcode from the list below,or scan your own barcode.
      internal static let sectionHeader = L10n.tr("Localizable", "DataView.SampleBarcodeView.sectionHeader", fallback: "Scan a sample barcode from the list below,or scan your own barcode.")
    }
  }
  internal enum MFi {
    /// Connect MFi Scanners
    internal static let navTitle = L10n.tr("Localizable", "MFi.navTitle", fallback: "Connect MFi Scanners")
    /// No device connected
    internal static let noDevicesMessage = L10n.tr("Localizable", "MFi.noDevicesMessage", fallback: "No device connected")
    /// MFi
    internal static let tabTitle = L10n.tr("Localizable", "MFi.TabTitle", fallback: "MFi")
    internal enum Cs4070 {
      /// 1. If previously paired, use Bluetooth Settings to unpair the CS4070.
      internal static let instruction1 = L10n.tr("Localizable", "MFi.CS4070.Instruction1", fallback: "1. If previously paired, use Bluetooth Settings to unpair the CS4070.")
      /// 2. Scan the 'Reset Factory Defaults' barcode below:
      internal static let instruction2 = L10n.tr("Localizable", "MFi.CS4070.Instruction2", fallback: "2. Scan the 'Reset Factory Defaults' barcode below:")
      /// 3. Scan the 'Bluetooth MFi_SSI' barcode below to pair:
      internal static let instruction3 = L10n.tr("Localizable", "MFi.CS4070.Instruction3", fallback: "3. Scan the 'Bluetooth MFi_SSI' barcode below to pair:")
      /// 4. Enable Bluetooth on the device.
      internal static let instruction4 = L10n.tr("Localizable", "MFi.CS4070.Instruction4", fallback: "4. Enable Bluetooth on the device.")
      /// 5. The device will discover the CS4070 and display it on the Bluetooth Device list.
      internal static let instruction5 = L10n.tr("Localizable", "MFi.CS4070.Instruction5", fallback: "5. The device will discover the CS4070 and display it on the Bluetooth Device list.")
      /// 6. Tap the 'CS4070' to pair from the Bluetooth Device list.
      internal static let instruction6 = L10n.tr("Localizable", "MFi.CS4070.Instruction6", fallback: "6. Tap the 'CS4070' to pair from the Bluetooth Device list.")
      /// 7. Go to 'Zebra Scanner Control' app's 'MFi' screen and select the CS4070.
      internal static let instruction7 = L10n.tr("Localizable", "MFi.CS4070.Instruction7", fallback: "7. Go to 'Zebra Scanner Control' app's 'MFi' screen and select the CS4070.")
    }
    internal enum Cs6080 {
      /// 1. If previously paired, use Bluetooth Settings to unpair the DS8178/CS6080.
      internal static let instruction1 = L10n.tr("Localizable", "MFi.CS6080.Instruction1", fallback: "1. If previously paired, use Bluetooth Settings to unpair the DS8178/CS6080.")
      /// 2. Scan the 'Reset Factory Defaults' barcode below:
      internal static let instruction2 = L10n.tr("Localizable", "MFi.CS6080.Instruction2", fallback: "2. Scan the 'Reset Factory Defaults' barcode below:")
      /// 3. Scan the 'Bluetooth MFi_SSI' barcode below to pair:
      internal static let instruction3 = L10n.tr("Localizable", "MFi.CS6080.Instruction3", fallback: "3. Scan the 'Bluetooth MFi_SSI' barcode below to pair:")
      /// 4. Enable Bluetooth on the device.
      internal static let instruction4 = L10n.tr("Localizable", "MFi.CS6080.Instruction4", fallback: "4. Enable Bluetooth on the device.")
      /// 5. The device will discover the DS8178/ CS6080 and display it on the Bluetooth Device list.
      internal static let instruction5 = L10n.tr("Localizable", "MFi.CS6080.Instruction5", fallback: "5. The device will discover the DS8178/ CS6080 and display it on the Bluetooth Device list.")
      /// 6. Tap the DS8178/ CS6080 to pair from the Bluetooth Device list.
      internal static let instruction6 = L10n.tr("Localizable", "MFi.CS6080.Instruction6", fallback: "6. Tap the DS8178/ CS6080 to pair from the Bluetooth Device list.")
      /// 7. Go to 'Zebra Scanner Control' app's 'MFi' screen and select the DS8178/ CS6080.
      internal static let instruction7 = L10n.tr("Localizable", "MFi.CS6080.Instruction7", fallback: "7. Go to 'Zebra Scanner Control' app's 'MFi' screen and select the DS8178/ CS6080.")
    }
  }
  internal enum More {
    /// App Overview
    internal static let appOverview = L10n.tr("Localizable", "More.AppOverview", fallback: "App Overview")
    /// App Settings
    internal static let appSettings = L10n.tr("Localizable", "More.AppSettings", fallback: "App Settings")
    /// Available Device List
    internal static let availableDeviceList = L10n.tr("Localizable", "More.AvailableDeviceList", fallback: "Available Device List")
    /// Connection Help
    internal static let connectionHelp = L10n.tr("Localizable", "More.ConnectionHelp", fallback: "Connection Help")
    /// Disconnect Scanner
    internal static let disconnectScannerButtonText = L10n.tr("Localizable", "More.DisconnectScannerButtonText", fallback: "Disconnect Scanner")
    /// More
    internal static let navTitle = L10n.tr("Localizable", "More.navTitle", fallback: "More")
    /// More
    internal static let tabTitle = L10n.tr("Localizable", "More.TabTitle", fallback: "More")
  }
  internal enum PairingHelp {
    /// BT LE
    internal static let btle = L10n.tr("Localizable", "PairingHelp.BTLE", fallback: "BT LE")
    /// MFi
    internal static let mFi = L10n.tr("Localizable", "PairingHelp.MFi", fallback: "MFi")
    /// Pairing Help
    internal static let navTitle = L10n.tr("Localizable", "PairingHelp.navTitle", fallback: "Pairing Help")
    /// Pair CS4070
    internal static let pairCS4070 = L10n.tr("Localizable", "PairingHelp.PairCS4070", fallback: "Pair CS4070")
    /// Pair DS2278
    internal static let pairDS2278 = L10n.tr("Localizable", "PairingHelp.PairDS2278", fallback: "Pair DS2278")
    /// Pair DS8178/CS6080
    internal static let pairDS8178CS6080 = L10n.tr("Localizable", "PairingHelp.PairDS8178/CS6080", fallback: "Pair DS8178/CS6080")
    /// Pairing Instructions
    internal static let pairingInstructionsLabel = L10n.tr("Localizable", "PairingHelp.PairingInstructionsLabel", fallback: "Pairing Instructions")
    /// Pair LI/DS3678
    internal static let pairLIDS3678 = L10n.tr("Localizable", "PairingHelp.PairLI/DS3678", fallback: "Pair LI/DS3678")
    /// Pair RFD8500
    internal static let pairRFD8500 = L10n.tr("Localizable", "PairingHelp.PairRFD8500", fallback: "Pair RFD8500")
    /// Pair RS5100
    internal static let pairRS5100 = L10n.tr("Localizable", "PairingHelp.PairRS5100", fallback: "Pair RS5100")
    /// Set Defaults
    internal static let setDefaultsLabel = L10n.tr("Localizable", "PairingHelp.SetDefaultsLabel", fallback: "Set Defaults")
    internal enum PairCS4070 {
      /// Pair CS4070
      internal static let navTitle = L10n.tr("Localizable", "PairingHelp.PairCS4070.navTitle", fallback: "Pair CS4070")
    }
    internal enum PairDS8178CS6080 {
      /// Pair DS8178/CS6080
      internal static let navTitle = L10n.tr("Localizable", "PairingHelp.PairDS8178/CS6080.navTitle", fallback: "Pair DS8178/CS6080")
    }
    internal enum SetDefaults {
      /// Set Defaults
      internal static let navTitle = L10n.tr("Localizable", "PairingHelp.SetDefaults.navTitle", fallback: "Set Defaults")
    }
  }
  internal enum Rfd8500 {
    /// 1. Turn the RFD8500 on and ensure Bluetooth is enabled.
    internal static let instruction1 = L10n.tr("Localizable", "RFD8500.Instruction1", fallback: "1. Turn the RFD8500 on and ensure Bluetooth is enabled.")
    /// The RFD8500 is discoverable over Bluetooth for 40 seconds after start up. After that time Bluetooth suspends and is no longer discoverable. To make discoverable again, press the Bluetooth button, located on the side of RFD8500.
    internal static let instruction11 = L10n.tr("Localizable", "RFD8500.Instruction1_1", fallback: "The RFD8500 is discoverable over Bluetooth for 40 seconds after start up. After that time Bluetooth suspends and is no longer discoverable. To make discoverable again, press the Bluetooth button, located on the side of RFD8500.")
    /// 2. Enable Bluetooth on the device.
    internal static let instruction2 = L10n.tr("Localizable", "RFD8500.Instruction2", fallback: "2. Enable Bluetooth on the device.")
    /// 3. The device will discover the RFD8500 and display it on the Bluetooth Devices list.
    internal static let instruction3 = L10n.tr("Localizable", "RFD8500.Instruction3", fallback: "3. The device will discover the RFD8500 and display it on the Bluetooth Devices list.")
    /// 4. Tap the 'RFD8500' to initiate pairing from the Bluetooth Devices list.
    internal static let instruction4 = L10n.tr("Localizable", "RFD8500.Instruction4", fallback: "4. Tap the 'RFD8500' to initiate pairing from the Bluetooth Devices list.")
    /// 5. Press the RFD8500 trigger to complete pairing when the Bluetooth LED starts flashing fast.
    internal static let instruction5 = L10n.tr("Localizable", "RFD8500.Instruction5", fallback: "5. Press the RFD8500 trigger to complete pairing when the Bluetooth LED starts flashing fast.")
    /// Pair RFD8500
    internal static let navTitle = L10n.tr("Localizable", "RFD8500.navTitle", fallback: "Pair RFD8500")
  }
  internal enum SetDefault {
    /// Scan the barcode below to restore to default paramaters.
    internal static let instruction = L10n.tr("Localizable", "SetDefault.Instruction", fallback: "Scan the barcode below to restore to default paramaters.")
  }
  internal enum Settings {
    /// Aim Guide
    internal static let aimGuideLabel = L10n.tr("Localizable", "Settings.AimGuideLabel", fallback: "Aim Guide")
    /// Auto reconnect enabled
    internal static let autoReconnectText = L10n.tr("Localizable", "Settings.AutoReconnectText", fallback: "Auto reconnect enabled")
    /// Beeper
    internal static let beeperLabel = L10n.tr("Localizable", "Settings.BeeperLabel", fallback: "Beeper")
    /// LED Control
    internal static let ledControlLabel = L10n.tr("Localizable", "Settings.LEDControlLabel", fallback: "LED Control")
    /// Settings
    internal static let navTitle = L10n.tr("Localizable", "Settings.navTitle", fallback: "Settings")
    /// This disables the decoding of parameter barcodes including Set Defaults, but Scan-To-Connect (STC) pairing barcodes can still be scanned.
    internal static let paramterBarcodeInfoText = L10n.tr("Localizable", "Settings.ParamterBarcodeInfoText", fallback: "This disables the decoding of parameter barcodes including Set Defaults, but Scan-To-Connect (STC) pairing barcodes can still be scanned.")
    /// Parameter barcode 
    /// scanning disabled
    internal static let paramterBarcodeText = L10n.tr("Localizable", "Settings.ParamterBarcodeText", fallback: "Parameter barcode \nscanning disabled")
    /// Picklist Mode
    internal static let picklistModeLabel = L10n.tr("Localizable", "Settings.PicklistModeLabel", fallback: "Picklist Mode")
    /// Symbologies
    internal static let symbologiesLabel = L10n.tr("Localizable", "Settings.SymbologiesLabel", fallback: "Symbologies")
    /// Settings
    internal static let tabTitle = L10n.tr("Localizable", "Settings.TabTitle", fallback: "Settings")
    /// Trigger
    internal static let triggerLabel = L10n.tr("Localizable", "Settings.TriggerLabel", fallback: "Trigger")
    /// Vibration Feedback
    internal static let vibrationFeedbackLabel = L10n.tr("Localizable", "Settings.VibrationFeedbackLabel", fallback: "Vibration Feedback")
    internal enum AimGuide {
      /// Off
      internal static let offButtonText = L10n.tr("Localizable", "Settings.AimGuide.OffButtonText", fallback: "Off")
      /// On
      internal static let onButtonText = L10n.tr("Localizable", "Settings.AimGuide.OnButtonText", fallback: "On")
    }
    internal enum Beeper {
      /// Beeper Settings
      internal static let navTitle = L10n.tr("Localizable", "Settings.Beeper.navTitle", fallback: "Beeper Settings")
    }
    internal enum LEDControl {
      /// Green LED
      internal static let greenLED = L10n.tr("Localizable", "Settings.LEDControl.greenLED", fallback: "Green LED")
      /// Off
      internal static let ledOff = L10n.tr("Localizable", "Settings.LEDControl.ledOff", fallback: "Off")
      /// On
      internal static let ledOn = L10n.tr("Localizable", "Settings.LEDControl.ledOn", fallback: "On")
      /// LED Control
      internal static let navTitle = L10n.tr("Localizable", "Settings.LEDControl.navTitle", fallback: "LED Control")
      /// Red LED
      internal static let redLED = L10n.tr("Localizable", "Settings.LEDControl.redLED", fallback: "Red LED")
      /// Amber/Yellow LED
      internal static let yellowLED = L10n.tr("Localizable", "Settings.LEDControl.yellowLED", fallback: "Amber/Yellow LED")
    }
    internal enum Symbologies {
      /// Symbology Settings(ON/OFF)
      internal static let navTitle = L10n.tr("Localizable", "Settings.Symbologies.navTitle", fallback: "Symbology Settings(ON/OFF)")
    }
    internal enum Trigger {
      /// Pull
      internal static let pullButtonText = L10n.tr("Localizable", "Settings.Trigger.PullButtonText", fallback: "Pull")
      /// Release
      internal static let releaseButtonText = L10n.tr("Localizable", "Settings.Trigger.ReleaseButtonText", fallback: "Release")
    }
    internal enum VibrationFeedback {
      /// Vibration Feedback
      internal static let navTitle = L10n.tr("Localizable", "Settings.VibrationFeedback.navTitle", fallback: "Vibration Feedback")
    }
  }
  internal enum SupportedScanners {
    /// The following cordless scanners can be used with this application
    internal static let headingText = L10n.tr("Localizable", "SupportedScanners.headingText", fallback: "The following cordless scanners can be used with this application")
    /// Supported Scanners
    internal static let navTitle = L10n.tr("Localizable", "SupportedScanners.navTitle", fallback: "Supported Scanners")
  }
  internal enum Symbology {
    /// Persist Settings
    internal static let persistLabel = L10n.tr("Localizable", "Symbology.persistLabel", fallback: "Persist Settings")
  }
  internal enum UpdateFirmwareView {
    ///  Firmware Updated
    internal static let firmwareUpdatedText = L10n.tr("Localizable", "UpdateFirmwareView.firmwareUpdatedText", fallback: " Firmware Updated")
    /// Firmware Update Process Help
    internal static let helpTitle = L10n.tr("Localizable", "UpdateFirmwareView.helpTitle", fallback: "Firmware Update Process Help")
    /// Copy the correct 123Scan plug-in for your scanner to your device
    internal static let mainIntructionText = L10n.tr("Localizable", "UpdateFirmwareView.mainIntructionText", fallback: "Copy the correct 123Scan plug-in for your scanner to your device")
    /// Firmware file not found. Please add a valid firmware file to app's download folder
    internal static let noFilesText = L10n.tr("Localizable", "UpdateFirmwareView.noFilesText", fallback: "Firmware file not found. Please add a valid firmware file to app's download folder")
    /// 1.  Delete the incorrect plugin from the application's download folder.
    internal static let pluginMismatchInstruction1 = L10n.tr("Localizable", "UpdateFirmwareView.pluginMismatchInstruction1", fallback: "1.  Delete the incorrect plugin from the application's download folder.")
    /// 2.  Copy the correct plugin to the application's download folder.
    internal static let pluginMismatchInstruction2 = L10n.tr("Localizable", "UpdateFirmwareView.pluginMismatchInstruction2", fallback: "2.  Copy the correct plugin to the application's download folder.")
    /// Plugin/Scanner Mismatch
    internal static let pluginMismatchTitle = L10n.tr("Localizable", "UpdateFirmwareView.pluginMismatchTitle", fallback: "Plugin/Scanner Mismatch")
    /// Select Firmware
    internal static let selectFirmwareButtonText = L10n.tr("Localizable", "UpdateFirmwareView.selectFirmwareButtonText", fallback: "Select Firmware")
    /// 1.  Load 123Scan onto a Windows computer from
    internal static let subInstruction1 = L10n.tr("Localizable", "UpdateFirmwareView.subInstruction1", fallback: "1.  Load 123Scan onto a Windows computer from")
    /// 2.  From your Windows PC with 123Scan, access your scanner's plug-in(.scnplg file) from 
    internal static let subInstruction2 = L10n.tr("Localizable", "UpdateFirmwareView.subInstruction2", fallback: "2.  From your Windows PC with 123Scan, access your scanner's plug-in(.scnplg file) from ")
    /// 3.  Put a copy of the  plug-in into your device's download folder (Application > Download)
    internal static let subInstruction3 = L10n.tr("Localizable", "UpdateFirmwareView.subInstruction3", fallback: "3.  Put a copy of the  plug-in into your device's download folder (Application > Download)")
    /// Update Firmware
    internal static let updateFirmwareButtonText = L10n.tr("Localizable", "UpdateFirmwareView.updateFirmwareButtonText", fallback: "Update Firmware")
    /// www.Zebra.com/123Scan
    internal static let urlDisplayText = L10n.tr("Localizable", "UpdateFirmwareView.url_display_text", fallback: "www.Zebra.com/123Scan")
    internal enum AbortConfirmation {
      /// Do you want to stop this firmware update?
      internal static let description = L10n.tr("Localizable", "UpdateFirmwareView.abortConfirmation.description", fallback: "Do you want to stop this firmware update?")
      /// Message
      internal static let title = L10n.tr("Localizable", "UpdateFirmwareView.abortConfirmation.title", fallback: "Message")
    }
    internal enum PluginMatch {
      /// From
      internal static let from = L10n.tr("Localizable", "UpdateFirmwareView.pluginMatch.from", fallback: "From")
      /// Release Notes
      internal static let releaseNotes = L10n.tr("Localizable", "UpdateFirmwareView.pluginMatch.releaseNotes", fallback: "Release Notes")
      /// To
      internal static let to = L10n.tr("Localizable", "UpdateFirmwareView.pluginMatch.to", fallback: "To")
    }
  }
  internal enum VibrationFeedback {
    /// Vibrate
    internal static let vibrateText = L10n.tr("Localizable", "VibrationFeedback.VibrateText", fallback: "Vibrate")
    /// Vibration
    internal static let vibrationToggleText = L10n.tr("Localizable", "VibrationFeedback.VibrationToggleText", fallback: "Vibration")
  }
  internal enum VirtualTether {
    /// Audio Alarm
    internal static let audioAlarmText = L10n.tr("Localizable", "VirtualTether.AudioAlarmText", fallback: "Audio Alarm")
    /// Enable Host Feedback
    internal static let enableHostFeedbackText = L10n.tr("Localizable", "VirtualTether.EnableHostFeedbackText", fallback: "Enable Host Feedback")
    /// Enable Virtual Tether
    internal static let enableVirtualTetherText = L10n.tr("Localizable", "VirtualTether.EnableVirtualTetherText", fallback: "Enable Virtual Tether")
    /// Flashing Screen
    internal static let flashingScreenText = L10n.tr("Localizable", "VirtualTether.FlashingScreenText", fallback: "Flashing Screen")
    /// Host Settings(Tablet/Phone)
    internal static let hostSettingsText = L10n.tr("Localizable", "VirtualTether.HostSettingsText", fallback: "Host Settings(Tablet/Phone)")
    /// Zebra Virtual Tether alarm activated.
    internal static let popupAlertText = L10n.tr("Localizable", "VirtualTether.PopupAlertText", fallback: "Zebra Virtual Tether alarm activated.")
    /// OK
    internal static let popupMessageOKText = L10n.tr("Localizable", "VirtualTether.PopupMessageOKText", fallback: "OK")
    /// Pop-up message
    internal static let popupMessageText = L10n.tr("Localizable", "VirtualTether.PopupMessageText", fallback: "Pop-up message")
    /// Scanner Settings
    internal static let scannerSettingsText = L10n.tr("Localizable", "VirtualTether.ScannerSettingsText", fallback: "Scanner Settings")
    /// Simulate Alarm
    internal static let simulateAlarmText = L10n.tr("Localizable", "VirtualTether.SimulateAlarmText", fallback: "Simulate Alarm")
    /// Snooze Alarm on Scanner
    internal static let snoozeAlarmButtonText = L10n.tr("Localizable", "VirtualTether.SnoozeAlarmButtonText", fallback: "Snooze Alarm on Scanner")
    /// Stop Alarm on Host
    internal static let stopAlarmButtonText = L10n.tr("Localizable", "VirtualTether.StopAlarmButtonText", fallback: "Stop Alarm on Host")
    /// Vibrate
    internal static let vibrateText = L10n.tr("Localizable", "VirtualTether.VibrateText", fallback: "Vibrate")
    /// Disabled on hosts that lack vibration capability.
    internal static let vibrationNotSupportedAlertText = L10n.tr("Localizable", "VirtualTether.VibrationNotSupportedAlertText", fallback: "Disabled on hosts that lack vibration capability.")
    /// Virtual tether is not supported by this scanner model
    internal static let virtualTetherNotSupportedAlertText = L10n.tr("Localizable", "VirtualTether.VirtualTetherNotSupportedAlertText", fallback: "Virtual tether is not supported by this scanner model.")


  }
}
// swiftlint:enable explicit_type_interface function_parameter_count identifier_name line_length
// swiftlint:enable nesting type_body_length type_name vertical_whitespace_opening_braces

// MARK: - Implementation Details

extension L10n {
  private static func tr(_ table: String, _ key: String, _ args: CVarArg..., fallback value: String) -> String {
    let format = BundleToken.bundle.localizedString(forKey: key, value: value, table: table)
    return String(format: format, locale: Locale.current, arguments: args)
  }
}

// swiftlint:disable convenience_type
private final class BundleToken {
  static let bundle: Bundle = {
    #if SWIFT_PACKAGE
    return Bundle.module
    #else
    return Bundle(for: BundleToken.self)
    #endif
  }()
}
// swiftlint:enable convenience_type
