//
//  MetaDataXmlParser.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation


///Responsible for parsing the Meta Data xml in the firmware plugin file for firmware update
class MetaDataXmlParser : NSObject, XMLParserDelegate {
    
    var currentElementName = ""
    var currentElementValue = ""
    
    var supportedScannerModelList = [String]()
    var firmwareVersionNameList = [String]()
    var pluginFamily = ""
    var pluginRevision = ""
    var pluginName = ""
    var pluginDate = ""
    var matchingPluginFWName = ""
    var pngFileName = ""

    
  

    ///sent by parser to delegate when a start tag is detected for a given element
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        if elementName == Constants.AppDetails.ZT_MODEL_LIST_TAG {
            supportedScannerModelList = [String]()
        } else if elementName == Constants.AppDetails.ZT_FIRMWARE_NAME_TAG{
            let mainFirmwareName = attributeDict["name"]?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            firmwareVersionNameList.append(mainFirmwareName)
        }
        currentElementName = elementName
    }
    
    ///sent by parser to delegate with the strings of the current element
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        
        currentElementValue = string.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if !currentElementValue.isEmpty {
            switch currentElementName {
            case Constants.AppDetails.ZT_MODEL_TAG:
                supportedScannerModelList.append(currentElementValue)
            case Constants.AppDetails.ZT_REVISION_TAG:
                pluginRevision = currentElementValue
            case Constants.AppDetails.ZT_IMAGE_TAG:
                pngFileName = currentElementValue
            case Constants.AppDetails.ZT_RELEASED_DATE_TAG:
                pluginDate = currentElementValue
            case Constants.AppDetails.ZT_FAMILY_TAG:
                pluginFamily = currentElementValue
            case Constants.AppDetails.ZT_NAME_TAG:
                pluginName = currentElementValue
            case Constants.AppDetails.ZT_FIRMWARE_COMPONENT:
                firmwareVersionNameList.append(currentElementValue)
                
            default:
                break
            }
        }
        
    }
    
    ///sent by parser to delegate when a end tag is detected for a given element
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {

    }
    
    ///sent by parser to delegate when the parsing is completed
    func parserDidEndDocument(_ parser: XMLParser) {

    }
    
    
}
