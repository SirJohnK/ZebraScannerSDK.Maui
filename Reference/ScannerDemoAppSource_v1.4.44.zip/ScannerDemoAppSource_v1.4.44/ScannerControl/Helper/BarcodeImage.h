//
//  BarcodeImage.h
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/*
 Responsible for generating parameter barcodes
 */

@interface BarcodeImage : NSObject

///Generate the parameter barcodes for a selected config code and imageview dimensions
///
/// - Parameter configBarcodeType: ConfigBarcode type
/// - Returns : UIImage for the parameter barcode with config code
///
+ (UIImage *) generateBarcodeImageUsingConfigCode : (NSString *)configurationCode withHeight:(CGFloat)imgHeight andWidth:(CGFloat)imgWidth;

@end

NS_ASSUME_NONNULL_END
