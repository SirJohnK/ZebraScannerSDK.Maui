//
//  DetectOrientation.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.
//

import Foundation
import SwiftUI

/// Responsible for detecting and notifying device orientation updates
struct DetectOrientation: ViewModifier {
    
    @Binding var orientation: UIDeviceOrientation
    
    func body(content: Content) -> some View {
        content
            .onReceive(NotificationCenter.default.publisher(for: UIDevice.orientationDidChangeNotification)) { _ in
                orientation = UIDevice.current.orientation
            }
    }
}

extension View {
    
    /// Detects the current orientation of the device
    func detectOrientation(_ orientation: Binding<UIDeviceOrientation>) -> some View {
        modifier(DetectOrientation(orientation: orientation))
    }
}
