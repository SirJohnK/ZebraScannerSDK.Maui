//
//  HapticManager.swift
//  ScannerControl
//
//  ©2024 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation
import CoreHaptics

///Class for handling vibration controls
class HapticManager : NSObject {
    private var engine: CHHapticEngine?
    private var continuousPlayer: CHHapticPatternPlayer?
    private var isEngineRunning = false

    static let shared: HapticManager = {
        let sharedInstance = HapticManager()
        return sharedInstance
    }()
    
    private override init() {
        super.init()
        self.createHapticEngine()
    }

   // Method to create haptic engine
   private func createHapticEngine() {
        do {
            self.engine = try CHHapticEngine()
        } catch {
            print("Error creating the haptic engine: \(error.localizedDescription)")
        }
    }

    //Method to start the vibration
    func vibrateHost() {
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return }

        do {

            if !isEngineRunning {
                try engine?.start()
                isEngineRunning = true
            }
            
        } catch {
            print("There was an error creating the haptic engine: \(error.localizedDescription)")
        }
        
                                
        let sharpness = CHHapticEventParameter(parameterID: .hapticSharpness, value: 0.6)
        let intensity = CHHapticEventParameter(parameterID: .hapticIntensity, value: 1)
        
        // Create a continuous event with a long duration from the parameters.
        let continuousEvent = CHHapticEvent(eventType: .hapticContinuous,
                                            parameters: [intensity, sharpness],
                                            relativeTime: 0,
                                            duration: 1000)


        do {
            // Create a pattern from the continuous haptic event.
            let pattern = try CHHapticPattern(events: [continuousEvent], parameters: [])
            
            // Create a player from the continuous haptic pattern.
            continuousPlayer = try engine?.makeAdvancedPlayer(with: pattern)
            try continuousPlayer?.start(atTime: 0)
            
        } catch let error {
            print("Pattern Player Creation Error: \(error)")
        }

    }
    
    //Method to stop vibration
    func stopVibration(){
        do {
            try continuousPlayer?.stop(atTime: CHHapticTimeImmediate)
            continuousPlayer = nil
            isEngineRunning = false
        } catch {
            print("Failed to stop pattern: \(error.localizedDescription)")
        }

    }
}
