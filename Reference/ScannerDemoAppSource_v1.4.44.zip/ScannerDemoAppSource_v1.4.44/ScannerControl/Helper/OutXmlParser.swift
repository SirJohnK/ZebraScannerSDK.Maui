//
//  OutXmlParser.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation

///Responsible for parsing the output xml in execute command calls
class OutXmlParser : NSObject, XMLParserDelegate {

    var xmlDict = [String: Any]()
    var xmlDictArr = [[String: Any]]()
    var currentElement = ""
    var attributeList = [AttributeDetail]()
    let attributeElementName = "attribute"

    ///sent by parser to delegate when a start tag is detected for a given element
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:]) {
        if elementName == attributeElementName {
            xmlDict = [:]
        } else {
            currentElement = elementName
        }
    }
    
    ///sent by parser to delegate with the strings of the current element
    func parser(_ parser: XMLParser, foundCharacters string: String) {
        if !string.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            if xmlDict[currentElement] == nil {
                   xmlDict.updateValue(string, forKey: currentElement)
            }
        }
    }
    
    ///sent by parser to delegate when a end tag is detected for a given element
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == attributeElementName {
                xmlDictArr.append(xmlDict)
        }
    }
    
    ///sent by parser to delegate when the parsing is completed
    func parserDidEndDocument(_ parser: XMLParser) {
         parsingCompleted()
    }
    
    ///for updating the output attribute list when parsing is completed
    func parsingCompleted() {
        self.attributeList = self.xmlDictArr.map { AttributeDetail(details: $0) }
    }

}


