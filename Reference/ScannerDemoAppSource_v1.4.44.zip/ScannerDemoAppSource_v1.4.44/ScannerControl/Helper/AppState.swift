//
//  AppState.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.
//

import Foundation
//import SwiftUI

/** To store all the global variables in centralized app state  **/
class AppState: ObservableObject {
    
    ///selected main tab
    @Published var selectedTab: MainTabView.Tab = AppSettings.shared.communicationMode == CommunicationMode.MFI.rawValue ? .MFI : .BLE
    ///true when the scanner is connected
    @Published var isScannerConnected : Bool = false
    ///Current connected scanner information
    @Published var connectedScanner: ScannerInfo!
    ///Available scanners in the vicinity
    @Published var availableScannerList: [ScannerInfo] = []
    ///true when the scanner is trying to connect
    @Published var connectionInProgress: Bool = false
    ///true when there's a connection attempt failure
    @Published var connectionFailed: Bool = false
    ///true when a background task is running
    @Published var loading: Bool = false
    ///customized text for loading view
    @Published var loadingText: String = "Loading..."
    ///Barcode list
    @Published var scannerBarcodeList: [BarcodeList] = []
    ///true when showing an alert
    @Published var showAlert: Bool = false
    ///progress value of the firmware update
    @Published var progressOfFirmwareUpdate: Float = 0.0
    ///to store the  last connected scanner details
    var lastConnectedScanner: ScannerInfo?
    ///to check firmware update status in order to navigate to update firmware screen when a scanner is connected
    @Published var isFirmwareUpdated: Bool = false
    ///to check whether firmware is updating or not
    @Published var isFirmwareUpdating: Bool = false
    ///to get back the firmware details after firmware update
    var updatedFirmwarePluginFile: FirmwareFile?
    ///to show firmware updated ui after firmware update completes
    @Published var isRebootCompleted: Bool = false
    ///to check whether firmware update has been aborted
    @Published var firmwareUpdateDidAbort: Bool = false
    ///to check temporary stopping of firmware update progress before firmware update abort is success or failed
    @Published var firmwareUpdateDidStop: Bool = false
    /// to check whether virtual tether host feedback is activated
    @Published var virtualTetherHostActivated: Bool = false
    /// to check whether virtual tether event occured
    @Published var virtualTetherEventOccurred: Bool = false
    ///Symbology list with current state (enable/disable)
    @Published var symbologyList: [Symbology] = []
    ///true when the scanner is connecting from the available scanner list
    @Published var isConnectFromAvailableList: Bool = false
    ///true if the disconnection is manual
    @Published var isManualDisconnection: Bool = false
    ///true if the background virtual tether event started
    @Published var isBackgroundVirtualTetherStarted: Bool = false
    /// true when the virtual tether auto navigation should happen
    @Published var isVirtualTetherScreenActive: Bool = false
    /// true when the currently connected scanner supports virtual tether
    @Published var isVirtualTetherSupported: Bool = false
    
    ///singleton AppState instance
    static let shared = AppState()
    
    ///private initilizer for the singleton instance
    private init() {
      
    }
    
    

}


