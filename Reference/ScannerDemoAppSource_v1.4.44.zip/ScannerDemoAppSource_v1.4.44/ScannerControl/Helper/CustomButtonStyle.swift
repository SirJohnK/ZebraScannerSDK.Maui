//
//  CustomButtonStyle.swift
//  ScannerControl
//
// ©2023 Zebra Technologies Corp. and/or its affiliates. All rights reserved.
//

import Foundation
import SwiftUI

struct CustomButtonStyle: ButtonStyle {
    func makeBody(configuration: Self.Configuration) -> some View {
        CustomButtonStyleView(configuration: configuration)
    }
}

private extension CustomButtonStyle {
    struct CustomButtonStyleView: View {
        @Environment(\.isEnabled) var isEnabled
        let configuration: CustomButtonStyle.Configuration
        
        var body: some View {
            return configuration.label
                .foregroundColor(.white)
                .textCase(/*@START_MENU_TOKEN@*/.uppercase/*@END_MENU_TOKEN@*/)
                .background(RoundedRectangle(cornerRadius: 5)
                    .fill(isEnabled ? Asset.blueColor.swiftUIColor : Asset.disabledBlueColor.swiftUIColor)
                )
                .opacity(configuration.isPressed ? 0.8 : 1.0)
        }
    }
}
