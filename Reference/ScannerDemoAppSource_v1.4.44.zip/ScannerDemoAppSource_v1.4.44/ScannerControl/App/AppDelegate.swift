//
//  AppDelegate.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation

class AppDelegate: NSObject, UIApplicationDelegate {
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil) -> Bool {
        Thread.sleep(forTimeInterval: 2.0)
        
        // Create a directory called "Download" to store firmware plugin files for firmware update
        createDirectory()
        
        UserDefaults.standard.register(defaults: [
            AppSettings.Keys.communicationMode.rawValue : CommunicationMode.MFI_BT_LE.rawValue,
            AppSettings.Keys.availableScannerBgNotification.rawValue : true,
            AppSettings.Keys.activeScannerBgNotification.rawValue : true,
            AppSettings.Keys.barcodeEventBgNotification.rawValue : false,
            AppSettings.Keys.discoverBluetoothScanners.rawValue : true,
            AppSettings.Keys.setFactoryDefaults.rawValue : false,
            AppSettings.Keys.autoConnectOnRelaunch.rawValue : false
                    ]
                )
        
        requestNotificationAuthorization()
        return true
    }
    
    // Method to request necessary permissions to display notifications
    func requestNotificationAuthorization() {
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if granted {
//                print("Notification permission granted.")
            } else {
//                print("Notification permission denied.")
            }
        }
    }
    
    // Create a directory in app's document folder
    func createDirectory () {
    
        let documentDirectoryPaths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)

        let documentDirectoryURL = documentDirectoryPaths[0]

        let newDir = documentDirectoryURL.appendingPathComponent(Constants.AppDetails.ZT_FW_FILE_DIRECTORY_NAME).path
        
        var isDirectory = ObjCBool(true)
        
        // Check the directory is exist or not
        let exists = FileManager.default.fileExists(atPath: newDir, isDirectory: &isDirectory)
        
        // Create a directory if the directory is not exist
        if (!exists || !isDirectory.boolValue){
            
            do {
                try FileManager.default.createDirectory(atPath: newDir,
                                            withIntermediateDirectories: true, attributes: nil)
            } catch let error as NSError {
                print("Error: \(error.localizedDescription)")
            }
        }
    }
}
