//
//  FirmwareFile.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation

///Data model for firmware file details
struct FirmwareFile : Hashable{
    
    var fileName: String?
    var fileType: FirmwareFileType?
    var fileURL: URL?
    var releaseNotes: String?
    var supportedModels: [String]?
    var pluginRevision: String?
    var pluginReleasedDate: String?
    var firmwareVersionNames: [String]?
    var pluginScannerImageName: String?
    var pluginScannerImage: UIImage?
    var pluginFamilyName: String?
   
  
    /// Method to get text with a combination of firmware revision, released date and matching firmware version
    /// - Parameter currentFWversion: current firmware version description
    /// - Returns: Text with a combination of firmware revision, released date and matching firmware version
    func getToText(currentFWversion: String) -> String {
        
        if let pluginRevision = pluginRevision, let pluginReleasedDate = pluginReleasedDate, let firmwareVersionNames = firmwareVersionNames {
            
            var matchingFWname = ""
            
            for fwName in firmwareVersionNames {
                if fwName.count > 3 && (fwName.prefix(3) == currentFWversion.prefix(3)) {
                    matchingFWname = fwName
                    break
                }
            }
            return pluginRevision + " - " + pluginReleasedDate + " (" + matchingFWname + ")"
        }else {
            if let fileType = fileType, let fileName = fileName, fileType == FirmwareFileType.DAT {
                if (AppState.shared.isRebootCompleted) {
                    return currentFWversion
                } else {
                    return (fileName as NSString).deletingPathExtension
                }
            }
            return ""
        }
    }
}




enum FirmwareFileType: String, CaseIterable {
    case DAT = "DAT"
    case SCNPLG = "SCNPLG"
}

