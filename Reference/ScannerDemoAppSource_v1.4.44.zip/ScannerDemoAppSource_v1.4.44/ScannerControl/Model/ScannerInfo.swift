//
//  ScannerInfo.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation

///Data model for scanner details
struct ScannerInfo : Hashable{
    
    var scannerId: Int32
    var connectionType: Int32
    var autoCommunicationSessionReestablishment: Bool
    var active: Bool
    var available: Bool
    var isStcConnected: Bool
    var scannerName: String
    var scannerModel: String
    var serialNo: String?
    var firmware: String?
    var dateOfManufacture: String?
    var configurationFileName: String?
    
    /// Method to get the display text for the connection type
    func getConnectionType() -> String {
        var connectionTypeText = "";
        switch (self.connectionType) {
        case Int32(SBT_CONNTYPE_MFI):
            connectionTypeText = "MFi"
            break;
        case Int32(SBT_CONNTYPE_BTLE):
            connectionTypeText = "BT LE"
            break;
        default:
            connectionTypeText = "Unknown"
        }
        return connectionTypeText
    }
}
