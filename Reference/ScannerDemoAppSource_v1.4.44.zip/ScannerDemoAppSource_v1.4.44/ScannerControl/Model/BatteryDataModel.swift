//
//  BatteryDataModel.swift
//  ScannerControl
//
//  ©2024 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation

///Data model for battery statictics
struct BatteryDataModel{

    var manufactureDate: String = ""
    var serialNumber: String = ""
    var modelNumber: String = ""
    var designCapacity: String = ""
    
    var stateOfHealth: String = ""
    var chargeCyclesConsumed: String = ""
    
    var fullChargeCapacity: String = ""
    var stateOfCharge: String = ""
    var remainingCapacity: String = ""
    
    var currentTemperature: String = ""
    var highestTemperature: String = ""
    var lowestTemperature: String = ""
    
        
}
