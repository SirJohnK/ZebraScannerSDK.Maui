//
//  BarcodeData.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation

///Data model for storing barcode details
struct BarcodeData : Identifiable, Hashable{
    
    let id = UUID()
    var barcodeType: Int32
    var barcodeData: Data
    var barcodeText: String
    var characterCount: Int
    
    init(barcodeType: Int32,barcodeData: Data) {
        self.barcodeData = barcodeData
        self.barcodeType = barcodeType
        self.barcodeText = {
            let bytes = barcodeData
            
            let decodeDataString = String(decoding: bytes, as: UTF8.self)
            /*
            var decodeDataString = String(data: bytes, encoding: .utf8)
             
            if (decodeDataString == nil) {
                let byteArrayFromData: [UInt8] = [UInt8](bytes)

                decodeDataString = "Data cannot be displayed as string:"
                for byte in byteArrayFromData {
                    decodeDataString?.append(String(format: "0x%02X ", byte))
                }
                
            }
             */

            return decodeDataString;
        }()
        self.characterCount = self.barcodeText.count
    }
    
    ///Method to get the symbology name corresponding to the symbology type
    func getBarcodeTypeAsString() -> String {
        
        switch(barcodeType){
        case Int32(Constants.SymbologyTypes.ST_CODE_39): return "CODE 39"
        case Int32(Constants.SymbologyTypes.ST_CODABAR): return "CODABAR"
        case Int32(Constants.SymbologyTypes.ST_CODE_128): return "CODE 128"
        case Int32(Constants.SymbologyTypes.ST_D2OF5): return "D 2 OF 5"
        case Int32(Constants.SymbologyTypes.ST_IATA): return "IATA"
        case Int32(Constants.SymbologyTypes.ST_I2OF5): return "I 2 OF 5"
        case Int32(Constants.SymbologyTypes.ST_CODE93): return "CODE 93"
        case Int32(Constants.SymbologyTypes.ST_UPCA): return "UPCA"
        case Int32(Constants.SymbologyTypes.ST_UPCE0): return "UPCE 0"
        case Int32(Constants.SymbologyTypes.ST_EAN8): return "EAN 8"
        case Int32(Constants.SymbologyTypes.ST_EAN13): return "EAN 13"
        case Int32(Constants.SymbologyTypes.ST_CODE11): return "CODE 11"
        case Int32(Constants.SymbologyTypes.ST_CODE49): return "CODE 49"
        case Int32(Constants.SymbologyTypes.ST_MSI): return "MSI"
        case Int32(Constants.SymbologyTypes.ST_EAN128): return "EAN 128"
        case Int32(Constants.SymbologyTypes.ST_UPCE1): return "UPCE 1"
        case Int32(Constants.SymbologyTypes.ST_PDF417): return "PDF 417"
        case Int32(Constants.SymbologyTypes.ST_CODE16K): return "CODE 16K"
        case Int32(Constants.SymbologyTypes.ST_C39FULL): return "C39FULL"
        case Int32(Constants.SymbologyTypes.ST_UPCD): return "UPCD"
        case Int32(Constants.SymbologyTypes.ST_TRIOPTIC): return "TRIOPTIC"
        case Int32(Constants.SymbologyTypes.ST_BOOKLAND): return "BOOKLAND"
        case Int32(Constants.SymbologyTypes.ST_COUPON): return "COUPON"
        case Int32(Constants.SymbologyTypes.ST_NW7): return "NW7"
        case Int32(Constants.SymbologyTypes.ST_ISBT128): return "ISBT128"
        case Int32(Constants.SymbologyTypes.ST_MICRO_PDF): return "MICRO PDF"
        case Int32(Constants.SymbologyTypes.ST_DATAMATRIX): return "DATAMATRIX"
        case Int32(Constants.SymbologyTypes.ST_QR_CODE): return "QR CODE"
        case Int32(Constants.SymbologyTypes.ST_MICRO_PDF_CCA): return "MICRO PDF CCA"
        case Int32(Constants.SymbologyTypes.ST_POSTNET_US): return "POSTNET US"
        case Int32(Constants.SymbologyTypes.ST_PLANET_CODE): return "PLANET CODE"
        case Int32(Constants.SymbologyTypes.ST_CODE_32): return "CODE 32"
        case Int32(Constants.SymbologyTypes.ST_ISBT128_CON): return "ISBT 128 CON"
        case Int32(Constants.SymbologyTypes.ST_JAPAN_POSTAL): return "JAPAN POSTAL"
        case Int32(Constants.SymbologyTypes.ST_AUS_POSTAL): return "AUS POSTAL"
        case Int32(Constants.SymbologyTypes.ST_DUTCH_POSTAL): return "DUTCH POSTAL"
        case Int32(Constants.SymbologyTypes.ST_MAXICODE): return "MAXICODE"
        case Int32(Constants.SymbologyTypes.ST_CANADIN_POSTAL): return "CANADA POSTAL"
        case Int32(Constants.SymbologyTypes.ST_UK_POSTAL): return "UK POSTAL"
        case Int32(Constants.SymbologyTypes.ST_MACRO_PDF): return "MACRO PDF"
        case Int32(Constants.SymbologyTypes.ST_RSS14): return "RSS 14"
        case Int32(Constants.SymbologyTypes.ST_RSS_LIMITED): return "RSS LIMITED"
        case Int32(Constants.SymbologyTypes.ST_RSS_EXPANDED): return "RSS EXPANDED"
        case Int32(Constants.SymbologyTypes.ST_SCANLET): return "ST SCANLET"
        case Int32(Constants.SymbologyTypes.ST_UPCA_2): return "UPCA 2"
        case Int32(Constants.SymbologyTypes.ST_UPCE0_2): return "UPCE0 2"
        case Int32(Constants.SymbologyTypes.ST_EAN8_2): return "EAN8 2"
        case Int32(Constants.SymbologyTypes.ST_EAN13_2): return "EAN13 2"
        case Int32(Constants.SymbologyTypes.ST_UPCE1_2): return "UPCE1 2"
        case Int32(Constants.SymbologyTypes.ST_CCA_EAN128): return "CCA EAN 128"
        case Int32(Constants.SymbologyTypes.ST_CCA_EAN13): return "CCA EAN 13"
        case Int32(Constants.SymbologyTypes.ST_CCA_EAN8): return "CCA EAN 8"
        case Int32(Constants.SymbologyTypes.ST_CCA_RSS_EXPANDED): return "CCA RSS EXPANDED"
        case Int32(Constants.SymbologyTypes.ST_CCA_RSS_LIMITED): return "CCA RSS LIMITED"
        case Int32(Constants.SymbologyTypes.ST_CCA_RSS14): return "CCA RSS 14"
        case Int32(Constants.SymbologyTypes.ST_CCA_UPCA): return "CCA UPCA"
        case Int32(Constants.SymbologyTypes.ST_CCA_UPCE): return "CCA UPCE"
        case Int32(Constants.SymbologyTypes.ST_CCC_EAN128): return "CCC EAN 128"
        case Int32(Constants.SymbologyTypes.ST_TLC39): return "TLC39"
        case Int32(Constants.SymbologyTypes.ST_CCB_EAN128): return "CCB EAN 128"
        case Int32(Constants.SymbologyTypes.ST_CCB_EAN13): return "CCB EAN 13"
        case Int32(Constants.SymbologyTypes.ST_CCB_EAN8): return "CCB EAN 8"
        case Int32(Constants.SymbologyTypes.ST_CCB_RSS_EXPANDED): return "CCB RSS EXPANDED"
        case Int32(Constants.SymbologyTypes.ST_CCB_RSS_LIMITED): return "CCB RSS LIMITED"
        case Int32(Constants.SymbologyTypes.ST_CCB_RSS14): return "CCB RSS 14"
        case Int32(Constants.SymbologyTypes.ST_CCB_UPCA): return "CCB UPCA"
        case Int32(Constants.SymbologyTypes.ST_CCB_UPCE): return "CCB UPCE"
        case Int32(Constants.SymbologyTypes.ST_SIGNATURE_CAPTURE): return "SIGNATURE CAPTURE"
        case Int32(Constants.SymbologyTypes.ST_MATRIX2OF5): return "MATRIX 2 OF 5"
        case Int32(Constants.SymbologyTypes.ST_CHINESE2OF5): return "CHINESE 2 OF 5"
        case Int32(Constants.SymbologyTypes.ST_UPCA_5): return "UPCA 5"
        case Int32(Constants.SymbologyTypes.ST_UPCE0_5): return "UPCE0 5"
        case Int32(Constants.SymbologyTypes.ST_EAN8_5): return "EAN8 5"
        case Int32(Constants.SymbologyTypes.ST_EAN13_5): return "EAN13 5"
        case Int32(Constants.SymbologyTypes.ST_UPCE1_5): return "UPCE1 5"
        case Int32(Constants.SymbologyTypes.ST_MACRO_MICRO_PDF): return "MACRO MICRO PDF"
        case Int32(Constants.SymbologyTypes.ST_MICRO_QR_CODE): return "MICRO QR CODE"
        case Int32(Constants.SymbologyTypes.ST_AZTEC): return "AZTEC"
        case Int32(Constants.SymbologyTypes.ST_HAN_XIN): return "HAN XIN"
        case Int32(Constants.SymbologyTypes.ST_KOREAN_3_OF_5): return "KOREAN 3 OF 5"
        case Int32(Constants.SymbologyTypes.ST_ISSN): return "ISSN"
        case Int32(Constants.SymbologyTypes.ST_MATRIX_2_OF_5): return "MATRIX 2 OF 5"
        case Int32(Constants.SymbologyTypes.ST_AZTEC_RUNE_CODE): return "AZTEC RUNE CODE"
        case Int32(Constants.SymbologyTypes.ST_NEW_COUPEN_CODE): return "NEW COUPON CODE"
        case Int32(Constants.SymbologyTypes.ST_DOT_CODE): return "DOT CODE"
        default: return ""
        }
    }

}
