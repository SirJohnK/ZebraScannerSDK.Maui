//
//  PairingHelpViewModel.swift
//  ScannerControl
//
//   ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation


extension PairingHelpView {
    
    enum ConfigBarcode: Hashable {
        case ResetFactoryDefault
        case CS6080_DS8178_MFi
        case CS4070_MFi
        case SetDefault
        case ResetFactoryDefault_CS4070
    }
    
    
    ///ViewModel for publishing UI updates to PairingHelpView
    ///
    /// - Returns : ObservableObject with below published properties
    /// - Property resetSetDefaultBarcodeImage : Generated barcode UIImage for Reset Factory Defaults
    /// - Property mfiConfigBarcodeImageCS6080 : Generated barcode UIImage for MFi configuration for CS6080/ DS8178
    /// - Property resetSetDefaultBarcodeImageCS4070 : Generated barcode UIImage for Reset Factory Defaults for CS4070
    /// - Property mfiConfigBarcodeImageCS4070 : Generated barcode UIImage for MFi configuration for CS4070
    /// - Property imageWidth : Width for barcode images in the screen
    /// - Property imageHeight : Height for barcode images in the screen
    ///
    
    @MainActor class ViewModel: ObservableObject {
        
        @Published var resetSetDefaultBarcodeImage: UIImage?
        @Published var mfiConfigBarcodeImageCS6080: UIImage?
        @Published var mfiConfigBarcodeImageCS4070: UIImage?
        @Published var resetSetDefaultBarcodeImageCS4070: UIImage?
        @Published var setDefaultBarcodeImage: UIImage?
        
        @Published var imageWidth: Double = UIScreen.main.bounds.width * 0.7
        @Published var imageHeight: Double = UIScreen.main.bounds.height * 0.09
        
        
        ///Get  Reset Factory Defaults barcode
        func getResetFactoryDefaultBarcode (){
            resetSetDefaultBarcodeImage = getParameterBarcode (configBarcodeType: .ResetFactoryDefault)
        }
        
        ///Get  MFi config barcode for CS6080/ DS8178
        func getMFiConfigBarcodeForCS6080_DS8178 (){
            mfiConfigBarcodeImageCS6080 = getParameterBarcode (configBarcodeType: .CS6080_DS8178_MFi)
        }
        
        ///Get  MFi config barcode for CS4070
        func getMFiConfigBarcodeForCS4070 (){
            mfiConfigBarcodeImageCS4070 = getParameterBarcode (configBarcodeType: .CS4070_MFi)
        }
        
        ///Get  Reset Factory Defaults barcode for CS4070
        func getResetFactoryDefaultBarcodeForCS4070 (){
            resetSetDefaultBarcodeImageCS4070 = getParameterBarcode (configBarcodeType: .ResetFactoryDefault_CS4070)
        }
        
        ///Get  Set  Defaults barcode
        func getSetDefaultBarcode (){
            setDefaultBarcodeImage = getParameterBarcode (configBarcodeType: .SetDefault)
        }
        
        
        ///Generate the parameter barcodes for a selected config code
        ///
        /// - Parameter configBarcodeType: ConfigBarcode type
        /// - Returns : UIImage for the parameter barcode with config code
        ///

        func getParameterBarcode (configBarcodeType: ConfigBarcode) -> UIImage {
            
            var configCode = ""
            
            switch configBarcodeType {
            case .ResetFactoryDefault:
                configCode = "92"
            case .ResetFactoryDefault_CS4070:
                configCode = "L01"
            case .CS6080_DS8178_MFi:
                configCode = "N017F13"
            case .CS4070_MFi:
                configCode = "N051704"
            case .SetDefault:
                configCode = "91"
            }
            let configBarcodeImage: UIImage = BarcodeImage.generate(usingConfigCode: configCode, withHeight: imageHeight, andWidth: imageWidth)
            
            return configBarcodeImage
        }
    }
}
