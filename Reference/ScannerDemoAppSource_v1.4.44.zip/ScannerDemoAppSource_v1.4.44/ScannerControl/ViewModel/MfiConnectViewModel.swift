//
//  MfiViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation


extension MfiConnectView {
    
    @MainActor class ViewModel: ObservableObject {
        @Published var MFiScannerList : [ScannerInfo] = []
        @Published var selection : ScannerInfo?
        
        let alertDetails = AlertDetails(alertType: .connectionError)
        
        ///Method to filter the MFi scanners from the available scanner list
        func getMFiScannerList() {
            MFiScannerList = AppState.shared.availableScannerList.filter{$0.connectionType == SBT_CONNTYPE_MFI}
        }
        
        ///Method to connect the scanner in MFi mode
        func connectMFiScanner(scanner: ScannerInfo) {
            AppState.shared.connectionInProgress = true
            
            DispatchQueue.background(background:{
                ZebraSDKManager.shared.connectToScanner(scannerId: scanner.scannerId)
            })
        }
    }
}
