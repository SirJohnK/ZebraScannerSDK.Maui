//
//  SymbologySettingsViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation


extension SymbologySettingsView {
    
    ///ViewModel for publishing UI updates to SymbologySettingsView
    ///
    /// - Returns : ObservableObject with published properties
    ///
    @MainActor class ViewModel: ObservableObject {
        
        @Published var setPersistSetting: Bool = false
        @Published var showPersistSetting: Bool = true ///Need to disable persist setting for CS4070 device
        var firstToggleChange: Bool = true
        
        init() {
            self.setPersistSettingVisibility()
            ZebraSDKManager.shared.retrieveSymbologyDetails()

            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.firstToggleChange = false
            }
        }
        
        ///Method to check the device model and show/hide persist settings
        func setPersistSettingVisibility() {
            if (AppState.shared.connectedScanner?.scannerModel != nil && AppState.shared.connectedScanner.scannerModel.contains(Constants.ScannerDetails.SCANNER_MODEL_SSI_CS4070)) {
                self.showPersistSetting = false
            }
        }
        
        ///Method to set or store the configuration change on a symbology
        /// - Parameter symbology: current symbology
        func setSymbologyConfiguration(symbology: Symbology) {
            ///This condition is required to block triggering set configuration on first load of the symbologies as toggle will be fired during that time also
            if (!self.firstToggleChange){
                if (setPersistSetting) {
                    ZebraSDKManager.shared.storeAttributeValue(attributeId: Int32(symbology.RMDAttributeId), attributeValue: symbology.enabled ? "True" : "False", attributeDataType: "F", scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
                } else {
                    ZebraSDKManager.shared.setAttributeValue(attributeId: Int32(symbology.RMDAttributeId), attributeValue: symbology.enabled ? "True" : "False", attributeDataType: "F", scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
                }
            }
        }
        
    }
}

