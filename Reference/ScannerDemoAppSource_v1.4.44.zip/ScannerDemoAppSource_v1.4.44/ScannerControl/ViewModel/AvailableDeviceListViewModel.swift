//
//  AvailableDeviceListViewModel.swift
//  ScannerControl
//
//   ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation


extension AvailableDeviceListView {
    
    ///ViewModel for publishing UI updates to AvailableDeviceListView
    ///
    /// - Returns : ObservableObject with published properties
    ///
    
    @MainActor class ViewModel: ObservableObject {
        
        @Published var lastConnectedOrCurrentConnectedScaner: ScannerInfo?
        @Published var otherScannersList: [ScannerInfo] = []
        @Published var selectedScannerFromList : ScannerInfo?
        let alertDetails = AlertDetails(alertType: .disconnectWithAlert)
        let connectionFailureAlert = AlertDetails(alertType: .connectionError)
        
        //Method to get available scanners
        func getOtherScannerList() {
            
            if let scanner = lastConnectedOrCurrentConnectedScaner {
                
                if (AppSettings.shared.communicationMode == CommunicationMode.MFI.rawValue) {
                    otherScannersList = AppState.shared.availableScannerList.filter{$0.scannerId != scanner.scannerId && $0.connectionType == Int32(SBT_CONNTYPE_MFI)}
                } else if (AppSettings.shared.communicationMode == CommunicationMode.BT_LE.rawValue) {
                    otherScannersList = AppState.shared.availableScannerList.filter{$0.scannerId != scanner.scannerId && $0.connectionType == Int32(SBT_CONNTYPE_BTLE)}
                } else {
                    otherScannersList = AppState.shared.availableScannerList.filter{$0.scannerId != scanner.scannerId}
                }

            }else{
                if (AppSettings.shared.communicationMode == CommunicationMode.MFI.rawValue) {
                    otherScannersList = AppState.shared.availableScannerList.filter{$0.connectionType == Int32(SBT_CONNTYPE_MFI)}
                } else if (AppSettings.shared.communicationMode == CommunicationMode.BT_LE.rawValue) {
                    otherScannersList = AppState.shared.availableScannerList.filter{$0.connectionType == Int32(SBT_CONNTYPE_BTLE)}
                } else {
                    otherScannersList = AppState.shared.availableScannerList
                }
            }
        }
        
        //Method for updating published properties based on App state properties
        func LoadScannerList() {
            
            if (AppState.shared.isScannerConnected){
                lastConnectedOrCurrentConnectedScaner = AppState.shared.connectedScanner
            }else if (AppState.shared.lastConnectedScanner != nil){
                lastConnectedOrCurrentConnectedScaner = AppState.shared.lastConnectedScanner
            }
            
            getOtherScannerList()
            
        }
        
        ///Method to connect the scanner in MFi mode
        func connectScanner() {
            
            DispatchQueue.main.async {
                AppState.shared.isConnectFromAvailableList = true
                AppState.shared.connectionInProgress = true
            }
            
            DispatchQueue.background(background:{
                if AppState.shared.isScannerConnected {
                    ZebraSDKManager.shared.disconnectScanner(scannerId: AppState.shared.connectedScanner.scannerId)
                }
                if let scannerId = self.selectedScannerFromList?.scannerId  {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                        ZebraSDKManager.shared.connectToScanner(scannerId: scannerId)
                    }
                }
            })
        }

    }
}
