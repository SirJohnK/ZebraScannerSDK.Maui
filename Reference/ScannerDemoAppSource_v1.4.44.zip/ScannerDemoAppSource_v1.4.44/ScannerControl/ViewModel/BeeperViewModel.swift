//
//  BeeperViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation


extension BeeperView {
    
    ///ViewModel for publishing UI updates to BeeperView
    ///
    /// - Returns : ObservableObject with published properties
    ///
    @MainActor class ViewModel: ObservableObject {
        var beeperSequenceList: [BeeperSequence] = []
        var beeperVolumeList: [BeeperVolume] = []
        var beeperFrequencyList: [BeeperFrequency] = []
        
        @Published var selectedVolume : BeeperVolume? = nil
        @Published var selectedSequence : BeeperSequence? = nil
        @Published var selectedFrequency : BeeperFrequency? = nil
        
        init() {
            self.loadBeeperVolumeList()
            self.loadBeeperSequenceList()
            self.loadBeeperFrequencyList()
        }
        
        ///Method to load beeper sequence settings list
        func loadBeeperSequenceList() {
            
            /// CS4070 firmware does not support SET ACTION commands to control beeper. Use SSI commands instead.
            if (AppState.shared.connectedScanner?.scannerModel != nil && AppState.shared.connectedScanner.scannerModel.contains(Constants.ScannerDetails.SCANNER_MODEL_SSI_CS4070)) {
                self.beeperSequenceList = [
                    .init(actionValue: SBT_BEEPCODE_SHORT_HIGH_1,
                          actionName: "One high short beep"),
                    .init(actionValue: SBT_BEEPCODE_SHORT_HIGH_2,
                          actionName: "Two high short beeps"),
                    .init(actionValue: SBT_BEEPCODE_SHORT_HIGH_3,
                          actionName: "Three high short beeps"),
                    .init(actionValue: SBT_BEEPCODE_SHORT_HIGH_4,
                          actionName: "Four high short beeps"),
                    .init(actionValue: SBT_BEEPCODE_SHORT_HIGH_5,
                          actionName: "Five high short beeps"),
                    .init(actionValue: SBT_BEEPCODE_SHORT_LOW_1,
                          actionName: "One low short beep"),
                    .init(actionValue: SBT_BEEPCODE_SHORT_LOW_2,
                          actionName: "Two low short beeps"),
                    .init(actionValue: SBT_BEEPCODE_SHORT_LOW_3,
                          actionName: "Three low short beeps"),
                    .init(actionValue: SBT_BEEPCODE_SHORT_LOW_4,
                          actionName: "Four low short beeps"),
                    .init(actionValue: SBT_BEEPCODE_SHORT_LOW_5,
                          actionName: "Five low short beeps"),
                    .init(actionValue: SBT_BEEPCODE_LONG_HIGH_1,
                          actionName: "One high long beep"),
                    .init(actionValue: SBT_BEEPCODE_LONG_HIGH_2,
                          actionName: "Two high long beeps"),
                    .init(actionValue: SBT_BEEPCODE_LONG_HIGH_3,
                          actionName: "Three high long beeps"),
                    .init(actionValue: SBT_BEEPCODE_LONG_HIGH_4,
                          actionName: "Four high long beeps"),
                    .init(actionValue: SBT_BEEPCODE_LONG_HIGH_5,
                          actionName: "Five high long beeps"),
                    .init(actionValue: SBT_BEEPCODE_LONG_LOW_1,
                          actionName: "One low long beep"),
                    .init(actionValue: SBT_BEEPCODE_LONG_LOW_2,
                          actionName: "Two low long beeps"),
                    .init(actionValue: SBT_BEEPCODE_LONG_LOW_3,
                          actionName: "Three low long beeps"),
                    .init(actionValue: SBT_BEEPCODE_LONG_LOW_4,
                          actionName: "Four low long beeps"),
                    .init(actionValue: SBT_BEEPCODE_LONG_LOW_5,
                          actionName: "Five low long beeps"),
                    .init(actionValue: SBT_BEEPCODE_FAST_WARBLE,
                          actionName: "Fast warble beep"),
                    .init(actionValue: SBT_BEEPCODE_SLOW_WARBLE,
                          actionName: "Slow warble beep"),
                    .init(actionValue: SBT_BEEPCODE_MIX1_HIGH_LOW,
                          actionName: "High-low beep"),
                    .init(actionValue: SBT_BEEPCODE_MIX2_LOW_HIGH,
                          actionName: "Low-high beep"),
                    .init(actionValue: SBT_BEEPCODE_MIX3_HIGH_LOW_HIGH,
                          actionName: "High-low-high beep"),
                    .init(actionValue: SBT_BEEPCODE_MIX4_LOW_HIGH_LOW,
                          actionName: "Low-high-low beep")
                ]
            } else {
                self.beeperSequenceList = [
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_HIGH_SHORT_BEEP_1),
                          actionName: "One high short beep"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_HIGH_SHORT_BEEP_2),
                          actionName: "Two high short beeps"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_HIGH_SHORT_BEEP_3),
                          actionName: "Three high short beeps"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_HIGH_SHORT_BEEP_4),
                          actionName: "Four high short beeps"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_HIGH_SHORT_BEEP_5),
                          actionName: "Five high short beeps"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_LOW_SHORT_BEEP_1),
                          actionName: "One low short beep"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_LOW_SHORT_BEEP_2),
                          actionName: "Two low short beeps"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_LOW_SHORT_BEEP_3),
                          actionName: "Three low short beeps"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_LOW_SHORT_BEEP_4),
                          actionName: "Four low short beeps"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_LOW_SHORT_BEEP_5),
                          actionName: "Five low short beeps"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_HIGH_LONG_BEEP_1),
                          actionName: "One high long beep"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_HIGH_LONG_BEEP_2),
                          actionName: "Two high long beeps"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_HIGH_LONG_BEEP_3),
                          actionName: "Three high long beeps"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_HIGH_LONG_BEEP_4),
                          actionName: "Four high long beeps"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_HIGH_LONG_BEEP_5),
                          actionName: "Five high long beeps"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_LOW_LONG_BEEP_1),
                          actionName: "One low long beep"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_LOW_LONG_BEEP_2),
                          actionName: "Two low long beeps"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_LOW_LONG_BEEP_3),
                          actionName: "Three low long beeps"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_LOW_LONG_BEEP_4),
                          actionName: "Four low long beeps"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_LOW_LONG_BEEP_5),
                          actionName: "Five low long beeps"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_FAST_WARBLE_BEEP),
                          actionName: "Fast warble beep"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_SLOW_WARBLE_BEEP),
                          actionName: "Slow warble beep"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_HIGH_LOW_BEEP),
                          actionName: "High-low beep"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_LOW_HIGH_BEEP),
                          actionName: "Low-high beep"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_HIGH_LOW_HIGH_BEEP),
                          actionName: "High-low-high beep"),
                    .init(actionValue: Int(RMD_ATTR_VALUE_ACTION_LOW_HIGH_LOW_BEEP),
                          actionName: "Low-high-low beep")
                ]
                
            }
            
            //setting default beeper action
            self.selectedSequence = beeperSequenceList[0]
            
        }
        
        ///Method to load beeper volume settings list
        func loadBeeperVolumeList() {
            self.beeperVolumeList = [
                .init(actionValue: RMD_ATTR_VALUE_BEEPER_VOLUME_LOW, actionName: "Low"),
                .init(actionValue: RMD_ATTR_VALUE_BEEPER_VOLUME_MEDIUM, actionName: "Medium"),
                .init(actionValue: RMD_ATTR_VALUE_BEEPER_VOLUME_HIGH, actionName: "High")
            ]
            
        }
        
        ///Method to load beeper frequency settings list
        func loadBeeperFrequencyList() {
            self.beeperFrequencyList = [
                .init(actionValue: RMD_ATTR_VALUE_BEEPER_FREQ_LOW, actionName: "Low"),
                .init(actionValue: RMD_ATTR_VALUE_BEEPER_FREQ_MEDIUM, actionName: "Medium"),
                .init(actionValue: RMD_ATTR_VALUE_BEEPER_VOLUME_HIGH, actionName: "High")
            ]
        }
        
        ///Method to get beeper volume and frequency settings for the connected scanner
        func getBeeperSettings() {
            
            let attributeDetailList = ZebraSDKManager.shared.getAttributeValues(attributeIdList: [RMD_ATTR_BEEPER_VOLUME,RMD_ATTR_BEEPER_FREQUENCY], scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            
            for attribute in attributeDetailList{
                if (Int32(attribute.attributeId) == RMD_ATTR_BEEPER_VOLUME) {
                    let beeperVolume = Int32(attribute.attributeValue)
                    
                    switch (beeperVolume) {
                    case RMD_ATTR_VALUE_BEEPER_VOLUME_LOW:
                        self.selectedVolume = BeeperVolume(actionValue: RMD_ATTR_VALUE_BEEPER_VOLUME_LOW, actionName: "Low")
                        break
                    case RMD_ATTR_VALUE_BEEPER_VOLUME_MEDIUM:
                        self.selectedVolume = BeeperVolume(actionValue: RMD_ATTR_VALUE_BEEPER_VOLUME_MEDIUM, actionName: "Medium")
                        break
                    case RMD_ATTR_VALUE_BEEPER_VOLUME_HIGH:
                        self.selectedVolume = BeeperVolume(actionValue: RMD_ATTR_VALUE_BEEPER_VOLUME_HIGH, actionName: "High")
                        break
                    default:
                        self.selectedVolume = BeeperVolume(actionValue: RMD_ATTR_VALUE_BEEPER_VOLUME_HIGH, actionName: "High")
                    }
                    
                } else if (Int32(attribute.attributeId) == RMD_ATTR_BEEPER_FREQUENCY) {
                    let beeperFrequency = Int32(attribute.attributeValue)
                    
                    switch (beeperFrequency) {
                    case RMD_ATTR_VALUE_BEEPER_FREQ_LOW:
                        self.selectedFrequency = BeeperFrequency(actionValue: RMD_ATTR_VALUE_BEEPER_FREQ_LOW, actionName: "Low")
                        break
                    case RMD_ATTR_VALUE_BEEPER_FREQ_MEDIUM:
                        self.selectedFrequency = BeeperFrequency(actionValue: RMD_ATTR_VALUE_BEEPER_FREQ_MEDIUM, actionName: "Medium")
                        break
                    case RMD_ATTR_VALUE_BEEPER_FREQ_HIGH:
                        self.selectedFrequency = BeeperFrequency(actionValue: RMD_ATTR_VALUE_BEEPER_VOLUME_HIGH, actionName: "High")
                        break
                    default:
                        self.selectedFrequency = BeeperFrequency(actionValue: RMD_ATTR_VALUE_BEEPER_FREQ_MEDIUM, actionName: "Medium")
                        
                    }
                }
            }
        }
        
        /// Update beeper volume of scanner
        func updateBeeperVolume(){
            let beeperVolume = selectedVolume?.actionValue ?? RMD_ATTR_VALUE_BEEPER_VOLUME_HIGH
            ZebraSDKManager.shared.setAttributeValue(attributeId: RMD_ATTR_BEEPER_VOLUME, attributeValue: String(beeperVolume), attributeDataType: "B", scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
        }
        
        /// Update beeper frequency of scanner
        func updateBeeperFrequency(){
            let beeperFrequency = selectedFrequency?.actionValue ?? RMD_ATTR_VALUE_BEEPER_FREQ_MEDIUM
            ZebraSDKManager.shared.setAttributeValue(attributeId: RMD_ATTR_BEEPER_FREQUENCY, attributeValue: String(beeperFrequency), attributeDataType: "B", scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
        }
        
        ///Perform beeper sequence action
        func performBeeperSequenceAction() {
            let beeperSequence = selectedSequence?.actionValue ?? 0
            /// CS4070 firmware does not support SET ACTION commands to control beeper. Use SSI commands instead.
            if (AppState.shared.connectedScanner?.scannerModel != nil && AppState.shared.connectedScanner.scannerModel.contains(Constants.ScannerDetails.SCANNER_MODEL_SSI_CS4070)){
                ZebraSDKManager.shared.performBeepControl(actionValue: beeperSequence, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            } else {
                ZebraSDKManager.shared.setAction(actionValue: beeperSequence, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            }
        }
        
    }
}

