//
//  VirtualTetherViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation
import AVKit
import SwiftUI
import CoreHaptics

extension VirtualTetherView {
    
    ///ViewModel for publishing UI updates to VirtualTetherView
    ///
    /// - Returns : ObservableObject with published properties
    ///
    @MainActor class ViewModel: ObservableObject {
        
        /// This property is for enabling/disabling  all virtual tether host feedback toggles
        @Published var enableHostFeedbackToggles: Bool = AppSettings.shared.enableHostFeedbackToggles {
            didSet {
                DispatchQueue.main.async {
                    AppSettings.shared.enableHostFeedbackToggles = self.enableHostFeedbackToggles
                }
            }
        }
        
        /// Toggle value for 'Enable Virtual Tether'
        @Published var enableVirtualTether: Bool = AppSettings.shared.enableVirtualTether {
            didSet {
                //Enable/Disable host feedback sliders when virtual tether is enabled/disabled
                self.enableHostFeedbackToggles = self.enableVirtualTether
                
            }
        }
        
        /// Toggle value for 'Simulate Alarm'
        @Published var simulateAlarm: Bool = false {
            didSet {
                self.validateSimulateAlarm()
            }
        }
        
        @Published var enableStopAlarmOnHostButton: Bool = false
        @Published var enableSnoozeAlarmOnScannerButton: Bool = false
        @Published var enableSimulateAlarmToggle: Bool = true
        private var isOnPause: Bool = false
        private var virtualTetherSimulationOccurred: Bool = false
        private var snoozeTimer: Timer?
        private var simulationTimer: Timer?
        private var hostFeedbackSimulationTimer: Timer?
        private var virtualTetherHostAlarmStopped: Bool = false
        private var audioPlayer: AVAudioPlayer?
        private var audioAlarmTimer: Timer?
        private var vibrationTimer: Timer?
        @Published var displayPopup: Bool = false
        @Published var enableVibration: Bool = true
        @Published var showVibrationDisabledAlert: Bool = false
        
        /// Toggle value for 'Enable Host Feedback'
        @Published var enableHostFeedback: Bool = AppSettings.shared.enableHostFeedback {
            didSet {
                AppSettings.shared.enableHostFeedback = self.enableHostFeedback
                self.validateSimulateAlarm()
            }
        }
        
        /// Toggle value for 'Vibrate'
        @Published var virtualTetherVibration: Bool = AppSettings.shared.virtualTetherVibration {
            didSet {
                AppSettings.shared.virtualTetherVibration = self.virtualTetherVibration
                validateHostFeedbacks()
                
            }
        }
        
        /// Toggle value for 'Audio Alarm'
        @Published var virtualTetherAudioAlarm: Bool = AppSettings.shared.virtualTetherAudioAlarm {
            didSet {
                AppSettings.shared.virtualTetherAudioAlarm = self.virtualTetherAudioAlarm
                validateHostFeedbacks()
                
            }
        }
        
        /// Toggle value for 'Flashing Screen'
        @Published var virtualTetherFlashingScreen: Bool = AppSettings.shared.virtualTetherFlashingScreen {
            didSet {
                AppSettings.shared.virtualTetherFlashingScreen = self.virtualTetherFlashingScreen
                validateHostFeedbacks()
                
            }
        }
        
        /// Toggle value for 'Pop-up message'
        @Published var virtualTetherPopupMessage: Bool = AppSettings.shared.virtualTetherPopupMessage {
            didSet {
                AppSettings.shared.virtualTetherPopupMessage = self.virtualTetherPopupMessage
                validateHostFeedbacks()
                
            }
        }
        
        /// Color for the flashing background
        @Published var backgroundColor = Asset.defaultBgColor.swiftUIColor
        
        /// Check current virtual tether status and enable host feedbacks when virtual tether screen appears (This will be triggered when the app displays the virtual tether screen when scanner forcefully disconnects or went out of range)
        func checkVirtualTetherEventStatus() {
            AppState.shared.virtualTetherEventOccurred = AppSettings.shared.virtualTetherNotifyEvent
            if (AppState.shared.virtualTetherEventOccurred || AppState.shared.virtualTetherHostActivated) {
                self.enableStopAlarmOnHostButton = true
                self.virtualTetherHostAlarmStopped = false
                self.startVirtualTetherAudioAlarmFunction()
                self.startVirtualTetherPopupMessageFunction()
                self.startVirtualTetherVibrationFunction()
                self.startFlashScreen()
                                
            }
        }
        
        /// Method for validating host feedback toggles with host feedback options
        func validateHostFeedbacks () {
            if (!self.virtualTetherVibration && !self.virtualTetherAudioAlarm && !self.virtualTetherFlashingScreen && !self.virtualTetherPopupMessage) {
                self.enableHostFeedback = false
                
            } else if (self.virtualTetherVibration || self.virtualTetherAudioAlarm || self.virtualTetherFlashingScreen || self.virtualTetherPopupMessage){
                self.enableHostFeedback = true
            }
            self.validateSimulateAlarm()
        }
        
        /// Method for validating simulate alarm to enable/disable snooze and stop alarm buttons
        func validateSimulateAlarm () {
            if (self.simulateAlarm && self.enableHostFeedback) {
                self.enableStopAlarmOnHostButton = true
            } else if (!self.enableHostFeedback || !self.simulateAlarm) {
                self.enableStopAlarmOnHostButton = false
            }
        }
        
        /// Method for turning on and turning off  all host feedback toggles
        func enableAllHostFeedbackOptionToggles(turnOn: Bool){
            self.enableHostFeedback = turnOn
            // Disable vibration feedback for unsupported devices
            if (!self.supportsHaptics()) {
                self.virtualTetherVibration = false
            } else {
                self.virtualTetherVibration = turnOn
            }
            self.virtualTetherAudioAlarm = turnOn
            self.virtualTetherFlashingScreen = turnOn
            self.virtualTetherPopupMessage = turnOn
        }
        
        
        /// Method to snooze the alarm on scanner
        func snoozeAlarmOnScanner(){
            
            /// invalidate other timers
            self.simulationTimer?.invalidate()
    
            self.isOnPause = true
            
            /// stop simulation
            stopVirtualTetherSimulation()
            self.enableSnoozeAlarmOnScannerButton = false
            self.enableSimulateAlarmToggle = false
            
            /// restart virtual tether simulation after 3 seconds
            self.snoozeTimer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: false) { _ in
                Task {
                    await self.restartSimulation()
                    
                }
            }
        }
        
        /// Method to restart simulation after snooze timeout
        func restartSimulation() {

            self.enableSnoozeAlarmOnScannerButton = true
            self.initiateVirtualTetherSimulation()
        }
        
        /// Method to get the virtual tether scanner status
        func getVirtualTetherScannerStatus() {
            let attributeList = ZebraSDKManager.shared.getAttributeValues(attributeIdList: [RMD_ATTR_VIRTUAL_TETHER_ALARM_STATUS], scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            if (attributeList.count > 0) {
                let virtualTetherStatus = attributeList[0].attributeValue
                self.enableVirtualTether = Int32(virtualTetherStatus) == 0 ? false : true
            }
        }
        
        ///Method to call the API to enable or disable  virtual tether in scanner
        func enableDisableVirtualTetherAlarm(turnOn: Bool) {
            
            let command = Int(turnOn ? RMD_ATTR_VALUE_VIRTUAL_TETHER_ALARM_ENABLE : RMD_ATTR_VALUE_VIRTUAL_TETHER_ALARM_DISABLE)
            let result: SBT_RESULT =  ZebraSDKManager.shared.enableDisableVirualTether(command: command, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            if (result == SBT_RESULT_SUCCESS) {
                AppSettings.shared.enableVirtualTether = turnOn ? true : false
                //Enable disable host feedback on enable success
                AppSettings.shared.enableHostFeedback = turnOn ? true : false
                self.enableHostFeedback = turnOn ? true : false
            }
        }
        
        /// This method will initiate necessary callbacks and functions related to virtual tether simulation when simulation toggle is enabled
        func onSimulationEnabled() {
            if (self.simulateAlarm) {
                
                initiateVirtualTetherSimulation()
                
                simulateVirtualTetherHostFeedback()
                
                virtualTetherSimulationOccurred = true
                
                
                /// stop virtual tether host feedback simulation after 5 seconds
                self.hostFeedbackSimulationTimer = Timer.scheduledTimer(withTimeInterval: 5.0, repeats: false) { _ in
                    Task {
                        await self.stopVirtualTetherHostFeedbackSimulation()
                    }
                }
            }
            
        }
        
        /// This method is responsible for initiating the simulation process of Virtual Tether audio, LED ,haptics , illumination alarms
        func initiateVirtualTetherSimulation() {
            //invalidate other timers
            self.snoozeTimer?.invalidate()
            
            self.isOnPause = false
            startVirtualTetherSimulation()
            
            /// stop virtual tether simulation after 5 seconds
            self.simulationTimer = Timer.scheduledTimer(withTimeInterval: 5.0, repeats: false) { _ in
                Task {
                    await self.stopVirtualTetherSimulation()
                }
            }
            
        }
        
        /// This method is responsible for simulating the Virtual Tether audio, LED, haptics and illumination alarms.
        func startVirtualTetherSimulation() {
            self.enableSnoozeAlarmOnScannerButton = true
            self.simulateAlarm = true
            self.enableSimulateAlarmToggle = false
            self.virtualTetherHostAlarmStopped = false
            
            ZebraSDKManager.shared.startStopVirtualTetherSimulation(command: Int(RMD_ATTR_VALUE_ACTION_VIRTUAL_TETHER_SIMULATION_ENABLE), scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
        }
        
        /// This method is responsible for disabling the simulation of the Virtual Tether audio, LED, haptics and illumination alarms.
        func stopVirtualTetherSimulation() {
            ZebraSDKManager.shared.startStopVirtualTetherSimulation(command: Int(RMD_ATTR_VALUE_ACTION_VIRTUAL_TETHER_SIMULATION_DISABLE), scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            self.enableSnoozeAlarmOnScannerButton = false
            self.virtualTetherHostAlarmStopped = true

            
            if(!isOnPause) {
                self.simulateAlarm = false
                self.enableSimulateAlarmToggle = true
            }
        }
        
        /// Method to simulate virtual tether host feedback options
        func simulateVirtualTetherHostFeedback() {
            
            //simulate host audio alarm
            if(self.virtualTetherAudioAlarm) {
                self.startAudioAlarm()
            }
            //simulate popup message
            if(self.virtualTetherPopupMessage) {
                self.displayPopup = true
            }
            //simulate vibration
            if(self.virtualTetherVibration) {
                self.startVirtualTetherVibrationFunction()
            }
            //simulate flashing screen
            if (self.virtualTetherFlashingScreen) {
                self.startFlashScreen()
            }
        }
        
        // Configure background audio session to override silent mode but respect system volume
        func configureAudioSession() {
            do {
                try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.duckOthers])
                try AVAudioSession.sharedInstance().setActive(true)
            } catch {
                print("Failed to set audio session: \(error.localizedDescription)")
            }
        }
        
        /// Method to start virtual tether audio alarm
        func startAudioAlarm() {
            configureAudioSession()
            guard let sound = Bundle.main.path(forResource: Constants.VirtualTetherResource.AUDIO_FILE, ofType: Constants.VirtualTetherResource.AUDIO_FILE_TYPE) else {
                    return
                }
            do {
                if audioPlayer?.isPlaying == true {
                        audioPlayer?.stop()
                }
                self.audioPlayer = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound))
                self.audioPlayer?.volume = 1
                self.audioPlayer?.play()
                self.audioAlarmTimer?.invalidate()
                self.audioAlarmTimer = Timer.scheduledTimer(withTimeInterval: 3, repeats: true, block: { (timer) in
                    Task {
                        await self.audioPlayer?.play()
                    }
                })
            } catch {
                print("Eror while playing audio.")
            }
        }
        
        /// Method to stop the Virtual Tether host alarms
        func stopVirtualTetherHostFeedbackAlarms() {
            AppState.shared.virtualTetherEventOccurred = AppSettings.shared.virtualTetherNotifyEvent
            if (AppState.shared.virtualTetherEventOccurred || AppState.shared.virtualTetherHostActivated || self.virtualTetherSimulationOccurred) {
                self.enableStopAlarmOnHostButton = false
                self.virtualTetherHostAlarmStopped = true
                AppState.shared.virtualTetherHostActivated = false
                //stop audio alarm
                stopVirtualTetherAudioAlarmOnHost()
                //hide popup message
                self.displayPopup = false
                //stop vibration alarm
                stopVirtualTetherVibrationOnHost()
                //stop flashing screen
                self.stopFlashScreen()
            }

        }
        
        /// Method to stop simulation of the Virtual Tether host alarms.
        func stopVirtualTetherHostFeedbackSimulation() {
            
            if (AppState.shared.virtualTetherEventOccurred || self.virtualTetherSimulationOccurred) {
                // invalidate simulation timer
                self.hostFeedbackSimulationTimer?.invalidate()
                
                self.enableStopAlarmOnHostButton = false
                self.virtualTetherHostAlarmStopped = true
                AppState.shared.virtualTetherHostActivated = false
                //stop audio alarm
                stopVirtualTetherAudioAlarmOnHost()
                //hide popup message
                self.displayPopup = false
                //stop vibration
                stopVirtualTetherVibrationOnHost()
                //stop flashing screen
                self.stopFlashScreen()

                self.virtualTetherSimulationOccurred = false
            }
        }
        
        /// Method to stop the virtual tether audio alarm on host
        func stopVirtualTetherAudioAlarmOnHost() {
            //stop audio player alarm
            self.audioPlayer?.stop()
            self.audioAlarmTimer?.invalidate()
            do {
                try AVAudioSession.sharedInstance().setActive(false)
            } catch {
                print("Failed to unset audio session: \(error.localizedDescription)")
            }
        }
        

        //MARK: Below methods will be called when virtual tether gets activated without simulation(on foreceful disconnection/when out of range)
        /// Method to start  virtual tether audio alarm when virtual tether screen is coming back to the foreground when communication termination event occurs
        func startVirtualTetherAudioAlarmFunction() {
            if (AppSettings.shared.virtualTetherAudioAlarm) {
                self.startAudioAlarm()
            }

        }
        
        /// Method to start  virtual tether popup message when virtual tether screen is coming back to the foreground when communication termination event occurs
        func startVirtualTetherPopupMessageFunction() {
            if (AppSettings.shared.virtualTetherPopupMessage) {
                self.displayPopup = true
            }

        }
        
        /// Method to start  virtual tether vibration when virtual tether screen is coming back to the foreground when communication termination event occurs
        func startVirtualTetherVibrationFunction() {
            if (AppSettings.shared.virtualTetherVibration) {
                HapticManager.shared.vibrateHost()
            }

        }
        
        /// Method to stop the virtual tether vibration on host
        func stopVirtualTetherVibrationOnHost() {
            //stop vibration
            HapticManager.shared.stopVibration()
        }
        
        /// Method to start flashing screen
        private func startFlashScreen() {
            
            if (AppSettings.shared.virtualTetherFlashingScreen) {
                // Set first color with ease in animation
                withAnimation(.easeIn){
                    self.backgroundColor = Asset.flashingBlueColor.swiftUIColor
                }
                
                // wait for 1 second
                DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1), execute: {
                    // Back to normal color with ease out animation
                    withAnimation(.easeOut){
                        self.backgroundColor = Asset.defaultBgColor.swiftUIColor
                    }
                    if (!self.virtualTetherHostAlarmStopped ) {
                        self.startFlashScreen()
                    }
                })
            }
        }
        
        /// Method to stop flashing screen
        private func stopFlashScreen() {
            
            self.backgroundColor = Asset.defaultBgColor.swiftUIColor
        }
        
        /// Deactivate vibration toggle based on haptic support
        func checkVibrationSupport() {
            self.enableVibration = supportsHaptics()
        }
        
        /// Method to check whether the host device supports vibration/haptics
        func supportsHaptics() -> Bool {
            return CHHapticEngine.capabilitiesForHardware().supportsHaptics
        }
    }
    
    
}
