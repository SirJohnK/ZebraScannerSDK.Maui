//
//  AppSettingsViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

extension AppSettingsView {
    
    ///ViewModel for publishing UI updates to AppSettingsView
    ///
    /// - Returns : ObservableObject with below published properties
    /// - Property setFactoryDefaults : Selected default setting (Set Factory Defaults/ Keep current Setting)
    ///
    @MainActor class ViewModel: ObservableObject {
        
        @Published var setFactoryDefaults: Bool = AppSettings.shared.setFactoryDefaults {
            didSet {
                AppSettings.shared.setFactoryDefaults = self.setFactoryDefaults
                checkDefaults()
            }
        }
        @Published var selectedCommunicationMode = AppSettings.shared.communicationMode {
            didSet {
                AppSettings.shared.communicationMode = self.selectedCommunicationMode
                checkDefaults()
            }
        }
        @Published var availableScannerBgNotification = AppSettings.shared.availableScannerBgNotification {
            didSet {
                AppSettings.shared.availableScannerBgNotification = self.availableScannerBgNotification
                checkDefaults()
            }
        }
        @Published var activeScannerBgNotification = AppSettings.shared.activeScannerBgNotification {
            didSet {
                AppSettings.shared.activeScannerBgNotification = self.activeScannerBgNotification
                checkDefaults()
            }
        }
        @Published var barcodeEventBgNotification = AppSettings.shared.barcodeEventBgNotification {
            didSet {
                AppSettings.shared.barcodeEventBgNotification = self.barcodeEventBgNotification
                checkDefaults()
            }
        }
        @Published var discoverBluetoothscanners = AppSettings.shared.discoverBluetoothScanners {
            didSet {
                AppSettings.shared.discoverBluetoothScanners = self.discoverBluetoothscanners
                enableBluetoothScannerDiscovery()
                checkDefaults()
            }
        }
        @Published var autoReconnectOnRelaunch = AppSettings.shared.autoConnectOnRelaunch {
            didSet {
                AppSettings.shared.autoConnectOnRelaunch = self.autoReconnectOnRelaunch
                setAutoReconnectOnRelaunchStatus()
                checkDefaults()
            }
        }
        @Published var enableResetDefaults = false
        
        ///Reset to default parameters
        func resetDefaults() {
            self.setFactoryDefaults = false
            self.selectedCommunicationMode = CommunicationMode.MFI_BT_LE.rawValue
            self.availableScannerBgNotification = true
            self.activeScannerBgNotification = true
            self.barcodeEventBgNotification = false
            self.discoverBluetoothscanners = true
            self.autoReconnectOnRelaunch = false
        }
        
        /// Enable bluetooth scanner discovery based on toggle change
        func enableBluetoothScannerDiscovery() {
            ZebraSDKManager.shared.enableScannerDetection(detection: self.discoverBluetoothscanners)
        }
        
        /// Method to check whether the default settings has been changed
        func checkDefaults(){
            if (self.setFactoryDefaults == false &&
                self.selectedCommunicationMode == CommunicationMode.MFI_BT_LE.rawValue &&
                self.availableScannerBgNotification == true &&
                self.activeScannerBgNotification == true &&
                self.barcodeEventBgNotification == false &&
                self.discoverBluetoothscanners == true &&
                self.autoReconnectOnRelaunch == false
            ) {
                self.enableResetDefaults = false
            } else {
                self.enableResetDefaults = true
            }
        }
        
        ///Method to enable/disable auto connection on app relaunch for BLE scanner
        func setAutoReconnectOnRelaunchStatus(){
            ZebraSDKManager.shared.autoConnectOnAppRelaunch(enable: self.autoReconnectOnRelaunch)
        }
        
    }
    
}
