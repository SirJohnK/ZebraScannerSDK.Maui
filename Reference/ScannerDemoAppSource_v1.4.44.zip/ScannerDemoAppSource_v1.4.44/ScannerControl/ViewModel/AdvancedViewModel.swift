//
//  AdvancedViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation
import SwiftUI

extension AdvancedView {
    
    ///ViewModel for publishing UI updates to AdvancedView
    ///
    /// - Returns : ObservableObject with published properties
    ///
    @MainActor class ViewModel: ObservableObject {
        
        @ObservedObject var appState = AppState.shared
        @Published var enableFindScannerButton: Bool = true
        var timerTask: Timer?
        var endTime: Date?
        @Published var batteryStatictics: BatteryDataModel?
        @Published var unsupportedBattery: Bool = true
        
        /// Method to start the find scanner action
        func startFindScannerAction() {
            self.enableFindScannerButton = false
            self.turnOnOffLEDPattern(enable: true)
            self.beepScanner()
            self.vibrateScanner()
            
            endTime = Date().addingTimeInterval(3)
            timerTask = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(repeatTask), userInfo: nil, repeats: true)
            
        }
        
        /// Method to repeat the beeper and vibration
        @objc func repeatTask() {
            if Date() >= endTime ?? Date() {
                timerTask?.invalidate()
                self.turnOnOffLEDPattern(enable: false)
                self.enableFindScannerButton = true
                return
            }
            self.vibrateScanner()
            self.beepScanner()
        }
        
        
        /// Method to turn on and turn off LED pattern
        func turnOnOffLEDPattern(enable: Bool) {
            
            
            /// CS4070 firmware does not support SET ACTION commands to control LED. Use SSI commands instead.
            if (AppState.shared.connectedScanner?.scannerModel != nil && AppState.shared.connectedScanner.scannerModel.contains(Constants.ScannerDetails.SCANNER_MODEL_SSI_CS4070)){
                let ledControlCode: Int = SBT_LEDCODE_RED
                ZebraSDKManager.shared.performLedControl(ledEnable: enable, ledCode: ledControlCode, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
                
            } else { // for other scanners
                
                ZebraSDKManager.shared.setAction(actionValue: enable ? Int(RMD_ATTR_VALUE_ACTION_FAST_BLINK): Int(RMD_ATTR_VALUE_ACTION_FAST_BLINK_OFF), scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
                
            }
        }
        
        /// Method to vibrate the scanner
        func vibrateScanner() {
            _ = ZebraSDKManager.shared.performVibrationFeedback(scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
        }
        
        /// Method to beep the scanner
        func beepScanner() {
            /// CS4070 firmware does not support SET ACTION commands to control beeper. Use SSI commands instead.
            if (AppState.shared.connectedScanner?.scannerModel != nil && AppState.shared.connectedScanner.scannerModel.contains(Constants.ScannerDetails.SCANNER_MODEL_SSI_CS4070)){
                ZebraSDKManager.shared.performBeepControl(actionValue: Int(RMD_ATTR_VALUE_ACTION_HIGH_HIGH_LOW_LOW_BEEP), scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            } else {
                ZebraSDKManager.shared.setAction(actionValue: Int(RMD_ATTR_VALUE_ACTION_HIGH_HIGH_LOW_LOW_BEEP), scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            }
        }
        
        ///Method to get battery statistics
        func getBatteryStatictics() {
            
            let attributeDetailList = ZebraSDKManager.shared.getAttributeValues(attributeIdList: [
                RMD_ATTR_BATTERY_MANUFACTURE_DATE,
                RMD_ATTR_BATTERY_SERIAL_NUMBER,
                RMD_ATTR_BATTERY_MODEL_NUMBER,
                RMD_ATTR_BATTERY_DESIGN_CHARGE_CAPACITY,
                
                RMD_ATTR_BATTERY_HEALTH,
                RMD_ATTR_BATTERY_CHARGE_CYCLES,
                
                RMD_ATTR_BATTERY_FULL_CHARGE_CAPACITY,
                RMD_ATTR_BATTERY_CHARGE_PERCENTAGE,
                RMD_ATTR_BATTERY_REMAINING_CHARGE_CAPACITY,
                
                RMD_ATTR_BATTERY_CURRENT_TEMPERATURE,
                RMD_ATTR_BATTERY_HIGHEST_TEMPERATURE,
                RMD_ATTR_BATTERY_LOWEST_TEMPERATURE
            ], scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            
            var batteryStatisticData = BatteryDataModel()
            
            if (attributeDetailList.isEmpty) {
                unsupportedBattery = true
            } else {
                for attribute in attributeDetailList{
                    let attributeVal = attribute.attributeValue
                    
                    switch (Int32(attribute.attributeId)) {
                    case RMD_ATTR_BATTERY_MANUFACTURE_DATE:
                        batteryStatisticData.manufactureDate = attributeVal
                        //set the battery statistics as supported if the battery manufacture date is retrived successfully
                        unsupportedBattery = false
                        break
                    case RMD_ATTR_BATTERY_SERIAL_NUMBER:
                        batteryStatisticData.serialNumber = attributeVal
                        break
                    case RMD_ATTR_BATTERY_MODEL_NUMBER:
                        batteryStatisticData.modelNumber = attributeVal
                        break
                    case RMD_ATTR_BATTERY_DESIGN_CHARGE_CAPACITY:
                        batteryStatisticData.designCapacity = attributeVal
                        break
                    case RMD_ATTR_BATTERY_HEALTH:
                        batteryStatisticData.stateOfHealth = attributeVal
                        break
                    case RMD_ATTR_BATTERY_CHARGE_CYCLES:
                        batteryStatisticData.chargeCyclesConsumed = attributeVal
                        break
                    case RMD_ATTR_BATTERY_FULL_CHARGE_CAPACITY:
                        batteryStatisticData.fullChargeCapacity = attributeVal
                        break
                    case RMD_ATTR_BATTERY_CHARGE_PERCENTAGE:
                        batteryStatisticData.stateOfCharge = attributeVal
                        break
                    case RMD_ATTR_BATTERY_REMAINING_CHARGE_CAPACITY:
                        batteryStatisticData.remainingCapacity = attributeVal
                        break
                    case RMD_ATTR_BATTERY_CURRENT_TEMPERATURE:
                        batteryStatisticData.currentTemperature = getTempString(attr_val: attributeVal)
                        break
                    case RMD_ATTR_BATTERY_HIGHEST_TEMPERATURE:
                        batteryStatisticData.highestTemperature = getTempString(attr_val: attributeVal)
                        break
                    case RMD_ATTR_BATTERY_LOWEST_TEMPERATURE:
                        batteryStatisticData.lowestTemperature = getTempString(attr_val: attributeVal)
                        break
                    default:
                        batteryStatisticData.manufactureDate = attributeVal
                    }
                }
                self.batteryStatictics = batteryStatisticData

            }

        }
        
        /// Method to get the temperature formatted in fahrenhite and celcius
        func getTempString(attr_val: String) -> String{
            var tempString = ""
            let formatter = MeasurementFormatter()
            let celcius = Double(attr_val) ?? 0
             
            let temp = Measurement(value: celcius, unit: UnitTemperature.celsius)
            formatter.locale = Locale(identifier: "en_GB")
            let formattedTempInCelcius = formatter.string(from: temp)
            formatter.locale = Locale(identifier: "en_US")
            let formattedTempInFahrenheit = formatter.string(from: temp)
            
            tempString = "\(formattedTempInFahrenheit) / \(formattedTempInCelcius)"
            return  tempString;
        }
        
        /// Method to check whether the scanner supports virtual tether
        func getVirtualTetherSupportedStatus() {
            let attributeList = ZebraSDKManager.shared.getAttributeValues(attributeIdList: [RMD_ATTR_VIRTUAL_TETHER_ALARM_STATUS], scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            //Virtual tether is supported if the attribute list has values
            if (attributeList.count > 0) {
                AppState.shared.isVirtualTetherSupported = true
            } else {
                AppState.shared.isVirtualTetherSupported = false
            }

        }
    }
    
}
