//
//  UpdateFirmwareViewModel.swift
//  ScannerControl
//
//  ©2023 Zebra Technologies Corp. and/or its affiliates.  All rights reserved.
//

import Foundation
import SwiftUI
import ZIPFoundation

extension UpdateFirmwareView {
    
    enum FirmwareUpdatingStatus: Hashable {
        case notStarted
        case started
        case finished
        case errorOccured
    }
    
    ///ViewModel for publishing UI updates to UpdateFirmwareView
    @MainActor class ViewModel: ObservableObject {
        var currentFirmwareVersion: String?
        var modelName: String?
        @ObservedObject var appState = AppState.shared
        var alertDetails = AlertDetails(alertType: .actionFailed, description: "retrieve scanner information")
        @Published var actionNotSupportedAlert: Bool = false
        var firmwareFileList: [FirmwareFile] = []
        @Published var selectedFirmwareFile : FirmwareFile?
        @Published var showFilePicker = false
        @Published var showHelp = false
        @Published var showPluginMismatch = false
        @Published var showPluginMatchUI = false
        @Published var firmwareUpdateAborted = false
        @Published var showFWUpdateProgressView = false
        @Published var showAlertForAbortFWUpdate = false
        var isNavigatingToReleaseNotes = false
        var fwUpdateStatus: FirmwareUpdatingStatus = .notStarted {
            didSet {
                if fwUpdateStatus == .started {
                    DispatchQueue.main.async {
                        AppState.shared.isFirmwareUpdating = true
                    }
                    showFWUpdateProgressView = true
               
                }else {
                    showFWUpdateProgressView = false
                    DispatchQueue.main.async {
                        AppState.shared.isFirmwareUpdating = false
                    }
                }
            }
        }
        @Published var showRebooting = false
        
        init() {
            DispatchQueue.background(background:{
                self.getScannerInfo()
            })
            if (!AppState.shared.isRebootCompleted) {
                getFirmwareFileList()
                DispatchQueue.main.async {
                    self.appState.progressOfFirmwareUpdate = 0.0
                }
            }
        }
        
        
        /// Get current scanner firmware version and model number.
        func getScannerInfo() {
            let scannerId = appState.connectedScanner?.scannerId ?? 0
            if (scannerId != 0) {
                let attributeDetailList = ZebraSDKManager.shared.getAttributeValues(attributeIdList: [RMD_ATTR_FRMWR_VERSION,RMD_ATTR_MODEL_NUMBER], scannerId: scannerId)
                
                if (attributeDetailList.isEmpty) {
                    alertDetails = AlertDetails(alertType: .actionFailed, description: "retrieve scanner information")
                    actionNotSupportedAlert = true
                } else {
                    for attribute in attributeDetailList{
                        let attributeVal = attribute.attributeValue
                        
                        switch (Int32(attribute.attributeId)) {
                        case RMD_ATTR_FRMWR_VERSION:
                            currentFirmwareVersion = attributeVal
                            break
                        case RMD_ATTR_MODEL_NUMBER:
                            modelName = attributeVal
                            break
                        default:
                            currentFirmwareVersion = attributeVal
                        }
                    }
                }
            }
            
        }
        
        /// Get firmware files from the app downloads directory
        func getFirmwareFileList() {
            
            let documentDir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            let downloadDir = documentDir.appendingPathComponent(Constants.AppDetails.ZT_FW_FILE_DIRECTORY_NAME)
            
            let fileManager = FileManager.default
            
            do {
                let directoryContents = try fileManager.contentsOfDirectory(at: downloadDir, includingPropertiesForKeys: nil)
                let filteredFiles = directoryContents.filter { url in
                    return url.pathExtension == Constants.AppDetails.ZT_PLUGIN_FILE_EXTENSION || url.pathExtension == Constants.AppDetails.ZT_FW_FILE_EXTENSION
                }
                for firmwareFile in filteredFiles {
                    let fileExtension = firmwareFile.pathExtension == Constants.AppDetails.ZT_PLUGIN_FILE_EXTENSION ? FirmwareFileType.SCNPLG : FirmwareFileType.DAT
                    let newFile = FirmwareFile(fileName: firmwareFile.lastPathComponent, fileType: fileExtension, fileURL: firmwareFile)
                    self.firmwareFileList.append(newFile)
                }
                
            } catch {
                print("Error: \(error)")
            }
            
        }
        
        // Action for the select firmware button
        func selectFirmwareButtonAction() {
            if (firmwareFileList.isEmpty) {
                alertDetails =  AlertDetails(alertType: .none, description: L10n.UpdateFirmwareView.noFilesText)
                actionNotSupportedAlert = true
            } else {
                // hile firmware file picker
                showFilePicker.toggle()
            }
        }
        
        // Method to be called on selection of a firmware file from the list
        func onFirmwareFileSelected(item: FirmwareFile) {
            showFilePicker.toggle()
            selectedFirmwareFile = item
            if (item.fileType == FirmwareFileType.SCNPLG) {
                extractAndReadPluginFileContent()
                
                if isPluginMismatch() {
                    showPluginMismatch.toggle()
                }else {
                    showPluginData()
                }
            } else {
                showPluginData()
            }
        }
        
        /// Action for the update firmware button
        func updateFirmwareButtonAction() {
            
            if (selectedFirmwareFile != nil) {
                
                performFastBlinkLed(enable: true)
                
                fwUpdateStatus = .started
                
                /// run the firmware update in background thread
                DispatchQueue.background(background:{ [weak self] in
                    
                    /// disable barcode scaning before starting the firmware update
                    self?.disableBarcodeScanning()
                    DispatchQueue.main.async {
                        AppState.shared.firmwareUpdateDidStop = false
                        AppState.shared.firmwareUpdateDidAbort = false
                    }
                    guard let selectedFile = self?.selectedFirmwareFile else {
                        return
                    }
                    
                    let commad = selectedFile.fileType == FirmwareFileType.DAT ? SBT_UPDATE_FIRMWARE : SBT_UPDATE_FIRMWARE_FROM_PLUGIN
                    
                    let result: SBT_RESULT =  ZebraSDKManager.shared.performFirmwareUpdate(selectedFilePath: selectedFile.fileURL?.path ?? "", firmwareUpdateCommand: commad, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
                    
                    self?.performFastBlinkLed(enable: false)
                    
                    if (AppState.shared.firmwareUpdateDidAbort) {
                        DispatchQueue.main.async {
                            self?.fwUpdateStatus = .notStarted
                            self?.appState.progressOfFirmwareUpdate = 0.0
                        }
                        
                    } else if (result == SBT_RESULT_FAILURE) {
                        
                        DispatchQueue.main.async {
                            self?.fwUpdateStatus = .errorOccured
                        }
                        
                        self?.enableBarcodeScanning()
                        
                        
                    }else{
                        
                        DispatchQueue.main.async {
                            self?.fwUpdateStatus = .finished
                            self?.appState.isFirmwareUpdated = true
                        }
                        /// Disable all virtual tether host feedback options on firmware update success
                        AppSettings.shared.enableHostFeedback = false
                        AppSettings.shared.virtualTetherVibration = false
                        AppSettings.shared.virtualTetherAudioAlarm = false
                        AppSettings.shared.virtualTetherPopupMessage = false
                        AppSettings.shared.virtualTetherFlashingScreen = false
                        
                        ///  call start new firmware
                        self?.startNewFirmware()
                    }
                    
                    
                })
                
            }
        }
        
        /// Method to enable barcode scaning
        func enableBarcodeScanning() {
            
            let command = Int(SBT_DEVICE_SCAN_DISABLE)
            ZebraSDKManager.shared.performScanEnableDisable(command: command, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
        }
        
        /// Method to disable barcode scaning
        func disableBarcodeScanning () {
            
            let command = Int(SBT_DEVICE_SCAN_DISABLE)
            ZebraSDKManager.shared.performScanEnableDisable(command: command, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
        }
        
        /// Check for plugin mismatch
        /// - Returns: bolean value for plugin mismatch or not
        func isPluginMismatch() -> Bool {
           
            var isPluginMismatching = true
            
            for supportedModelName in selectedFirmwareFile?.supportedModels ?? [] {
                
                if supportedModelName == modelName {
                    isPluginMismatching = false
                    break
                }
                
            }
            return isPluginMismatching
        }
        
        /// Cancel action for firmware update
        func cancelButtonAction() {
            /// Abort firmware
            self.showAlertForAbortFWUpdate = true
        }
        
        /// Method to extract plugin file data
        func extractAndReadPluginFileContent () {
            
            ///An `Archive` is a sequence of entries
            guard let archive = Archive(url: selectedFirmwareFile?.fileURL ?? URL(fileURLWithPath: ""), accessMode: .read) else  {
                return
            }
            
            /// Entry is a single file that contains in the archive
            for entry in archive {
                
                let fileName = entry.path
                let fileExtension =  URL(fileURLWithPath: fileName).pathExtension
                
                
                if fileExtension == Constants.AppDetails.ZT_RELEASE_NOTES_FILE_EXTENTION {
                    
                    do {
                        // Extract "Release note" data
                        _ = try archive.extract(entry, consumer: { (data) in
                            let releaseNote = String(data: data, encoding: .utf8)
                            selectedFirmwareFile?.releaseNotes = releaseNote
                            
                        })
                        
                    } catch {
                        print("Extracting release notes from archive failed with error:\(error)")
                    }
                } else if fileName == Constants.AppDetails.ZT_METADATA_FILE {
                    do {
                        // Extract "Metadata" Xml file
                        _ = try archive.extract(entry, consumer: { (data) in
                            
                            // MetaDataXmlParser is a custom parser for extracting data from Metadata xml
                            let parser = MetaDataXmlParser()
                            let xmlParser = XMLParser(data: data)
                            xmlParser.delegate = parser
                            xmlParser.parse()
                            
                            // set the extracted data to the Firmware file object
                            selectedFirmwareFile?.firmwareVersionNames = parser.firmwareVersionNameList
                            selectedFirmwareFile?.supportedModels = parser.supportedScannerModelList
                            selectedFirmwareFile?.pluginRevision = parser.pluginRevision
                            selectedFirmwareFile?.pluginReleasedDate = parser.pluginDate
                            selectedFirmwareFile?.pluginScannerImageName = parser.pngFileName
                            selectedFirmwareFile?.pluginFamilyName = parser.pluginFamily + parser.pluginName
                            
                        })
                        
                        
                    } catch {
                        print("Extracting Meta Data file from archive failed with error:\(error)")
                    }
                }
            }
            
            guard let selectedFirmwareFile1 = selectedFirmwareFile, let pluginImageName =  selectedFirmwareFile1.pluginScannerImageName else {
                return
            }
            
            // verify a matching image file is there in the archive (the image file name under "picture" tag should be same as the file name in the archive)
            // replacingOccurences was used to replace pluginImageName spaces with space character(%20) as the unzipped file names included space characters
            guard let imageEntry = archive[pluginImageName.replacingOccurrences(of: " ", with: "%20")] else {
                return
            }
            
            var extractedData: Data = Data([])
            
            do {
                // Extract scanner image data
                _ = try archive.extract(imageEntry) { extractedData.append($0) }
                
                if let image = UIImage(data: extractedData) {
                    self.selectedFirmwareFile?.pluginScannerImage = image
                }
                
            } catch {
                print("Extracting image from archive failed with error:\(error)")
            }
        }
        
        /// show extracted plugin file data on the UI, if it is a matched one
        func showPluginData(){
            showPluginMatchUI = true
        }
        
        
        /// Method to enable or disable fast blink LED for firmware update
        /// - Parameter enable:  Boolean value to enable or disable. To enable --> true, disable --> false
        func performFastBlinkLed (enable: Bool) {
            
            let actionCommand = enable ? Int(RMD_ATTR_VALUE_ACTION_FAST_BLINK) : Int(RMD_ATTR_VALUE_ACTION_FAST_BLINK_OFF)
            ZebraSDKManager.shared.setAction(actionValue: actionCommand, scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
            
        }
        
        /// Method to start new firmware after firmware update is completed successfully
        func startNewFirmware() {
            /// save current firmware file info to show details after reconnection
            let result = ZebraSDKManager.shared.startNewFirmware(scannerId: AppState.shared.connectedScanner?.scannerId ?? 0);
            DispatchQueue.main.async {
                self.appState.updatedFirmwarePluginFile = self.selectedFirmwareFile
                if (result != SBT_RESULT_SUCCESS){
                    self.alertDetails = AlertDetails(alertType: .actionFailed, description: "start new firmware")
                    self.actionNotSupportedAlert = true
                } else {
                    self.showRebooting = true
                }
            }
        }
        
        /// Method to abort firmware update while firmware update is in progress
        func abortFirmwareUpdate() {
            DispatchQueue.main.async {
                AppState.shared.firmwareUpdateDidStop = true
            }
            DispatchQueue.background(background:{ [weak self] in
                let result: SBT_RESULT =  ZebraSDKManager.shared.abortFirmwareUpdate(scannerId: AppState.shared.connectedScanner?.scannerId ?? 0)
                DispatchQueue.main.async {
                    if (result == SBT_RESULT_SUCCESS) {
                        AppState.shared.firmwareUpdateDidAbort = true
                        self?.dismissAbortFirmwareAlert()
                    } else {
                        self?.dismissAbortFirmwareAlert()
                        self?.alertDetails = AlertDetails(alertType: .none, description: "Firmware update abort failed.")
                        self?.actionNotSupportedAlert = true
                        AppState.shared.firmwareUpdateDidStop = false
                    }
                }
            })
        }
        
        /// Method to dismiss the abort firmware update confirmation alert
        func dismissAbortFirmwareAlert() {
            self.showAlertForAbortFWUpdate = false
        }
    }
    
}

