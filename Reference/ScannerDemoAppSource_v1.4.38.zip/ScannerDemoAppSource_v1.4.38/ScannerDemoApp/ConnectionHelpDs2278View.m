//
//  ConnectionHelpDs2278View.m
//  ScannerSDKApp
//
//  Created by Nilusha Niwanthaka Wimalasena on 7/11/17.
//  Copyright © 2017 Alexei Igumnov. All rights reserved.
//

#import "ConnectionHelpDs2278View.h"
#import "BarcodeImage.h"
#import "UIColor+DarkModeExtension.h"

@implementation ConnectionHelpDs2278View

#pragma mark - Dark mode handling


@end
