//
//  BarcodeGen128.h
//  ScannerSDKApp
//
//  Created by pqj647 on 6/27/16.
//  Copyright © 2016 Alexei Igumnov. All rights reserved.
//

#ifndef BarcodeGen128_h
#define BarcodeGen128_h

unsigned generateBarcode128B1(const char *input, unsigned short *output, unsigned *width);

#endif /* BarcodeGen128_h */
