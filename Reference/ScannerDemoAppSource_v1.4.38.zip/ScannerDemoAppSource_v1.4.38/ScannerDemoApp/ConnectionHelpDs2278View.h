//
//  ConnectionHelpDs2278View.h
//  ScannerSDKApp
//
//  Created by Nilusha Niwanthaka Wimalasena on 7/11/17.
//  Copyright © 2017 Alexei Igumnov. All rights reserved.
//

#import "ConnectionHelpView.h"

@interface ConnectionHelpDs2278View : zt_ConnectionHelpView


@end
