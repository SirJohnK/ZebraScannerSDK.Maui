/******************************************************************************
 *
 *       Copyright Zebra Technologies, Inc. 2014 - 2015
 *
 *       The copyright notice above does not evidence any
 *       actual or intended publication of such source code.
 *       The code contains Zebra Technologies
 *       Confidential Proprietary Information.
 *
 *
 *  Description:  ActiveScannerInfoVC.m
 *
 *  Notes:
 *
 ******************************************************************************/

#import "ActiveScannerInfoVC.h"
#import "ActiveScannerVC.h"
#import "ConnectionManager.h"
#import "ScannerAppEngine.h"
#import "config.h"
#import "LedActionVC.h"
#import "BeeperActionVC.h"
#import "AssetDetailsVC.h"
#import "NSString+Contain.h"
#import "RMDAttributes.h"
#import "AppSettingsKeys.h"

typedef enum
{
    SECTION_ACTIONS = 0,
    SECTION_INFORMATION,
    SECTION_DISCONNECT,
    SECTION_AUTO_RECONNECT,
    SECTION_TOTAL
} InfoSection;

@interface zt_ActiveScannerInfoVC ()

@end

@implementation zt_ActiveScannerInfoVC


- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self != nil)
    {
        m_IsBusy = NO;
        attributeType = 0;
        isAutoReconnectEnable = NO;
        disabledParameterBarcodeScanning = NO;
    }
    return self;
}

- (void)dealloc
{
    [self.tableView setDataSource:nil];
    [self.tableView setDelegate:nil];
    [m_lblScannerName release];
    [switchAutoReconnect release];
    [switchParameterBarcode release];
    
    if (activityView != nil)
    {
        [activityView release];
    }

    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    activityView = [[zt_AlertView alloc]init];
    
    // Initialize the connection manager
    [ConnectionManager sharedConnectionManager];
    
    // Get auto reconnect status stored in user default
    [self getAutoReconnectStatus];
    
}

//Sent to the view controller when the app receives a memory warning.
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    // Get Auto Reconnect status
//    [self getAutoReconnectSyncStatus:[[ConnectionManager sharedConnectionManager] getConnectedScannerId] rmd_attr_value: RMD_ATTR_VALUE_AUTO_RECONNECT];
    
    [self updateUI];
    
    // firmware update
    if ([[zt_ScannerAppEngine sharedAppEngine] firmwareDidUpdate] == NO && disabledParameterBarcodeScanning == NO){
        // Disable parameter barcode scanning to avoid changing scanner side auto reconnection status by scanning the parameter barcode
        [self setParameterValueForAutoReconnectionSynchronize:0 rmd_attr_value:RMD_ATTR_VALUE_PARAMETER_BARCODE];
        disabledParameterBarcodeScanning = YES;
    }
}

- (void)updateUI
{
    if ([self.tabBarController isKindOfClass:[zt_ActiveScannerVC class]] == YES)
    {
        int scanner_id = [(zt_ActiveScannerVC*)self.tabBarController getScannerID];
        SbtScannerInfo *scanner_info = [[zt_ScannerAppEngine sharedAppEngine] getScannerByID:scanner_id];
        if (scanner_info != nil)
        {
            switch ([scanner_info getConnectionType])
            {
                case SBT_CONNTYPE_MFI:
                    [m_lblScannerName setText:[NSString stringWithFormat:@"%@", [scanner_info getScannerName]]];
                    break;
                case SBT_CONNTYPE_BTLE:
                    [m_lblScannerName setText:[NSString stringWithFormat:@"%@", [scanner_info getScannerName]]];
                    break;
            }
            return;
        }
    }
}

- (void)terminateCommunicationSession
{
    dispatch_async(dispatch_get_main_queue(), ^{
        if ([self.tabBarController isKindOfClass:[zt_ActiveScannerVC class]] == YES)
        {
            [[ConnectionManager sharedConnectionManager] disconnect];
        }

        m_IsBusy = NO;
    });
}

//
- (void)getAutoReconnectStatus {
    // Update auto reconnect status which previously get when in the  the UI
    isAutoReconnectEnable = [[NSUserDefaults standardUserDefaults] boolForKey:ZT_AUTO_RECONNECT_STATUS];
    [switchAutoReconnect setOn:isAutoReconnectEnable animated:YES];
}

- (void)setAutoReconnectStatus:(NSString*)param {

        SBT_RESULT res = [[zt_ScannerAppEngine sharedAppEngine] executeCommand:SBT_RSM_ATTR_STORE aInXML:param aOutXML:nil forScanner:[[ConnectionManager sharedConnectionManager] getConnectedScannerId]];
        
        if (res != SBT_RESULT_SUCCESS)
        {
            dispatch_async(dispatch_get_main_queue(), ^{
                /*
                 revert back, switch staus to previos state on UI as configuration is failed
                 */
                if (attributeType == RMD_ATTR_VALUE_AUTO_RECONNECT) {
                    [self updateUIAutoReconnection:switchPreviousStatus];
                }else {
                    [self updateUIParameterBarcode:switchPreviousStatus];
                }
                
                UIAlertController * alert = [UIAlertController
                                             alertControllerWithTitle:ZT_SCANNER_APP_NAME
                                             message:attributeType == RMD_ATTR_VALUE_AUTO_RECONNECT ? ZT_SCANNER_CANNOT_APPLY_AUTO_RECONNECT : ZT_SCANNER_CANNOT_APPLY_PRAMETER_BARCODE_SCANNING
                                             preferredStyle:UIAlertControllerStyleAlert];
                UIAlertAction* okButton = [UIAlertAction
                                           actionWithTitle:OK
                                           style:UIAlertActionStyleDefault
                                           handler:^(UIAlertAction * action) {
                    //Handle ok action
                }];
                [alert addAction:okButton];
                [self presentViewController:alert animated:YES completion:nil];
            });
        } else {
            if(attributeType == RMD_ATTR_VALUE_AUTO_RECONNECT) {
                //Save the auto reconnect status in user defaults
                [[NSUserDefaults standardUserDefaults] setBool:isAutoReconnectEnable forKey:ZT_AUTO_RECONNECT_STATUS];
                // update auto-reconnect option status in the SDK by user interaction
                [[zt_ScannerAppEngine sharedAppEngine] setAutoReconnectOption: [[ConnectionManager sharedConnectionManager] getConnectedScannerId] enableOption:isAutoReconnectEnable];
            }
        }
        
        [self getAutoReconnectSyncStatus:[[ConnectionManager sharedConnectionManager] getConnectedScannerId] rmd_attr_value: attributeType];
  
}

-(void)getAutoReconnectSyncStatus:(int)scanner_id rmd_attr_value:(int)attrValue {
    
    NSString *in_xml = [NSString stringWithFormat:@"<inArgs><scannerID>%d</scannerID><cmdArgs><arg-xml><attrib_list>%d</attrib_list></arg-xml></cmdArgs></inArgs>", scanner_id, attrValue];
    
    NSMutableString *result = [[NSMutableString alloc] init];
    
    SBT_RESULT res = [[zt_ScannerAppEngine sharedAppEngine] executeCommand:SBT_RSM_ATTR_GET aInXML:in_xml aOutXML:&result forScanner:scanner_id];
    
    if (SBT_RESULT_SUCCESS != res) {
        // Faild result for auto reconnect enable status
        NSLog(@"error");
        dispatch_async(dispatch_get_main_queue(), ^{
            UIAlertController * alert = [UIAlertController
                                         alertControllerWithTitle:ZT_SCANNER_APP_NAME
                                         message:attributeType == RMD_ATTR_VALUE_AUTO_RECONNECT ? ZT_SCANNER_CANNOT_RETRIEVE_AUTO_RECONNECT : ZT_SCANNER_CANNOT_RETRIEVE_PRAMETER_BARCODE_SCANNING
                                         preferredStyle:UIAlertControllerStyleAlert];
            UIAlertAction* okButton = [UIAlertAction
                                       actionWithTitle:OK
                                       style:UIAlertActionStyleDefault
                                       handler:^(UIAlertAction * action) {
                //Handle ok action
            }];
            [alert addAction:okButton];
            [self presentViewController:alert animated:YES completion:nil];
          }
        );
        return;
        
    } else {
        // Success result
        do {
            
            NSString* res_str = [result stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            
            NSString* tmp = @"<attrib_list><attribute>";
            NSRange range = [res_str rangeOfString:tmp];
            NSRange range2;
            
            if ((range.location == NSNotFound) || (range.length != [tmp length]))
            {
                break;
            }
            
            res_str = [res_str substringFromIndex:(range.location + range.length)];
            
            tmp = @"</attribute></attrib_list>";
            range = [res_str rangeOfString:tmp];
            
            if ((range.location == NSNotFound) || (range.length != [tmp length]))
            {
                break;
            }
            
            range.length = [res_str length] - range.location;
            
            res_str = [res_str stringByReplacingCharactersInRange:range withString:@""];
            
            NSArray *attrs = [res_str componentsSeparatedByString:@"</attribute><attribute>"];
            
            if ([attrs count] == 0)
            {
                break;
            }
            
            NSString *attr_str;
            
            int attr_id;
            int attr_val;
            
            for (NSString *pstr in attrs) {
                
                attr_str = pstr;
                
                tmp = @"<id>";
                range = [attr_str rangeOfString:tmp];
                if ((range.location != 0) || (range.length != [tmp length]))
                {
                    break;
                }
                attr_str = [attr_str stringByReplacingCharactersInRange:range withString:@""];
                
                tmp = @"</id>";
                
                range = [attr_str rangeOfString:tmp];
                
                if ((range.location == NSNotFound) || (range.length != [tmp length]))
                {
                    break;
                }
                
                range2.length = [attr_str length] - range.location;
                range2.location = range.location;
                
                NSString *attr_id_str = [attr_str stringByReplacingCharactersInRange:range2 withString:@""];
                
                attr_id = [attr_id_str intValue];
                
                
                range2.location = 0;
                range2.length = range.location + range.length;
                
                attr_str = [attr_str stringByReplacingCharactersInRange:range2 withString:@""];
                
                tmp = @"<value>";
                range = [attr_str rangeOfString:tmp];
                if ((range.location == NSNotFound) || (range.length != [tmp length]))
                {
                    break;
                }
                attr_str = [attr_str substringFromIndex:(range.location + range.length)];
                
                tmp = @"</value>";
                
                range = [attr_str rangeOfString:tmp];
                
                if ((range.location == NSNotFound) || (range.length != [tmp length]))
                {
                    break;
                }
                
                range.length = [attr_str length] - range.location;
                
                attr_str = [attr_str stringByReplacingCharactersInRange:range withString:@""];
                
                attr_val = [attr_str intValue];
                
                if(attrValue == RMD_ATTR_VALUE_PARAMETER_BARCODE){
                    
                    if([attr_str isEqual: @"TRUE"]){
                        // Enable Parameter BarCode
                        [self updateUIParameterBarcode: NO];
                    } else {
                        // Disable Parameter BarCode
                        [self updateUIParameterBarcode: YES];
                    }
                    
                } else {
                    
                    switch (attr_val){
                        case AutoReconnectBarCodeData:
                            [self updateUIAutoReconnection: YES];
                            break;
                        case AutoReconnectImmediately:
                            [self updateUIAutoReconnection: YES];
                            break;
                        case DisableAutoReconnect:
                            [self updateUIAutoReconnection: NO];
                            break;
                        default:
                            break;
                    }
                }
            }
        } while (0);
    }
    
    [result release];
}

// Parameter barcode enable or disable and auto reconnect enable or disable
- (void)setParameterValueForAutoReconnectionSynchronize:(int)value rmd_attr_value:(int)attrValue {
    // get Scanner ID
    int m_ScannerID = [[ConnectionManager sharedConnectionManager] getConnectedScannerId];
    NSString *in_xml = @"";
    attributeType = attrValue;
    
    if(attrValue == RMD_ATTR_VALUE_AUTO_RECONNECT){
        in_xml = [NSString stringWithFormat:@"<inArgs><scannerID>%d</scannerID><cmdArgs><arg-xml><attrib_list><attribute><id>%d</id><datatype>B</datatype><value>%d</value></attribute></attrib_list></arg-xml></cmdArgs></inArgs>", m_ScannerID, attrValue, value];
    } else {
        in_xml = [NSString stringWithFormat:@"<inArgs><scannerID>%d</scannerID><cmdArgs><arg-xml><attrib_list><attribute><id>%d</id><datatype>F</datatype><value>%@</value></attribute></attrib_list></arg-xml></cmdArgs></inArgs>", m_ScannerID, attrValue, (value == 1) ? @"TRUE" : @"FALSE"];
    }
    
    [activityView showAlertWithView:self.view withTarget:self withMethod:@selector(setAutoReconnectStatus:) withObject:in_xml withString:nil];
}

// UI update - auto reconnection
- (void)updateUIAutoReconnection:(BOOL)statusType{
    dispatch_async(dispatch_get_main_queue(), ^{
        [switchAutoReconnect setOn:statusType animated:NO];
    });
}

// UI update - parameter barcode
- (void)updateUIParameterBarcode:(BOOL)statusType{
    dispatch_async(dispatch_get_main_queue(), ^{
        [switchParameterBarcode setOn:statusType animated:NO];
    });
}

#pragma mark - IBAction - UISwitch
// handle auto reconnect switch  value change action
- (IBAction)autoReconnectSwitchValueChanged:(id)sender {
    int autoReconnectValue = 0;

    if ([sender isOn]) {
        // Auto reconnect immediately
        autoReconnectValue = 2;
        isAutoReconnectEnable = YES;
    } else {
        // Disable auto reconnect
        autoReconnectValue = 0;
        isAutoReconnectEnable = NO;
    }
    switchPreviousStatus = ![sender isOn];
    [self setParameterValueForAutoReconnectionSynchronize: autoReconnectValue rmd_attr_value:RMD_ATTR_VALUE_AUTO_RECONNECT];
}

// handle parameter barcode scanning switch value change action
- (IBAction)parameterBarcodeScanningSwitchValueChanged:(id)sender {
    int parameterBarCodeValue = 0;
    if ([sender isOn]) {
        /// Disable parameter barcode scanning
        parameterBarCodeValue = 0;
    } else {
        /// Enable parameter barcode scanning
        parameterBarCodeValue = 1;
    }
    switchPreviousStatus = ![sender isOn];
    [self setParameterValueForAutoReconnectionSynchronize: parameterBarCodeValue rmd_attr_value:RMD_ATTR_VALUE_PARAMETER_BARCODE];
}

#pragma mark - IBAction - UIButton

/// handle info button click action
- (IBAction)parameterBarcodeScanningInfoButtonClicked:(id)sender {
    
    UIAlertController * alert = [UIAlertController
                                 alertControllerWithTitle:DISABLED_MODE_ALERT_TITLE
                                     message:PARAMETER_BARCODE_SCANNING_SETTING_MESSAGE
                              preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction* okButton = [UIAlertAction
                        actionWithTitle:OK
                                  style:UIAlertActionStyleCancel
                                handler:^(UIAlertAction * action) {
                                    //Handle ok action
                                }];
    [alert addAction:okButton];
    
    [self presentViewController:alert animated:YES completion:nil];
    
}


#pragma mark - Table view data source
/* ###################################################################### */
/* ########## Table View Data Source Delegate Protocol implementation ### */
/* ###################################################################### */

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return SECTION_TOTAL;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    switch (section)
    {
        case SECTION_DISCONNECT:
            return 1;
        case SECTION_INFORMATION:
            return 2;
        case SECTION_ACTIONS:
            return 2;
        case SECTION_AUTO_RECONNECT:
            return 2;
        default:
            return 0;
    }
}

#pragma mark - Table view delegate
/* ###################################################################### */
/* ########## Table View Delegate Protocol implementation ############### */
/* ###################################################################### */

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Navigation logic may go here. Create and push another view controller.
    if ([indexPath section] == SECTION_ACTIONS) /* actions section */
    {
        if ([indexPath row] == 0) /* Beeper */
        {
            zt_BeeperActionVC *beeper_vc = (zt_BeeperActionVC*)[[UIStoryboard storyboardWithName:SCANNER_STORY_BOARD bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:ID_SCANNER_BEEPER_ACTION_VC];
            
            if (beeper_vc != nil)
            {
                [beeper_vc setScannerID:[(zt_ActiveScannerVC*)self.tabBarController getScannerID]];
                [self.navigationController pushViewController:beeper_vc animated:YES];
                /* beeper_vc is autoreleased object returned by instantiateViewControllerWithIdentifier */
            }
        }
        else if ([indexPath row] == 1) /* LED */
        {
            zt_LedActionVC *led_vc = (zt_LedActionVC*)[[UIStoryboard storyboardWithName:SCANNER_STORY_BOARD bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:ID_SCANNER_LED_ACTION_VC];
            
            if (led_vc != nil)
            {
                [led_vc setScannerID:[(zt_ActiveScannerVC*)self.tabBarController getScannerID]];
                [self.navigationController pushViewController:led_vc animated:YES];
                /* led_vc is autoreleased object returned by instantiateViewControllerWithIdentifier */
            }
        }
    }
    
    if (([indexPath section] == SECTION_DISCONNECT) && ([indexPath row] == 0)) /* Disconnect button */
    {
        if (NO == m_IsBusy)
        {
            
            UIAlertController * alert = [UIAlertController
                                        alertControllerWithTitle:ACTIVE_SCANNER_DISCONNECT_ALERT_TITLE
                                                         message:ZT_SCANNER_DISCONNECT_SCANNER_FROM_APPLICATION_MESSAGE
                                                  preferredStyle:UIAlertControllerStyleAlert];
                        UIAlertAction* yesButton = [UIAlertAction
                                            actionWithTitle:ACTIVE_SCANNER_BARCODE_ALERT_CANCEL
                                                      style:UIAlertActionStyleDefault
                                                    handler:^(UIAlertAction * action) {
                                                        //Handle your yes please button action here
                                                    }];
                        UIAlertAction* noButton = [UIAlertAction
                                                actionWithTitle:ACTIVE_SCANNER_BARCODE_ALERT_CONTINUE
                                                          style:UIAlertActionStyleDefault
                                                        handler:^(UIAlertAction * action) {
                            m_IsBusy = YES;
                            ///Disable all virtual tether options on new scanner disconnect
                            [[ConnectionManager sharedConnectionManager] resetAllVirtualTetherHostAlarmSetting];
                            [activityView showAlertWithView:self.view withTarget:self withMethod:@selector(terminateCommunicationSession) withObject:nil withString:ZT_SCANNER_DISCONNECTING_MESSAGE];
                                                        }];

                        [alert addAction:yesButton];
                        [alert addAction:noButton];
                        [self presentViewController:alert animated:YES completion:nil];
                        
        }
    }
    
    if ([indexPath section] == SECTION_INFORMATION && [indexPath row] == 1) {
        AssetDetailsVC *assets_vc = nil;
        
        assets_vc = (AssetDetailsVC*)[[UIStoryboard storyboardWithName:SCANNER_STORY_BOARD bundle:[NSBundle mainBundle]] instantiateViewControllerWithIdentifier:ID_ASSET_DETAILS_VC];
        
        if (assets_vc != nil)
        {
            SbtScannerInfo *scanner_info = [[zt_ScannerAppEngine sharedAppEngine] getScannerByID:[(zt_ActiveScannerVC*)self.tabBarController getScannerID]];
            [assets_vc setScanner_info:scanner_info];
            [self.navigationController pushViewController:assets_vc animated:YES];
        }
    }

    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if (cell != nil)
    {
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        //[cell setSelected:NO animated:YES];
    }
}

@end
