//
//  FWUpdateModel.m
//  ScannerSDKApp
//
//  Created by pqj647 on 10/9/16.
//  Copyright © 2016 Alexei Igumnov. All rights reserved.
//

#import "FWUpdateModel.h"

@implementation FWUpdateModel

@end
