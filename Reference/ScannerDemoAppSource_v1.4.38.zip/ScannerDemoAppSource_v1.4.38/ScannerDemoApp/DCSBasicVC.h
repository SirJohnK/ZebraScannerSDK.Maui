//
//  DCSBasicVC.h
//  ScannerSDKApp
//
//  Created by pqj647 on 8/1/16.
//  Copyright © 2016 Alexei Igumnov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DCSBasicVC : UIViewController

@property(nonatomic, retain)NSString *backBTNName;

@end
